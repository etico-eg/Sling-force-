import 'package:get/get.dart';

import '../modules/chain/bindings/chain_binding.dart';
import '../modules/chain/views/chain_view.dart';
import '../modules/clutch/bindings/clutch_binding.dart';
import '../modules/clutch/views/clutch_view.dart';
import '../modules/connection_link/bindings/connection_link_binding.dart';
import '../modules/connection_link/views/connection_link_view.dart';
import '../modules/home/bindings/home_binding.dart';
import '../modules/home/views/home_view.dart';
import '../modules/hook/bindings/hook_binding.dart';
import '../modules/hook/views/hook_view.dart';
import '../modules/lifting_eye/bindings/lifting_eye_binding.dart';
import '../modules/lifting_eye/views/lifting_eye_view.dart';
import '../modules/load_binder/bindings/load_binder_binding.dart';
import '../modules/load_binder/views/load_binder_view.dart';
import '../modules/machine_spec/bindings/machine_spec_binding.dart';
import '../modules/machine_spec/views/machine_spec_view.dart';
import '../modules/quatation_wire/bindings/quatation_wire_binding.dart';
import '../modules/quatation_wire/views/quatation_wire_view.dart';
import '../modules/shakle_tracking/bindings/shakle_tracking_binding.dart';
import '../modules/shakle_tracking/views/shakle_tracking_view.dart';
import '../modules/socket/bindings/socket_binding.dart';
import '../modules/socket/views/socket_view.dart';
import '../modules/splash/bindings/splash_binding.dart';
import '../modules/splash/views/splash_view.dart';
import '../modules/steel_quatation/bindings/steel_quatation_binding.dart';
import '../modules/steel_quatation/views/steel_quatation_view.dart';
import '../modules/steel_slings/bindings/steel_slings_binding.dart';
import '../modules/steel_slings/views/steel_slings_view.dart';
import '../modules/steel_slings_quotation/bindings/steel_slings_quotation_binding.dart';
import '../modules/steel_slings_quotation/views/steel_slings_quotation_view.dart';
import '../modules/turn_buckle/bindings/turn_buckle_binding.dart';
import '../modules/turn_buckle/views/turn_buckle_view.dart';
import '../modules/wire_rope_clips/bindings/wire_rope_clips_binding.dart';
import '../modules/wire_rope_clips/views/wire_rope_clips_view.dart';
import '../modules/wire_rope_quatation/bindings/wire_rope_quatation_binding.dart';
import '../modules/wire_rope_quatation/views/wire_rope_quatation_view.dart';
import '../modules/wire_rope_sling/bindings/wire_rope_sling_binding.dart';
import '../modules/wire_rope_sling/views/wire_rope_sling_view.dart';

part 'app_routes.dart';

class AppPages {
  static const INITIAL = Routes.SPLASH;

  static final routes = [
    GetPage(
      name: _Paths.HOME,
      page: () => const HomeView(),
      binding: HomeBinding(),
    ),
    GetPage(
      name: _Paths.MACHINE_SPEC,
      page: () => const MachineSpecView(),
      binding: MachineSpecBinding(),
    ),
    GetPage(
      name: _Paths.WIRE_ROPE_SLING,
      page: () => const WireRopeSlingView(),
      binding: WireRopeSlingBinding(),
    ),
    GetPage(
      name: _Paths.SHAKLE_TRACKING,
      page: () => const ShakleTrackingView(),
      binding: ShakleTrackingBinding(),
    ),
    GetPage(
      name: _Paths.SPLASH,
      page: () => const SplashView(),
      binding: SplashBinding(),
    ),
    GetPage(
      name: _Paths.QUATATION_WIRE,
      page: () => const QuatationWireView(),
      binding: QuatationWireBinding(),
    ),
    GetPage(
      name: _Paths.STEEL_SLINGS,
      page: () => const SteelSlingsView(),
      binding: SteelSlingsBinding(),
    ),
    GetPage(
      name: _Paths.WIRE_ROPE_CLIPS,
      page: () => const WireRopeClipsView(),
      binding: WireRopeClipsBinding(),
    ),
    GetPage(
      name: _Paths.HOOK,
      page: () => const HookView(),
      binding: HookBinding(),
    ),
    GetPage(
      name: _Paths.SOCKET,
      page: () => const SocketView(),
      binding: SocketBinding(),
    ),
    GetPage(
      name: _Paths.TURN_BUCKLE,
      page: () => const TurnBuckleView(),
      binding: TurnBuckleBinding(),
    ),
    GetPage(
      name: _Paths.CONNECTION_LINK,
      page: () => const ConnectionLinkView(),
      binding: ConnectionLinkBinding(),
    ),
    GetPage(
      name: _Paths.LIFTING_EYE,
      page: () => const LiftingEyeView(),
      binding: LiftingEyeBinding(),
    ),
    GetPage(
      name: _Paths.LOAD_BINDER,
      page: () => const LoadBinderView(),
      binding: LoadBinderBinding(),
    ),
    GetPage(
      name: _Paths.CHAIN,
      page: () => const ChainView(),
      binding: ChainBinding(),
    ),
    GetPage(
      name: _Paths.CLUTCH,
      page: () => const ClutchView(),
      binding: ClutchBinding(),
    ),
    GetPage(
      name: _Paths.WIRE_ROPE_QUATATION,
      page: () => const WireRopeQuatationView(),
      binding: WireRopeQuatationBinding(),
    ),
    GetPage(
      name: _Paths.STEEL_QUATATION,
      page: () => const SteelQuatationView(),
      binding: SteelQuatationBinding(),
    ),
    GetPage(
      name: _Paths.STEEL_SLINGS_QUOTATION,
      page: () => const SteelSlingsQuotationView(),
      binding: SteelSlingsQuotationBinding(),
    ),
  ];

  AppPages._();
}
