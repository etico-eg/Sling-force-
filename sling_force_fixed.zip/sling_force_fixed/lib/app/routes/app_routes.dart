part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const HOME = _Paths.HOME;
  static const MACHINE_SPEC = _Paths.MACHINE_SPEC;
  static const WIRE_ROPE_SLING = _Paths.WIRE_ROPE_SLING;
  static const SHAKLE_TRACKING = _Paths.SHAKLE_TRACKING;
  static const SPLASH = _Paths.SPLASH;
  static const QUATATION_WIRE = _Paths.QUATATION_WIRE;
  static const STEEL_SLINGS = _Paths.STEEL_SLINGS;
  static const WIRE_ROPE_CLIPS = _Paths.WIRE_ROPE_CLIPS;
  static const HOOK = _Paths.HOOK;
  static const SOCKET = _Paths.SOCKET;
  static const TURN_BUCKLE = _Paths.TURN_BUCKLE;
  static const CONNECTION_LINK = _Paths.CONNECTION_LINK;
  static const LIFTING_EYE = _Paths.LIFTING_EYE;
  static const LOAD_BINDER = _Paths.LOAD_BINDER;
  static const CHAIN = _Paths.CHAIN;
  static const CLUTCH = _Paths.CLUTCH;
  static const WIRE_ROPE_QUATATION = _Paths.WIRE_ROPE_QUATATION;
  static const STEEL_QUATATION = _Paths.STEEL_QUATATION;
  static const STEEL_SLINGS_QUOTATION = _Paths.STEEL_SLINGS_QUOTATION;
}

abstract class _Paths {
  _Paths._();
  static const HOME = '/home';
  static const MACHINE_SPEC = '/machine-spec';
  static const WIRE_ROPE_SLING = '/wire-rope-sling';
  static const SHAKLE_TRACKING = '/shakle-tracking';
  static const SPLASH = '/splash';
  static const QUATATION_WIRE = '/quatation-wire';
  static const STEEL_SLINGS = '/steel-slings';
  static const WIRE_ROPE_CLIPS = '/wire-rope-clips';
  static const HOOK = '/hook';
  static const SOCKET = '/socket';
  static const TURN_BUCKLE = '/turn-buckle';
  static const CONNECTION_LINK = '/connection-link';
  static const LIFTING_EYE = '/lifting-eye';
  static const LOAD_BINDER = '/load-binder';
  static const CHAIN = '/chain';
  static const CLUTCH = '/clutch';
  static const WIRE_ROPE_QUATATION = '/wire-rope-quatation';
  static const STEEL_QUATATION = '/steel-quatation';
  static const STEEL_SLINGS_QUOTATION = '/steel-slings-quotation';
}
