import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:sling_force/constants/assets.dart';
import 'package:sling_force/utils/extensions.dart';
import 'package:sling_force/values/app_colors.dart';

import '../controllers/splash_controller.dart';

class SplashView extends GetView<SplashController> {
  const SplashView({super.key});
  @override
  Widget build(BuildContext context) {
    Get.put(SplashController());
    var theme = context.theme;
    return Scaffold(
      backgroundColor: AppColors.primaryColor,
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SvgPicture.asset(
                Assets.assetsSvgIconsLogo,
                color: Colors.white,
                width: context.widthFraction(sizeFraction: 0.5),
                height: context.widthFraction(sizeFraction: 0.5),
              ).animate().fade().slideY(
                  duration: const Duration(milliseconds: 500),
                  begin: 1,
                  curve: Curves.easeInSine),
              20.verticalSpace,
              Padding(
                padding: EdgeInsets.only(left: 30.w),
                child: Text.rich(
                  TextSpan(children: [
                    TextSpan(
                      text: 'Sling ',
                      style: theme.textTheme.displayMedium?.copyWith(
                        color: Colors.white,
                      ),
                    ),
                    TextSpan(
                      text: 'Force ',
                      style: theme.textTheme.displayMedium?.copyWith(
                        color: Colors.white,
                      ),
                    ),
                  ]),
                ).animate().fade().slideY(
                    duration: const Duration(milliseconds: 500),
                    begin: 5,
                    curve: Curves.easeInSine),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
