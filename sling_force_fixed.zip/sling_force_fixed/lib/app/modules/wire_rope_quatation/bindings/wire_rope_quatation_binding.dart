import 'package:get/get.dart';

import '../controllers/wire_rope_quatation_controller.dart';

class WireRopeQuatationBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<WireRopeQuatationController>(
      () => WireRopeQuatationController(),
    );
  }
}
