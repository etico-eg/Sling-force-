import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:getwidget/getwidget.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/utils/extensions.dart';
import 'package:sling_force/values/app_colors.dart';

import '../controllers/wire_rope_quatation_controller.dart';

class WireRopeQuatationView extends GetView<WireRopeQuatationController> {
  const WireRopeQuatationView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          toolbarHeight: 40,
          automaticallyImplyLeading: true,
          foregroundColor: Colors.white,
          // actions: [
          //   PopupMenuButton<String>(
          //     color: Colors.white,
          //     itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
          //       const PopupMenuItem<String>(
          //         value: 'profile_settings',
          //         child: Text('Profile Settings'),
          //       ),
          //       const PopupMenuItem<String>(
          //         value: 'sign_out',
          //         child: Text('Sign Out'),
          //       ),
          //     ],
          //     elevation: 8,
          //     onSelected: (String value) {
          //       if (value == 'sign_out') {
          //         Get.dialog(const SignOutDialog());
          //       } else {
          //         // Handle other menu options
          //       }
          //     },
          //     icon: const Icon(
          //       Icons.more_vert,
          //       color: Colors.white,
          //     ),
          //   ),
          // ],
          backgroundColor: const Color.fromARGB(255, 96, 10, 10),
          // title: Text('Machine Specs',
          //     style: TextStyle(
          //         color: Colors.white,
          //         fontSize: 20,
          //         fontFamily: GoogleFonts.ubuntu().fontFamily,
          //         fontWeight: FontWeight.normal)),
          // centerTitle: false,
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(50),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Webbings Slings Quotation',
                    style: GoogleFonts.ubuntu(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                  const Icon(
                    Icons.add,
                    color: Colors.white,
                  )
                ],
              ),
            ),
          )),
      body: SizedBox(
          height: context.heightFraction(sizeFraction: 1),
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: SizedBox(
              height: context.heightFraction(sizeFraction: 1),
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    children: [
                      GFTextFieldRounded(
                        style: GoogleFonts.ubuntu(
                            fontSize: 10, fontWeight: FontWeight.bold),
                        autofocus: true,
                        autocorrect: true,
                        autovalidate: true,
                        autoValidateMode: AutovalidateMode.onUserInteraction,
                        enableSuggestions: true,
                        keyboardType: TextInputType.number,
                        onChanged: (value) {},
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        editingbordercolor: AppColors.darkBlue,
                        idlebordercolor: AppColors.primaryColor,
                        borderwidth: 3,
                        cornerradius: 10,
                        hintText: 'Sling Width (mm)',
                      ),
                      GFTextFieldRounded(
                        style: GoogleFonts.ubuntu(
                            fontSize: 10, fontWeight: FontWeight.bold),
                        autofocus: true,
                        autocorrect: true,
                        autovalidate: true,
                        autoValidateMode: AutovalidateMode.onUserInteraction,
                        enableSuggestions: true,
                        keyboardType: TextInputType.number,
                        onChanged: (value) {},
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        editingbordercolor: AppColors.darkBlue,
                        idlebordercolor: AppColors.primaryColor,
                        borderwidth: 3,
                        cornerradius: 10,
                        hintText: 'Sling Length (mm)',
                      ),
                      GFTextFieldRounded(
                        style: GoogleFonts.ubuntu(
                            fontSize: 10, fontWeight: FontWeight.bold),
                        autofocus: true,
                        autocorrect: true,
                        autovalidate: true,
                        autoValidateMode: AutovalidateMode.onUserInteraction,
                        enableSuggestions: true,
                        keyboardType: TextInputType.number,
                        onChanged: (value) {},
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        editingbordercolor: AppColors.darkBlue,
                        idlebordercolor: AppColors.primaryColor,
                        borderwidth: 3,
                        cornerradius: 10,
                        hintText: 'MBL',
                      ),
                      GFTextFieldRounded(
                        style: GoogleFonts.ubuntu(
                            fontSize: 10, fontWeight: FontWeight.bold),
                        autofocus: true,
                        autocorrect: true,
                        autovalidate: true,
                        autoValidateMode: AutovalidateMode.onUserInteraction,
                        enableSuggestions: true,
                        keyboardType: TextInputType.number,
                        onChanged: (value) {},
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        editingbordercolor: AppColors.darkBlue,
                        idlebordercolor: AppColors.primaryColor,
                        borderwidth: 3,
                        cornerradius: 10,
                        hintText: 'Number of layers ',
                      ),
                      // Padding(
                      //   padding: const EdgeInsets.symmetric(
                      //       horizontal: 8.0, vertical: 8.0),
                      //   child: Container(
                      //     // height: 50,

                      //     decoration: BoxDecoration(
                      //       borderRadius: BorderRadius.circular(10),
                      //       border: Border.all(
                      //         color: AppColors.primaryColor,
                      //         width: 3,
                      //       ),
                      //     ),
                      //     child: GFDropdown(
                      //       padding: const EdgeInsets.symmetric(
                      //           horizontal: 10, vertical: 5),
                      //       elevation: 5,
                      //       iconSize: 25,
                      //       iconDisabledColor: AppColors.primaryColor,
                      //       iconEnabledColor: AppColors.primaryColor,
                      //       dropdownButtonColor: Colors.transparent,
                      //       hint: Text(
                      //         'Sling First End Fitting',
                      //         style: GoogleFonts.ubuntu(
                      //           fontSize: 10,
                      //           fontWeight: FontWeight.bold,
                      //         ),
                      //       ),
                      //       icon: const Icon(
                      //         Icons.arrow_drop_down,
                      //         color: AppColors.primaryColor,
                      //       ),
                      //       isExpanded: true,
                      //       items: const [
                      //         DropdownMenuItem(
                      //             value: 1,
                      //             child: Text(
                      //               'Standard Soft Eye',
                      //               style: TextStyle(color: Colors.black),
                      //             )),
                      //         DropdownMenuItem(
                      //             value: 2,
                      //             child: Text('Standard Thimble Eye',
                      //                 style: TextStyle(color: Colors.black))),
                      //         DropdownMenuItem(
                      //             value: 2,
                      //             child: Text('Sling Hook/Catch',
                      //                 style: TextStyle(color: Colors.black))),
                      //       ],
                      //       onChanged: (x) {},
                      //       style: GoogleFonts.ubuntu(
                      //         fontSize: 10,
                      //         fontWeight: FontWeight.bold,
                      //       ),
                      //       // dropdownButtonColor: Colors.white,
                      //     ),
                      //   ),
                      // ),
                      // Padding(
                      //   padding: const EdgeInsets.symmetric(
                      //       horizontal: 8.0, vertical: 8.0),
                      //   child: Container(
                      //     // height: 50,

                      //     decoration: BoxDecoration(
                      //       borderRadius: BorderRadius.circular(10),
                      //       border: Border.all(
                      //         color: AppColors.primaryColor,
                      //         width: 3,
                      //       ),
                      //     ),
                      //     child: GFDropdown(
                      //       padding: const EdgeInsets.symmetric(
                      //           horizontal: 10, vertical: 5),
                      //       elevation: 5,
                      //       iconSize: 25,
                      //       iconDisabledColor: AppColors.primaryColor,
                      //       iconEnabledColor: AppColors.primaryColor,
                      //       dropdownButtonColor: Colors.transparent,
                      //       hint: Text(
                      //         'Sling Second End Fitting',
                      //         style: GoogleFonts.ubuntu(
                      //           fontSize: 10,
                      //           fontWeight: FontWeight.bold,
                      //         ),
                      //       ),
                      //       icon: const Icon(
                      //         Icons.arrow_drop_down,
                      //         color: AppColors.primaryColor,
                      //       ),
                      //       isExpanded: true,
                      //       items: const [
                      //         DropdownMenuItem(
                      //             value: 1,
                      //             child: Text(
                      //               'Standard Soft Eye',
                      //               style: TextStyle(color: Colors.black),
                      //             )),
                      //         DropdownMenuItem(
                      //             value: 2,
                      //             child: Text('Standard Thimble Eye',
                      //                 style: TextStyle(color: Colors.black))),
                      //         DropdownMenuItem(
                      //             value: 2,
                      //             child: Text('Sling Hook/Catch',
                      //                 style: TextStyle(color: Colors.black))),
                      //       ],
                      //       onChanged: (x) {},
                      //       style: GoogleFonts.ubuntu(
                      //         fontSize: 10,
                      //         fontWeight: FontWeight.bold,
                      //       ),
                      //       // dropdownButtonColor: Colors.white,
                      //     ),
                      //   ),
                      // ),
                      // GFTextFieldRounded(
                      //   style: GoogleFonts.ubuntu(
                      //       fontSize: 10, fontWeight: FontWeight.bold),
                      //   autofocus: true,
                      //   autocorrect: true,
                      //   autovalidate: true,
                      //   autoValidateMode: AutovalidateMode.onUserInteraction,
                      //   enableSuggestions: true,
                      //   keyboardType: TextInputType.number,
                      //   onChanged: (value) {},
                      //   inputFormatters: [
                      //     FilteringTextInputFormatter.digitsOnly,
                      //   ],
                      //   editingbordercolor: AppColors.darkBlue,
                      //   idlebordercolor: AppColors.primaryColor,
                      //   borderwidth: 3,
                      //   cornerradius: 10,
                      //   hintText: 'Sling Working Load Limit (kg)',
                      // ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 8.0, horizontal: 32.0),
                        child: GFButton(
                            onPressed: () {},
                            blockButton: true,
                            type: GFButtonType.outline2x,
                            color: AppColors.primaryColor,
                            textStyle: GoogleFonts.ubuntu(
                                fontWeight: FontWeight.w500,
                                color: AppColors.primaryColor),
                            text: 'Request Quotation',
                            shape: GFButtonShape.pills),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          )),
    );
  }
}
