import 'package:get/get.dart';

class WireRopeQuatationController extends GetxController {
  //TODO: Implement WireRopeQuatationController

  final count = 0.obs;

  void increment() => count.value++;
}
