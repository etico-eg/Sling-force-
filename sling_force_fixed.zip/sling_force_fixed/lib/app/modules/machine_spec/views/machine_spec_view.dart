import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:getwidget/getwidget.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/utils/common_widgets/barcode_scanner_window.dart';
import 'package:sling_force/utils/common_widgets/app_dropdown.dart';
import 'package:sling_force/utils/common_widgets/nfc_scanner_sheet.dart';
import 'package:sling_force/utils/extensions.dart';
import 'package:sling_force/utils/helpers/snackbar_helper.dart';
import 'package:sling_force/values/app_colors.dart';

import '../controllers/machine_spec_controller.dart';
import 'package:sling_force/utils/common_widgets/tabbed_screen_wrapper.dart';

class MachineSpecView extends GetView<MachineSpecController> {
  const MachineSpecView({super.key});
  @override
  Widget build(BuildContext context) {
    print((Get.arguments as String?) ?? '');
    return TabbedScreenWrapper(
      title: 'Wire Rope',
      collection: 'wire_ropes',
      extraWhere: Get.arguments != null ? {'type': (Get.arguments as String?) ?? '' as String} : null,
      submitChild: Stack(
        children: [
          SizedBox(
                height: context.heightFraction(sizeFraction: 1),
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: SizedBox(
                    height: context.heightFraction(sizeFraction: 1),
                    child: SingleChildScrollView(
                      child: GfForm(
                        formkey: controller.formkey,
                        onFormSubmitted: (controller) {},
                        defaultSubmitButtonEnabled: false,
                        height: context.heightFraction(sizeFraction: 0.8),
                        formBorderColor: AppColors.primaryColor,
                        formfields: [
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Machine Serial Number :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            validator: (controller) {
                              if (controller == null || controller.isEmpty) {
                                return 'Please enter machine serial number';
                              }
                              return null;
                            },
                            controller: controller.serialController,
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            autocorrect: true,
                            autovalidate: true,
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            enableSuggestions: true,
                            keyboardType: TextInputType.text,
                            onChanged: (value) {},
                            inputFormatters: const [],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Machine Serial Number',
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Project Name :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            validator: (controller) {
                              // if (controller == null || controller.isEmpty) {
                              //   return 'Please enter project name';
                              // }
                              return null;
                            },
                            controller: controller.projectNameController,
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            autocorrect: true,
                            autovalidate: true,
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            enableSuggestions: true,
                            keyboardType: TextInputType.text,
                            onChanged: (value) {},
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Project Name',
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Wire Rope Core :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter wire rope core';
                              }
                              return null;
                            },
                            controller: controller.wireRopeCoreController,
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            autocorrect: true,
                            autovalidate: true,
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            enableSuggestions: true,
                            keyboardType: TextInputType.text,
                            onChanged: (value) {},
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Wire rope core',
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Lay Direction :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8.0, vertical: 8.0),
                            child: AppDropdown(
                              notifier: controller.layDirection,
                              hint: 'Select Lay Direction',
                              items: const [
                                'RHOL Right Hand Ordinary Lay',
                                'RHLL Right Hand Lang Lay',
                                'LHOL Left Hand Ordinary Lay',
                                'LHLL Left Hand Lang Lay',
                              ],
                              validator: (v) => v.isEmpty ? 'Please select lay direction' : null,
                            ),
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Finish :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8.0, vertical: 8.0),
                            child: AppDropdown(
                              notifier: controller.finish,
                              hint: 'Select Finish',
                              items: const [
                                'Drawn Galvanized',
                                'Bright',
                                'PVC Coated',
                              ],
                              validator: (v) => v.isEmpty ? 'Please select finish' : null,
                            ),
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Construction :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter construction';
                              }
                              return null;
                            },
                            controller: controller.constructionController,
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            autocorrect: true,
                            autovalidate: true,
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            enableSuggestions: true,
                            keyboardType: TextInputType.text,
                            onChanged: (value) {},
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Construction',
                          ),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              SizedBox(
                                height:
                                    context.heightFraction(sizeFraction: 0.15),
                                width:
                                    context.widthFraction(sizeFraction: 0.45),
                                child: Column(
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 5.0, vertical: 5),
                                      child: GFTypography(
                                        showDivider: false,
                                        text: "Wire Rope Diameter ",
                                        textColor: Colors.black87,
                                        type: GFTypographyType.typo5,
                                      ),
                                    ),
                                    SizedBox(
                                      width: context.widthFraction(
                                          sizeFraction: 0.45),
                                      child: GFTextFieldRounded(
                                        validator: (value) {
                                          if (value == null || value.isEmpty) {
                                            return 'Please enter diameter';
                                          }
                                          return null;
                                        },
                                        controller:
                                            controller.diameterController,
                                        style: GoogleFonts.ubuntu(
                                            fontSize: 10,
                                            fontWeight: FontWeight.bold),
                                        autofocus: true,
                                        autocorrect: true,
                                        autovalidate: true,
                                        autoValidateMode:
                                            AutovalidateMode.onUserInteraction,
                                        enableSuggestions: true,
                                        keyboardType: const TextInputType
                                            .numberWithOptions(decimal: true),
                                        onChanged: (value) {},
                                        inputFormatters: const [],
                                        editingbordercolor: AppColors.darkBlue,
                                        idlebordercolor: AppColors.primaryColor,
                                        borderwidth: 3,
                                        cornerradius: 10,
                                        hintText: 'Wire Rope Diameter',
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(
                                height: 50,
                                width: 3,
                                child: VerticalDivider(
                                  color: AppColors.primaryColor,
                                  thickness: 3,
                                  indent: 15,
                                ),
                              ),
                              SizedBox(
                                height:
                                    context.heightFraction(sizeFraction: 0.15),
                                width:
                                    context.widthFraction(sizeFraction: 0.45),
                                child: Column(
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 4.0, vertical: 5),
                                      child: GFTypography(
                                        showDivider: false,
                                        text: "Wire Rope Length ",
                                        textColor: Colors.black87,
                                        type: GFTypographyType.typo5,
                                      ),
                                    ),
                                    SizedBox(
                                      width: context.widthFraction(
                                          sizeFraction: 0.45),
                                      child: GFTextFieldRounded(
                                        validator: (value) {
                                          if (value == null || value.isEmpty) {
                                            return 'Please enter length';
                                          }
                                          return null;
                                        },
                                        controller: controller.lengthController,
                                        style: GoogleFonts.ubuntu(
                                            fontSize: 10,
                                            fontWeight: FontWeight.bold),
                                        autofocus: true,
                                        autocorrect: true,
                                        autovalidate: true,
                                        autoValidateMode:
                                            AutovalidateMode.onUserInteraction,
                                        enableSuggestions: true,
                                        keyboardType: const TextInputType
                                            .numberWithOptions(decimal: true),
                                        onChanged: (value) {},
                                        inputFormatters: const [],
                                        editingbordercolor: AppColors.darkBlue,
                                        idlebordercolor: AppColors.primaryColor,
                                        borderwidth: 3,
                                        cornerradius: 10,
                                        hintText: 'Wire Rope Length',
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 8, horizontal: 8),
                                child: GFButton(
                                    size: GFSize.LARGE,
                                    onPressed: () async {
                                      // clear the text fields
                                      Future.microtask(
                                        () async {
                                          // get the user company name from firestore
                                          await controller.track();
                                        },
                                      );
                                    },
                                    blockButton: false,
                                    type: GFButtonType.outline2x,
                                    color: AppColors.primaryColor,
                                    textStyle: GoogleFonts.ubuntu(
                                        fontWeight: FontWeight.w500,
                                        color: AppColors.primaryColor),
                                    text: 'Track',
                                    shape: GFButtonShape.pills),
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 8, horizontal: 8),
                                child: GFButton(
                                    size: GFSize.LARGE,
                                    onPressed: () async {
                                      await controller.writeData();
                                    },
                                    blockButton: false,
                                    type: GFButtonType.outline2x,
                                    color: AppColors.primaryColor,
                                    textStyle: GoogleFonts.ubuntu(
                                        fontWeight: FontWeight.w500,
                                        color: AppColors.primaryColor),
                                    text: 'Submit',
                                    shape: GFButtonShape.pills),
                              ),
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 8, horizontal: 8),
                                child: GFButton(
                                    size: GFSize.LARGE,
                                    onPressed: () {
                                      controller.clear();
                                    },
                                    blockButton: false,
                                    type: GFButtonType.outline2x,
                                    color: AppColors.primaryColor,
                                    textStyle: GoogleFonts.ubuntu(
                                        fontWeight: FontWeight.w500,
                                        color: AppColors.primaryColor),
                                    text: 'Clear',
                                    shape: GFButtonShape.pills),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              SizedBox(
                                width: context.widthFraction(sizeFraction: 0.4),
                                child: const GFTypography(
                                  showDivider: false,
                                  type: GFTypographyType.typo5,
                                  textColor: AppColors.primaryColor,
                                  text: 'Scan with qr code',
                                ),
                              ),
                              GFButton(
                                blockButton: false,
                                type: GFButtonType.outline2x,
                                color: AppColors.primaryColor,
                                shape: GFButtonShape.pills,
                                onPressed: () async {
                                  var result = await Get.to(
                                      () => BarcodeScannerWithScanWindow(
                                            controller: controller,
                                          ));

                                  print('result ' + result);
                                  if (result != null) {
                                    controller.isTracking.value = true;
                                    // context.loaderOverlay.show();
                                    result = result
                                        .split(' ')[0]
                                        .replaceAll(",", "");
                                    print(result);
                                    controller.serialController.text = result;
                                    await controller.trackOrSubmitBarCode(
                                        context: context);
                                    controller.isTracking.value = false;
                                  }
                                },
                                child: const Icon(
                                  Icons.qr_code,
                                  // size: 500,
                                  color: AppColors.primaryColor,
                                ),
                              ),
                              GFButton(
                                blockButton: false,
                                type: GFButtonType.outline2x,
                                color: AppColors.primaryColor,
                                shape: GFButtonShape.pills,
                                onPressed: () async {
                                  final result = await NfcScannerSheet.scan();
                                  if (result != null) {
                                    controller.isTracking.value = true;
                                    controller.serialController.text =
                                        result.split(' ')[0].replaceAll(',', '');
                                    await controller.trackOrSubmitBarCode(
                                        context: context);
                                    controller.isTracking.value = false;
                                  }
                                },
                                child: const Icon(
                                  Icons.nfc,
                                  color: AppColors.primaryColor,
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                )),
          Obx(() => controller.isTracking.isTrue
              ? Container(
                  color: Colors.white.withValues(alpha: 0.7),
                  child: const Center(
                    child: SpinKitCubeGrid(
                      color: AppColors.primaryColor,
                      size: 50.0,
                    ),
                  ),
                )
              : const SizedBox.shrink()),
        ],
      ),
    );;
  }
}
