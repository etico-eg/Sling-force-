import 'package:get/get.dart';

import '../controllers/machine_spec_controller.dart';

class MachineSpecBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<MachineSpecController>(
      () => MachineSpecController(),
    );
  }
}
