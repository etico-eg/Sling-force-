import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sling_force/services/firestore_service.dart';
import 'package:sling_force/utils/helpers/snackbar_helper.dart';

class MachineSpecController extends GetxController {
  final layDirection = ValueNotifier<String>('');
  final finish       = ValueNotifier<String>('');

  final serialController      = TextEditingController();
  final projectNameController = TextEditingController();
  final wireRopeCoreController = TextEditingController();
  final constructionController = TextEditingController();
  final diameterController    = TextEditingController();
  final lengthController      = TextEditingController();

  final formkey = GlobalKey<FormState>();
  RxBool isTracking = false.obs;

  clear() {
    projectNameController.clear();
    wireRopeCoreController.clear();
    lengthController.clear();
    diameterController.clear();
    constructionController.clear();
    finish.value = '';
    layDirection.value = '';
    update();
  }

  Future<bool> submit({required String companyName}) async {
    final colRef = FirestoreService.productCollection(companyName, 'wire_ropes');
    final query = colRef.where('serial', isEqualTo: serialController.text).where('type', isEqualTo: (Get.arguments as String?) ?? '');
    final docs = await query.get();
    if (docs.docs.isEmpty) {
      return (await Get.dialog<bool>(AlertDialog(
        title: const Text('Submit'),
        content: const Text('Are you sure you want to submit?'),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: const Text('No')),
          TextButton(onPressed: () => Get.back(result: true), child: const Text('Yes')),
        ],
      ))) ?? false;
    } else {
      return (await Get.dialog<bool>(AlertDialog(
        title: const Text('Serial Found'),
        content: const Text('Serial already exists. Override with current data?'),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: const Text('No')),
          TextButton(onPressed: () => Get.back(result: true), child: const Text('Yes')),
        ],
      ))) ?? false;
    }
  }

  Future<void> track() async {
    isTracking.value = true;
    try {
      final companyName = await FirestoreService.getCompanyName();
      final docs = await FirestoreService.productCollection(companyName, 'wire_ropes')
          .where('serial', isEqualTo: serialController.text)
          .where('type', isEqualTo: (Get.arguments as String?) ?? '')
          .get();
      if (docs.docs.isNotEmpty) {
        final data = docs.docs.first.data() as Map<String, dynamic>;
        projectNameController.text  = data['projectName']      ?? '';
        wireRopeCoreController.text = data['wireRopeCore']?.toString() ?? '';
        lengthController.text       = data['length']?.toString()       ?? '';
        diameterController.text     = data['wireRopeDiameter']?.toString() ?? '';
        constructionController.text = data['construction']?.toString() ?? '';
        finish.value                = data['finish']       ?? '';
        layDirection.value          = data['layDirection'] ?? '';
      }
    } finally {
      isTracking.value = false;
    }
  }

  Future<void> trackOrSubmitBarCode({required BuildContext context}) => track();

  Future<void> writeData() async {
    if (!formkey.currentState!.validate()) return;
    final confirmed = await Get.dialog<bool>(AlertDialog(
      title: const Text('Submit'),
      content: const Text('Are you sure you want to submit?'),
      actions: [
        TextButton(onPressed: () => Get.back(result: false), child: const Text('No')),
        TextButton(onPressed: () => Get.back(result: true), child: const Text('Yes')),
      ],
    ));
    if (confirmed != true) return;

    final companyName = await FirestoreService.getCompanyName();
    await FirestoreService.productCollection(companyName, 'wire_ropes')
        .doc(serialController.text)
        .set({
      ...FirestoreService.baseProductFields(companyId: companyName, category: (Get.arguments as String?) ?? 'wire_rope'),
      'serial':           serialController.text,
      'projectName':      projectNameController.text,
      'wireRopeCore':     wireRopeCoreController.text,
      'length':           lengthController.text,
      'wireRopeDiameter': diameterController.text,
      'construction':     constructionController.text,
      'finish':           finish.value,
      'layDirection':     layDirection.value,
      'type':             (Get.arguments as String?) ?? '',
    }, SetOptions(merge: true));

    clear();
    SnackbarHelper.showSnackBar('Wire rope saved successfully', isError: false);
  }
}
