import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sling_force/app/modules/home/views/intro_view.dart';

class HomeController extends GetxController {
  int currentIndex = 0;
  List<Widget> pages = [
    const IntroView(),
    const IntroView(
      screen: 'sling',
    ),
    const IntroView(screen: 'shakle'),
  ];
  void changePage(int index) async {
    currentIndex = index;
    update();
  }
}
