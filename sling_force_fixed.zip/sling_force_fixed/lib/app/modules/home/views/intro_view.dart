import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/app/modules/home/views/shakle_view.dart';
import 'package:sling_force/app/modules/home/views/sign_out.dart';
import 'package:sling_force/app/modules/home/views/sling_view.dart';
import 'package:sling_force/app/modules/home/views/wire_tracking_view.dart';
import 'package:sling_force/app/routes/app_pages.dart';
import 'package:sling_force/constants/assets.dart';
import 'package:sling_force/utils/common_widgets/invalid_route.dart';
import 'package:sling_force/utils/extensions.dart';

class IntroView extends GetView {
  final String screen;
  const IntroView({super.key, this.screen = "wire"});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: true,
        foregroundColor: Colors.white,
        leadingWidth: context.widthFraction(sizeFraction: 0.1),
        actions: [
          SvgPicture.asset(
            Assets.assetsSvgIconsLogo,
            color: Colors.white,
            width: context.widthFraction(sizeFraction: 0.15),
            height: context.widthFraction(sizeFraction: 0.15),
          ),
          SizedBox(
            width: context.widthFraction(sizeFraction: 0.25),
          ),
          PopupMenuButton<String>(
            color: Colors.white,
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              const PopupMenuItem<String>(
                value: 'profile_settings',
                child: Text('Profile Settings'),
              ),
              const PopupMenuItem<String>(
                value: 'sign_out',
                child: Text('Sign Out'),
              ),
            ],
            elevation: 8,
            onSelected: (String value) {
              if (value == 'sign_out') {
                Get.dialog(const SignOutDialog());
              } else {
                // Handle other menu options
              }
            },
            icon: const Icon(
              Icons.more_vert,
              color: Colors.white,
            ),
          ),
        ],
        backgroundColor: const Color.fromARGB(255, 96, 10, 10),
        title: Text(
            screen == 'sling'
                ? 'Slings'
                : screen == 'webbing_sling'
                    ? 'Webbing Slings'
                    : screen == 'steel_sling'
                        ? 'Steel Slings'
                        : screen == 'wire'
                            ? 'Wire Ropes'
                            : screen == 'shakle'
                                ? 'Shackles'
                                : 'Sling Force',
            style: TextStyle(
                fontSize: context.widthFraction(sizeFraction: 0.035),
                color: Colors.white,
                fontFamily: GoogleFonts.ubuntu().fontFamily,
                fontWeight: FontWeight.bold)),
        centerTitle: false,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: () {
                // switch on the screen string to navigate
                // get screen from constructor

                switch (screen) {
                  case "wire":
                    Get.to(() => const WireTrackingView());
                    break;
                  case "sling":
                    Get.to(() => const IntroView(screen: 'webbing_sling'));
                    break;
                  case "steel_sling":
                    Get.to(() => const SlingView());
                    break;
                  case "webbing_sling":
                    Get.toNamed(Routes.WIRE_ROPE_SLING,
                        arguments: 'webbing_sling');
                    break;
                  case "shakle":
                    Get.to(() => const ShakleView());
                    break;
                  default:
                    Get.to(() => const InvalidRoute());
                }
                // Get.to(() => const WireTrackingView());
              },
              child: SizedBox(
                width: context.widthFraction(sizeFraction: 0.55),
                height: context.heightFraction(sizeFraction: 0.3),
                child: Card(
                  color: Colors.white,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                      side: BorderSide(color: Colors.black, width: 2)),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      screen == "sling"
                          ? Image.asset(Assets.assetsImagesWebbingSling,
                              width: context.widthFraction(
                                sizeFraction: 0.3,
                              ),
                              height: context.widthFraction(sizeFraction: 0.3))
                          : SvgPicture.asset(
                              Assets.assetsSvgIconsTrack,
                              width: context.widthFraction(sizeFraction: 0.3),
                              height: context.widthFraction(sizeFraction: 0.3),
                              colorFilter: const ColorFilter.mode(
                                  Color.fromARGB(255, 114, 19, 12),
                                  BlendMode.srcIn),
                            ),
                      Text(
                        screen == "sling" ? 'Webbing Slings' : 'Tracking',
                        style: TextStyle(
                            color: Colors.black,
                            fontFamily: GoogleFonts.ubuntu().fontFamily,
                            fontWeight: FontWeight.bold,
                            fontSize:
                                context.widthFraction(sizeFraction: 0.04)),
                      )
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            GestureDetector(
              onTap: () {
                // switch on the screen string to navigate
                // get screen from constructor

                switch (screen) {
                  case "wire":
                    Get.toNamed(Routes.QUATATION_WIRE);
                    break;
                  case "sling":
                    Get.to(() => const IntroView(
                          screen: "steel_sling",
                        ));
                    break;
                  case "steel_sling":
                    Get.toNamed(Routes.STEEL_SLINGS_QUOTATION);
                    break;
                  case "webbing_sling":
                    Get.toNamed(Routes.WIRE_ROPE_QUATATION);
                    break;
                  case "shakle":
                    // Get.to(() => const ShakleView());
                    break;
                  default:
                    Get.to(() => const InvalidRoute());
                }
                // Get.to(() => const WireTrackingView());
              },
              child: SizedBox(
                width: context.widthFraction(sizeFraction: 0.55),
                height: context.heightFraction(sizeFraction: 0.3),
                child: Card(
                  color: Colors.white,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(20)),
                      side: BorderSide(color: Colors.black, width: 2)),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      screen == 'sling'
                          ? Image.asset(Assets.assetsImagesSteelLadle,
                              width: context.widthFraction(sizeFraction: 0.3),
                              height: context.widthFraction(sizeFraction: 0.3))
                          : SvgPicture.asset(
                              Assets.assetsSvgIconsQuotation,
                              theme: const SvgTheme(),
                              colorFilter: const ColorFilter.mode(
                                  Color.fromARGB(255, 114, 19, 12),
                                  BlendMode.srcIn),
                              // color: const Color.fromARGB(255, 114, 19, 12),
                              width: context.widthFraction(sizeFraction: 0.3),
                              height: context.widthFraction(sizeFraction: 0.3),
                            ),
                      Text(
                        screen == 'sling'
                            ? 'Steel Wire Slings'
                            : 'Request Quotation',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.black,
                            fontFamily: GoogleFonts.ubuntu().fontFamily,
                            fontWeight: FontWeight.bold,
                            fontSize:
                                context.widthFraction(sizeFraction: 0.04)),
                      )
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
