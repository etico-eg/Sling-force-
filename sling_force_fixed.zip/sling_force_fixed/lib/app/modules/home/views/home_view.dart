import 'package:curved_labeled_navigation_bar/curved_navigation_bar.dart';
import 'package:curved_labeled_navigation_bar/curved_navigation_bar_item.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:sling_force/constants/assets.dart';
import 'package:sling_force/screens/login_screen.dart';
import 'package:sling_force/screens/register_screen.dart';
import 'package:sling_force/utils/extensions.dart';
import 'package:sling_force/values/app_them.dart';

import '../controllers/home_controller.dart';

class HomeView extends GetView<HomeController> {
  const HomeView({super.key});
  @override
  Widget build(BuildContext context) {
    Get.put(HomeController());
    return Scaffold(
        backgroundColor: const Color.fromARGB(255, 96, 10, 10),
        bottomNavigationBar: FirebaseAuth.instance.currentUser != null
            ? CurvedNavigationBar(
                backgroundColor: const Color.fromARGB(255, 96, 10, 10),
                items: [
                  CurvedNavigationBarItem(
                      child: SvgPicture.asset(
                        Assets.assetsSvgIconsNounWire116163,
                        width: context.widthFraction(sizeFraction: 0.1),
                      ),
                      label: 'Wire Rope',
                      labelStyle: AppTheme.bodySmall.copyWith(
                          height: 0.5,
                          fontSize: context.widthFraction(sizeFraction: 0.033),
                          color: const Color.fromARGB(255, 96, 10, 10))),
                  CurvedNavigationBarItem(
                      child: SvgPicture.asset(
                        Assets.assetsSvgIconsSling,
                        width: context.widthFraction(sizeFraction: 0.1),
                      ),
                      label: 'Sling',
                      labelStyle: AppTheme.bodySmall.copyWith(
                          height: 0.5,
                          fontSize: context.widthFraction(sizeFraction: 0.033),
                          color: const Color.fromARGB(255, 96, 10, 10))),
                  CurvedNavigationBarItem(
                      child: SvgPicture.asset(
                        Assets.assetsSvgIconsHook,
                        width: context.widthFraction(sizeFraction: 0.1),
                      ),
                      label: 'Shackle&Hook',
                      labelStyle: AppTheme.bodySmall.copyWith(
                          height: 0.5,
                          fontSize: context.widthFraction(sizeFraction: 0.033),
                          color: const Color.fromARGB(255, 96, 10, 10))),
                ],
                onTap: (index) {
                  controller.currentIndex = index;
                  controller.update();
                },
              )
            : null,
        body: StreamBuilder<User?>(
          stream: FirebaseAuth.instance.authStateChanges(),
          builder: (BuildContext context, AsyncSnapshot<User?> snapshot) {
            // print(
            //     "triggered ${snapshot.connectionState}  ${snapshot.data?.email}");
            if (snapshot.hasData) {
              Get.lazyPut<HomeController>(() => HomeController());
              return GetBuilder<HomeController>(builder: (_) {
                return controller.pages[controller.currentIndex];
              });
            } else if (snapshot.hasError) {
              return const RegisterPage();
            } else {
              return const LoginPage();
            }
          },
        ));
  }
}
