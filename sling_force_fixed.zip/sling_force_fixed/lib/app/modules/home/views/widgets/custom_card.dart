import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/app/routes/app_pages.dart';
import 'package:sling_force/utils/extensions.dart';

class CustomCard extends StatelessWidget {
  final String text;
  final Widget image;
  final String path;
  final String? argument;

  const CustomCard(
      {super.key,
      required this.text,
      required this.image,
      this.argument,
      this.path = 'wire_tracking'});

  @override
  Widget build(BuildContext context) {
    // print(Get.arguments);
    return GestureDetector(
      onTap: () {
        switch (path) {
          case 'wire_tracking':
            Get.toNamed(Routes.MACHINE_SPEC, arguments: argument);
            break;
          case 'machine_spec':
            Get.toNamed(Routes.MACHINE_SPEC, arguments: argument);
            break;
          case 'sling_spec':
            Get.toNamed(Routes.STEEL_SLINGS, arguments: argument);
            break;
          case 'shakle_spec':
            Get.toNamed(Routes.SHAKLE_TRACKING, arguments: argument);
            break;
          case 'clips':
            Get.toNamed(Routes.WIRE_ROPE_CLIPS, arguments: argument);
            break;
          case 'hook':
            Get.toNamed(Routes.HOOK, arguments: argument);
            break;
          case 'socket':
            Get.toNamed(Routes.SOCKET, arguments: argument);
            break;
          case 'turn_buckle':
            Get.toNamed(Routes.TURN_BUCKLE, arguments: argument);
            break;
          case 'connection_link':
            Get.toNamed(Routes.CONNECTION_LINK, arguments: argument);
            break;
          case 'lifting_eye':
            Get.toNamed(Routes.LIFTING_EYE, arguments: argument);
            break;
          case 'load_binder':
            Get.toNamed(Routes.LOAD_BINDER, arguments: argument);
            break;
          case 'chain':
            Get.toNamed(Routes.CHAIN, arguments: argument);
            break;
          case 'clutch':
            Get.toNamed(Routes.CLUTCH, arguments: argument);
            break;

          // case 'settings':
          //   Get.toNamed(Routes.SETTINGS);
          //   break;
          default:
            Get.toNamed(Routes.MACHINE_SPEC, arguments: argument);
        }
        // Get.toNamed(Routes.MACHINE_SPEC);
      },
      child: SizedBox(
        height: context.heightFraction(sizeFraction: 0.14),
        child: Card(
          shadowColor: Colors.white,
          elevation: 0,
          color: Colors.white,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10)),
            side: BorderSide(color: Colors.black, width: 2),
          ),
          child: Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Row(
                  children: [
                    image,
                    const SizedBox(
                      width: 20,
                    ),
                    Text(
                      text,
                      style: TextStyle(
                        color: Colors.black,
                        fontFamily: GoogleFonts.ubuntu().fontFamily,
                        fontWeight: FontWeight.bold,
                        fontSize: context.widthFraction(sizeFraction: 0.035),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
