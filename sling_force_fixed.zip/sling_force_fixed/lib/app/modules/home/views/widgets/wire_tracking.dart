import 'package:flutter/material.dart';
import 'package:sling_force/screens/profile_screen.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/app/modules/home/views/sign_out.dart';
import 'package:sling_force/app/modules/home/views/widgets/custom_card.dart';
import 'package:sling_force/constants/assets.dart';
import 'package:sling_force/utils/extensions.dart';
import 'package:sling_force/values/app_them.dart';

class WireTracking extends StatefulWidget {
  const WireTracking({super.key});

  @override
  State<WireTracking> createState() => _WireTrackingState();
}

class _WireTrackingState extends State<WireTracking>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        foregroundColor: Colors.white,
        actions: [
          // three dots icon when pressed shows signout button
          IconButton(
            color: Colors.white,
            onPressed: () {
              PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'sign_out') {
                    Get.dialog(const SignOutDialog());
                  } else {
                    // Handle other menu options
                  }
                },
                itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                  const PopupMenuItem<String>(
                    value: 'profile_settings',
                    child: Text('Profile Settings'),
                  ),
                  const PopupMenuItem<String>(
                    value: 'sign_out',
                    child: Text('Sign Out'),
                  ),
                ],
                icon: const Icon(Icons.more_vert),
              );
            },
            icon: const Icon(Icons.more_vert),
          ),
        ],
        bottom: TabBar(
          // padding: const EdgeInsets.symmetric(horizontal: 5),
          physics: const BouncingScrollPhysics(),
          unselectedLabelColor: Colors.white54,
          unselectedLabelStyle: TextStyle(
              letterSpacing: 0.2,
              fontSize: context.widthFraction(sizeFraction: 0.025),
              fontWeight: FontWeight.bold,
              fontFamily: GoogleFonts.roboto().fontFamily),
          indicatorColor: Colors.white,
          labelStyle: TextStyle(
              fontSize: context.widthFraction(sizeFraction: 0.025),
              fontWeight: FontWeight.bold,
              fontFamily: GoogleFonts.roboto().fontFamily),
          indicatorSize: TabBarIndicatorSize.tab,
          indicatorPadding: const EdgeInsetsDirectional.symmetric(
              horizontal: 25, vertical: 3),
          indicatorWeight: 3,
          automaticIndicatorColorAdjustment: true,
          labelColor: Colors.white,
          controller: _tabController,
          tabs: const <Widget>[
            Tab(
              text: "Industrial \n  Cranes",
            ),
            Tab(
              text: "Construction \n    Cranes",
            ),
            Tab(text: "Port & Marines \n      Cranes"),
          ],
        ),
        backgroundColor: const Color.fromARGB(255, 96, 10, 10),
        title: Text('Wire Ropes',
            style: TextStyle(
                color: Colors.white,
                fontFamily: GoogleFonts.ubuntu().fontFamily,
                fontWeight: FontWeight.bold)),
        centerTitle: false,
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              children: [
                CustomCard(
                    text: "Overhead Hoist",
                    argument: "overhead_hoist",
                    image: Image.asset(
                      Assets.assetsImagesOverhead,
                      width: context.widthFraction(sizeFraction: 0.2),
                    )),
                const SizedBox(
                  height: 10,
                ),
                CustomCard(
                    text: "Steel Works Ladle/Charging \n Cranes",
                    argument: "steel_ladle",
                    image: Image.asset(
                      Assets.assetsImagesSteelLadle,
                      width: context.widthFraction(sizeFraction: 0.2),
                    )),
                const SizedBox(
                  height: 10,
                ),
                CustomCard(
                    text: "Steel Works Blast",
                    argument: "steel_blast",
                    image: Image.asset(
                      Assets.assetsImagesSteelBlast,
                      width: context.widthFraction(sizeFraction: 0.2),
                    )),
                const SizedBox(
                  height: 10,
                ),
                CustomCard(
                    text: "Cold Rolling/Looper Car",
                    argument: "cold_rolling",
                    image: Image.asset(
                      Assets.assetsImagesRolling,
                      width: context.widthFraction(sizeFraction: 0.2),
                      height: context.widthFraction(sizeFraction: 0.2),
                    )),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Crawler Cranes",
                    style: AppTheme.titleLarge.copyWith(
                        color: Colors.black38,
                        fontSize: context.widthFraction(sizeFraction: 0.05)),
                  ),
                  // line separator
                  const Divider(
                    color: Colors.black38,
                    thickness: 3,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustomCard(
                      text: "Lattice Boom Crane",
                      argument: "lattice_boom",
                      image: Image.asset(
                        Assets.assetsImagesLatticeBoom,
                        width: context.widthFraction(sizeFraction: 0.2),
                      )),
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    "Foundation Works",
                    style: AppTheme.titleLarge.copyWith(
                      color: Colors.black38,
                      fontSize: context.widthFraction(sizeFraction: 0.05),
                    ),
                  ),
                  // line separator
                  const Divider(
                    color: Colors.black38,
                    thickness: 3,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustomCard(
                      text: "Rotary Drilling Crane",
                      argument: "rotary_drilling",
                      image: Image.asset(
                        Assets.assetsImagesDrilling,
                        width: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "Piling Crane",
                      argument: "piling_crane",
                      image: Image.asset(
                        Assets.assetsImagesDrilling,
                        width: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "Diaphragm Walling Crane",
                      argument: "diaphragm_walling",
                      image: Image.asset(
                        Assets.assetsImagesDrilling,
                        width: context.widthFraction(sizeFraction: 0.2),
                      )),
                  const SizedBox(
                    height: 20,
                  ),
                  Text(
                    "Tower Cranes",
                    style: AppTheme.titleLarge.copyWith(
                        color: Colors.black38,
                        fontSize: context.widthFraction(sizeFraction: 0.05)),
                  ),
                  // line separator
                  const Divider(
                    color: Colors.black38,
                    thickness: 3,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustomCard(
                      text: "Flat Top Crane",
                      argument: "flat_top_crane",
                      image: Image.asset(
                        Assets.assetsImagesTowerCrane,
                        width: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "High Top Crane",
                      argument: "high_top_crane",
                      image: Image.asset(
                        Assets.assetsImagesTowerCrane,
                        width: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "Luffing Crane",
                      argument: "luffing_crane",
                      image: Image.asset(
                        Assets.assetsImagesTowerCrane,
                        width: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "Derrick Crane",
                      argument: "derrick_crane",
                      image: Image.asset(
                        Assets.assetsImagesTowerCrane,
                        width: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "Heavy Load Crane",
                      argument: "heavy_load_crane",
                      image: Image.asset(
                        Assets.assetsImagesTowerCrane,
                        width: context.widthFraction(sizeFraction: 0.2),
                      )),
                  const SizedBox(
                    height: 20,
                  ),
                  Text(
                    "Telescopic Mobile Cranes",
                    style: AppTheme.titleLarge.copyWith(
                        color: Colors.black38,
                        fontSize: context.widthFraction(sizeFraction: 0.05)),
                  ),
                  // line separator
                  const Divider(
                    color: Colors.black38,
                    thickness: 3,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustomCard(
                      text: "All Terrain Crane",
                      argument: "all_terrain_crane",
                      image: Image.asset(
                        Assets.assetsImagesTelescopic,
                        width: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "Telescopic Crane",
                      argument: "telescopic_crane",
                      image: Image.asset(
                        Assets.assetsImagesTelescopic,
                        width: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "Rough Terrain Crane",
                      argument: "rough_terrain_crane",
                      image: Image.asset(
                        Assets.assetsImagesTelescopic,
                        width: context.widthFraction(sizeFraction: 0.2),
                      )),
                  const SizedBox(
                    height: 20,
                  ),
                  Text(
                    "Truck Mounted Cranes",
                    style: AppTheme.titleLarge.copyWith(
                        color: Colors.black38,
                        fontSize: context.widthFraction(sizeFraction: 0.05)),
                  ),
                  // line separator
                  const Divider(
                    color: Colors.black38,
                    thickness: 3,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustomCard(
                      text: "Truck Mounted Crane",
                      argument: "truck_mounted_crane",
                      image: Image.asset(
                        Assets.assetsImagesDrilling,
                        width: context.widthFraction(sizeFraction: 0.2),
                      )),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Ship Cranes",
                    style: AppTheme.titleLarge.copyWith(
                        color: Colors.black38,
                        fontSize: context.widthFraction(sizeFraction: 0.05)),
                  ),
                  // line separator
                  const Divider(
                    color: Colors.black38,
                    thickness: 3,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustomCard(
                      text: "Pedestal Crane",
                      argument: "pedestal_crane",
                      image: Image.asset(
                        Assets.assetsImagesPedestal,
                        height: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "Knuckle Boom Crane",
                      argument: "knuckle_boom_crane",
                      image: Image.asset(
                        Assets.assetsImagesPedestal,
                        height: context.widthFraction(sizeFraction: 0.2),
                      )),
                  const SizedBox(
                    height: 20,
                  ),
                  Text(
                    "Ship Cranes",
                    style: AppTheme.titleLarge.copyWith(
                        color: Colors.black38,
                        fontSize: context.widthFraction(sizeFraction: 0.05)),
                  ),
                  // line separator
                  const Divider(
                    color: Colors.black38,
                    thickness: 3,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustomCard(
                      text: "Pedestal Crane",
                      argument: "pedestal_crane",
                      image: Image.asset(
                        Assets.assetsImagesPedestal,
                        height: context.widthFraction(sizeFraction: 0.2),
                      )),
                  const SizedBox(
                    height: 20,
                  ),
                  Text(
                    "Miscellaneous",
                    style: AppTheme.titleLarge.copyWith(
                        color: Colors.black38,
                        fontSize: context.widthFraction(sizeFraction: 0.05)),
                  ),
                  // line separator
                  const Divider(
                    color: Colors.black38,
                    thickness: 3,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustomCard(
                      text: "Mobile Harbour Crane",
                      argument: "mobile_harbour_crane",
                      image: Image.asset(
                        Assets.assetsImagesPedestal,
                        height: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "Ship to Shore Crane",
                      argument: "ship_to_shore_crane",
                      image: Image.asset(
                        Assets.assetsImagesPedestal,
                        height: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "Container Handler Crane",
                      argument: "container_handler_crane",
                      image: Image.asset(
                        Assets.assetsImagesPedestal,
                        height: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "Bulk Unloader Crane",
                      argument: "bulk_unloader_crane",
                      image: Image.asset(
                        Assets.assetsImagesPedestal,
                        height: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "Ship Lifter Crane",
                      argument: "ship_lifter_crane",
                      image: Image.asset(
                        Assets.assetsImagesPedestal,
                        height: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "Floating Crane",
                      argument: "floating_crane",
                      image: Image.asset(
                        Assets.assetsImagesPedestal,
                        height: context.widthFraction(sizeFraction: 0.2),
                      )),
                  CustomCard(
                      text: "Ship Derrick Crane",
                      argument: "ship_derrick_crane",
                      image: Image.asset(
                        Assets.assetsImagesPedestal,
                        height: context.widthFraction(sizeFraction: 0.2),
                      )),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }
}
