import 'package:flutter/material.dart';
import 'package:sling_force/screens/profile_screen.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/app/modules/home/views/sign_out.dart';
import 'package:sling_force/app/modules/home/views/widgets/custom_card.dart';
import 'package:sling_force/constants/assets.dart';
import 'package:sling_force/utils/extensions.dart';

class ShakleView extends GetView {
  const ShakleView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: true,
          foregroundColor: Colors.white,
          actions: [
            PopupMenuButton<String>(
              color: Colors.white,
              itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                const PopupMenuItem<String>(
                  value: 'profile_settings',
                  child: Text('Profile Settings'),
                ),
                const PopupMenuItem<String>(
                  value: 'sign_out',
                  child: Text('Sign Out'),
                ),
              ],
              elevation: 8,
              onSelected: (String value) {
                if (value == 'sign_out') {
                  Get.dialog(const SignOutDialog());
                } else {
                  // Handle other menu options
                }
              },
              icon: const Icon(
                Icons.more_vert,
                color: Colors.white,
              ),
            ),
          ],
          backgroundColor: const Color.fromARGB(255, 96, 10, 10),
          title: Text('Shackle',
              style: TextStyle(
                  fontSize: 20,
                  color: Colors.white,
                  fontFamily: GoogleFonts.ubuntu().fontFamily,
                  fontWeight: FontWeight.bold)),
          centerTitle: false,
        ),
        body: Padding(
          padding: const EdgeInsets.all(10.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                CustomCard(
                    path: 'shakle_spec',
                    text: 'Shackle',
                    argument: 'shackle',
                    image: Image.asset(
                      Assets.assetsImagesShackleReal,
                      height: context.heightFraction(sizeFraction: 0.1),
                      // color: Colors.transparent,
                    )),
                const SizedBox(
                  height: 10,
                ),
                CustomCard(
                    path: 'clips',
                    text: 'Wire Rope Clip',
                    argument: 'clips',
                    image: Image.asset(
                      Assets.assetsImagesWireRopeClip,
                      height: context.heightFraction(sizeFraction: 0.1),
                      // color: Colors.transparent,
                    )),
                const SizedBox(
                  height: 10,
                ),
                CustomCard(
                    path: 'hook',
                    text: 'Hook',
                    argument: 'hook',
                    image: Image.asset(
                      Assets.assetsImagesHookReal,
                      height: context.heightFraction(sizeFraction: 0.1),
                      // color: Colors.transparent,
                    )),
                const SizedBox(
                  height: 10,
                ),
                CustomCard(
                    path: 'socket',
                    text: 'Socket',
                    argument: 'socket',
                    image: Image.asset(
                      Assets.assetsImagesSocket,
                      height: context.heightFraction(sizeFraction: 0.1),
                      // color: Colors.transparent,
                    )),
                const SizedBox(
                  height: 10,
                ),
                CustomCard(
                  path: 'turn_buckle',
                  text: 'Turnbuckle',
                  argument: 'turn_buckle',
                  image: Image.asset(
                    Assets.assetsImagesTurnbuckle,
                    height: context.heightFraction(sizeFraction: 0.1),
                    width: context.heightFraction(sizeFraction: 0.1),
                    // color: Colors.transparent,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                CustomCard(
                  path: 'connection_link',
                  text: 'Connection Link',
                  argument: 'connection_link',
                  image: Image.asset(
                    Assets.assetsImagesConnectingLink,
                    height: context.heightFraction(sizeFraction: 0.1),
                    width: context.heightFraction(sizeFraction: 0.1),
                    // color: Colors.transparent,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                CustomCard(
                  path: 'lifting_eye',
                  text: 'Lifting Eye',
                  argument: 'lifting_eye',
                  image: Image.asset(
                    Assets.assetsImagesLiftingEye,
                    height: context.heightFraction(sizeFraction: 0.1),
                    width: context.heightFraction(sizeFraction: 0.1),
                    // color: Colors.transparent,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                CustomCard(
                  path: 'load_binder',
                  text: 'Load Binder',
                  argument: 'load_binder',
                  image: Image.asset(
                    Assets.assetsImagesLoadbinder,
                    height: context.heightFraction(sizeFraction: 0.1),
                    width: context.heightFraction(sizeFraction: 0.1),
                    // color: Colors.transparent,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                CustomCard(
                  path: 'chain',
                  text: 'Chain',
                  argument: 'chain',
                  image: Image.asset(
                    Assets.assetsImagesChain,
                    height: context.heightFraction(sizeFraction: 0.1),
                    width: context.heightFraction(sizeFraction: 0.1),
                    // color: Colors.transparent,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                CustomCard(
                  path: 'clutch',
                  text: 'Shortening Clutch',
                  argument: 'clutch',
                  image: Image.asset(
                    Assets.assetsImagesClutch,
                    height: context.heightFraction(sizeFraction: 0.1),
                    width: context.heightFraction(sizeFraction: 0.1),
                    // color: Colors.transparent,
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                // CustomCard(
                //   path: 'shakle_spec',
                //   text: 'Block',
                //   image: Image.asset(
                //     Assets.assetsImagesBlock,
                //     height: context.heightFraction(sizeFraction: 0.1),
                //     width: context.heightFraction(sizeFraction: 0.1),
                //     // color: Colors.transparent,
                //   ),
                // ),
                // const SizedBox(
                //   height: 10,
                // ),
              ],
            ),
          ),
        ));
  }
}
