import 'package:flutter/material.dart';
import 'package:sling_force/screens/profile_screen.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/app/modules/home/views/sign_out.dart';
import 'package:sling_force/app/modules/home/views/widgets/custom_card.dart';
import 'package:sling_force/constants/assets.dart';
import 'package:sling_force/utils/extensions.dart';

class SlingView extends GetView {
  const SlingView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // backgroundColor: Colors.white,
        appBar: AppBar(
          automaticallyImplyLeading: true,
          foregroundColor: Colors.white,
          actions: [
            PopupMenuButton<String>(
              color: Colors.white,
              itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
                const PopupMenuItem<String>(
                  value: 'profile_settings',
                  child: Text('Profile Settings'),
                ),
                const PopupMenuItem<String>(
                  value: 'sign_out',
                  child: Text('Sign Out'),
                ),
              ],
              elevation: 8,
              onSelected: (String value) {
                if (value == 'sign_out') {
                  Get.dialog(const SignOutDialog());
                } else {
                  // Handle other menu options
                }
              },
              icon: const Icon(
                Icons.more_vert,
                color: Colors.white,
              ),
            ),
          ],
          backgroundColor: const Color.fromARGB(255, 96, 10, 10),
          title: Text('Sling Force',
              style: TextStyle(
                  color: Colors.white,
                  fontFamily: GoogleFonts.ubuntu().fontFamily,
                  fontWeight: FontWeight.bold)),
          centerTitle: false,
        ),
        body: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            children: [
              CustomCard(
                  path: 'sling_spec',
                  argument: 'single_leg_wire_rope_sling',
                  text: 'Single Leg Wire Rope Sling',
                  image: Image.asset(
                    Assets.assetsImagesSingleLeg,
                    height: context.heightFraction(sizeFraction: 0.1),
                    // color: Colors.transparent,
                  )),
              const SizedBox(
                height: 10,
              ),
              CustomCard(
                  path: 'sling_spec',
                  argument: 'two_leg_wire_rope_sling',
                  text: 'Two Leg Wire Rope Sling',
                  image: Image.asset(
                    Assets.assetsImagesDoubleLeg,
                    height: context.heightFraction(sizeFraction: 0.1),
                    // color: Colors.transparent,
                  )),
              const SizedBox(
                height: 10,
              ),
              CustomCard(
                  text: 'Three Leg Wire Rope Sling',
                  path: 'sling_spec',
                  argument: 'three_leg_wire_rope_sling',
                  image: Image.asset(
                    Assets.assetsImagesTripleLeg,
                    height: context.heightFraction(sizeFraction: 0.1),
                    // color: Colors.transparent,
                  )),
              const SizedBox(
                height: 10,
              ),
              CustomCard(
                  text: 'Four Leg Wire Rope Sling',
                  path: 'sling_spec',
                  argument: 'four_leg_wire_rope_sling',
                  image: Image.asset(
                    Assets.assetsImagesQuadLeg,
                    height: context.heightFraction(sizeFraction: 0.1),
                    // color: Colors.transparent,
                  )),
              const SizedBox(
                height: 10,
              ),
              // CustomCard(
              //     path: 'sling_spec',
              //     text: 'Lifting Webbing Sling',
              //     image: Image.asset(
              //       Assets.assetsImagesWebbingSling,
              //       height: context.heightFraction(sizeFraction: 0.1),
              //       width: context.heightFraction(sizeFraction: 0.1),
              //       // color: Colors.transparent,
              //     )),
            ],
          ),
        ));
  }
}
