import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sling_force/app/modules/home/views/widgets/wire_tracking.dart';

class WireTrackingView extends GetView {
  const WireTrackingView({super.key});
  @override
  Widget build(BuildContext context) {
    return const WireTracking();
  }
}
