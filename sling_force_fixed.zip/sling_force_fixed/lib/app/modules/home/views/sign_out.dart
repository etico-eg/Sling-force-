import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sling_force/screens/login_screen.dart';
import 'package:sling_force/values/app_colors.dart';

class SignOutDialog extends StatefulWidget {
  const SignOutDialog({super.key});

  @override
  State<SignOutDialog> createState() => _SignOutDialogState();
}

class _SignOutDialogState extends State<SignOutDialog> {
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text(
        'Sign out',
        style: TextStyle(fontSize: 20, color: AppColors.primaryColor),
      ),
      content: const Text('Are you sure you want to sign out?'),
      actions: [
        TextButton(
          onPressed: () {
            FirebaseAuth.instance.signOut().then((value) {
              Get.offAll(() => const LoginPage());
            });
          },
          child: const Text(
            'Yes',
            style: TextStyle(color: AppColors.primaryColor),
          ),
        ),
        TextButton(
          onPressed: () {
            Get.back();
          },
          child:
              const Text('No', style: TextStyle(color: AppColors.primaryColor)),
        ),
      ],
    );
  }
}
