import 'package:get/get.dart';

import '../controllers/connection_link_controller.dart';

class ConnectionLinkBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ConnectionLinkController>(
      () => ConnectionLinkController(),
    );
  }
}
