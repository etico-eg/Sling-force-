import 'package:get/get.dart';

import '../controllers/socket_controller.dart';

class SocketBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<SocketController>(
      () => SocketController(),
    );
  }
}
