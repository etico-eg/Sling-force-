import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sling_force/values/app_colors.dart';

class QuatationWireController extends GetxController {
  RxString layDirection = 'Lay Direction'.obs;
  RxString finish = 'Finish'.obs;
  TextEditingController coreController = TextEditingController();
  TextEditingController constructionController = TextEditingController();
  TextEditingController lengthController = TextEditingController();
  TextEditingController diameterController = TextEditingController();
  TextEditingController typeController = TextEditingController();
  final formkey = GlobalKey<FormState>();
  RxBool isTracking = false.obs;

  clear() {
    coreController.clear();
    constructionController.clear();
    lengthController.clear();
    diameterController.clear();
    typeController.clear();
    finish.value = 'Finish';
    layDirection.value = 'Lay Direction';
    update();
  }

  submit() async {
    if (layDirection.value == 'Lay Direction') {
      return Get.snackbar('Error', 'Please Select Lay Direction',
          snackPosition: SnackPosition.BOTTOM,
          margin: const EdgeInsets.all(10),
          borderRadius: 10,
          colorText: Colors.white,
          duration: const Duration(seconds: 3),
          backgroundColor: Colors.red.shade900);
    }
    if (finish.value == 'Finish') {
      return Get.snackbar('Error', 'Please select finish of wire rope',
          snackPosition: SnackPosition.BOTTOM,
          margin: const EdgeInsets.all(10),
          borderRadius: 10,
          colorText: Colors.white,
          duration: const Duration(seconds: 3),
          backgroundColor: Colors.red.shade900);
    }
    var uid = FirebaseAuth.instance.currentUser!.uid;
    final user =
        await FirebaseFirestore.instance.collection('users').doc(uid).get();
    var companyName = user.data()!['companyName'];
    var name = user.data()!['name'];
    var email = user.data()!['email'];
    var position = user.data()!['position'];

    final colRef = FirebaseFirestore.instance
        .collection('companies/$companyName/wire_ropes')
        .doc('quotations')
        .collection('wire_ropes_quotations');

    await colRef.add({
      'core': coreController.text,
      'name': name,
      'email': email,
      'position': position,
      'construction': constructionController.text,
      'length': lengthController.text,
      'wireRopeDiameter': diameterController.text,
      'layDirection': layDirection.value,
      'finish': finish.value,
      'type': typeController.text,
    });
    Get.snackbar(
      'Quotation added succesfully',
      'Your quotation has been added successfully and will be reviewed by our team shortly.',
      snackPosition: SnackPosition.BOTTOM,
      margin: const EdgeInsets.all(10),
      backgroundColor: AppColors.primaryColor,
      colorText: Colors.white,
      borderRadius: 10,
      duration: const Duration(seconds: 3),
    );

    clear();
    //  snackbar.close();
  }
}
