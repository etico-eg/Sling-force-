import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getwidget/getwidget.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/utils/extensions.dart';
import 'package:sling_force/values/app_colors.dart';

import '../controllers/quatation_wire_controller.dart';

class QuatationWireView extends GetView<QuatationWireController> {
  const QuatationWireView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          toolbarHeight: 40,
          automaticallyImplyLeading: true,
          foregroundColor: Colors.white,
          // actions: [
          //   PopupMenuButton<String>(
          //     color: Colors.white,
          //     itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
          //       const PopupMenuItem<String>(
          //         value: 'profile_settings',
          //         child: Text('Profile Settings'),
          //       ),
          //       const PopupMenuItem<String>(
          //         value: 'sign_out',
          //         child: Text('Sign Out'),
          //       ),
          //     ],
          //     elevation: 8,
          //     onSelected: (String value) {
          //       if (value == 'sign_out') {
          //         Get.dialog(const SignOutDialog());
          //       } else {
          //         // Handle other menu options
          //       }
          //     },
          //     icon: const Icon(
          //       Icons.more_vert,
          //       color: Colors.white,
          //     ),
          //   ),
          // ],
          backgroundColor: const Color.fromARGB(255, 96, 10, 10),
          // title: Text('Machine Specs',
          //     style: TextStyle(
          //         color: Colors.white,
          //         fontSize: 20,
          //         fontFamily: GoogleFonts.ubuntu().fontFamily,
          //         fontWeight: FontWeight.normal)),
          // centerTitle: false,
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(50),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Wire Rope Quotation',
                    style: GoogleFonts.ubuntu(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                  const Icon(
                    Icons.add,
                    color: Colors.white,
                  )
                ],
              ),
            ),
          )),
      body: Obx(() {
        return SizedBox(
            height: context.heightFraction(sizeFraction: 1),
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: SizedBox(
                height: context.heightFraction(sizeFraction: 1),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: GfForm(
                    formkey: controller.formkey,
                    onFormSubmitted: (p0) {},
                    defaultSubmitButtonEnabled: false,
                    formfields: [
                      // GFTextFieldRounded(
                      //   style: GoogleFonts.ubuntu(
                      //       fontSize: 10, fontWeight: FontWeight.bold),
                      //   autofocus: true,
                      //   autocorrect: true,
                      //   autovalidate: true,
                      //   autoValidateMode: AutovalidateMode.onUserInteraction,
                      //   enableSuggestions: true,
                      //   keyboardType: TextInputType.number,
                      //   onChanged: (value) {},
                      //   inputFormatters: [
                      //     FilteringTextInputFormatter.digitsOnly,
                      //   ],
                      //   editingbordercolor: AppColors.darkBlue,
                      //   idlebordercolor: AppColors.primaryColor,
                      //   borderwidth: 3,
                      //   cornerradius: 10,
                      //   hintText: 'Machine Serial Number',
                      // ),
                      // GFTextFieldRounded(
                      //   style: GoogleFonts.ubuntu(
                      //       fontSize: 10, fontWeight: FontWeight.bold),
                      //   autofocus: true,
                      //   autocorrect: true,
                      //   autovalidate: true,
                      //   autoValidateMode: AutovalidateMode.onUserInteraction,
                      //   enableSuggestions: true,
                      //   keyboardType: TextInputType.number,
                      //   onChanged: (value) {},
                      //   inputFormatters: [
                      //     FilteringTextInputFormatter.digitsOnly,
                      //   ],
                      //   editingbordercolor: AppColors.darkBlue,
                      //   idlebordercolor: AppColors.primaryColor,
                      //   borderwidth: 3,
                      //   cornerradius: 10,
                      //   hintText: 'Project Name',
                      // ),
                      GFTextFieldRounded(
                        style: GoogleFonts.ubuntu(
                            fontSize: 10, fontWeight: FontWeight.bold),
                        autofocus: true,
                        autocorrect: true,
                        autovalidate: true,
                        autoValidateMode: AutovalidateMode.onUserInteraction,
                        enableSuggestions: true,
                        // keyboardType: TextInputType.number,
                        onChanged: (value) {},
                        inputFormatters: const [
                          // FilteringTextInputFormatter.digitsOnly,
                        ],
                        editingbordercolor: AppColors.darkBlue,
                        idlebordercolor: AppColors.primaryColor,
                        controller: controller.coreController,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Please enter wire core';
                          }
                          return null;
                        },
                        borderwidth: 3,
                        cornerradius: 10,
                        hintText: 'Wire core',
                      ),
                      GFTextFieldRounded(
                        style: GoogleFonts.ubuntu(
                            fontSize: 10, fontWeight: FontWeight.bold),
                        autofocus: true,
                        autocorrect: true,
                        autovalidate: true,
                        autoValidateMode: AutovalidateMode.onUserInteraction,
                        enableSuggestions: true,
                        // keyboardType: TextInputType.number,
                        onChanged: (value) {},
                        inputFormatters: const [
                          // FilteringTextInputFormatter.digitsOnly,
                        ],
                        editingbordercolor: AppColors.darkBlue,
                        idlebordercolor: AppColors.primaryColor,
                        controller: controller.typeController,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Please enter wire type';
                          }
                          return null;
                        },
                        borderwidth: 3,
                        cornerradius: 10,
                        hintText: 'Wire type',
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8.0, vertical: 8.0),
                        child: Container(
                          // height: 50,

                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: AppColors.primaryColor,
                              width: 3,
                            ),
                          ),
                          child: GFDropdown(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 5),
                            elevation: 5,
                            iconSize: 25,
                            iconDisabledColor: AppColors.primaryColor,
                            iconEnabledColor: AppColors.primaryColor,
                            dropdownButtonColor: Colors.transparent,
                            hint: Text(
                              controller.layDirection.value,
                              style: GoogleFonts.ubuntu(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            icon: const Icon(
                              Icons.arrow_drop_down,
                              color: AppColors.primaryColor,
                            ),
                            isExpanded: true,
                            items: const [
                              DropdownMenuItem(
                                  value: 1,
                                  child: Text(
                                    'RHOL Right Hand Ordinary Lay',
                                    style: TextStyle(color: Colors.black),
                                  )),
                              DropdownMenuItem(
                                  value: 2,
                                  child: Text('RHLL Right Hand Lang Lay',
                                      style: TextStyle(color: Colors.black))),
                              DropdownMenuItem(
                                  value: 2,
                                  child: Text('LHOL Left Hand Ordinary Lay',
                                      style: TextStyle(color: Colors.black))),
                              DropdownMenuItem(
                                  value: 2,
                                  child: Text('LHLL Left Hand Lang Lay',
                                      style: TextStyle(color: Colors.black))),
                            ],
                            onChanged: (x) {
                              controller.layDirection.value = switch (x) {
                                1 => 'RHOL Right Hand Ordinary Lay',
                                2 => 'RHLL Right Hand Lang Lay',
                                3 => 'LHOL Left Hand Ordinary Lay',
                                4 => 'LHLL Left Hand Lang Lay',
                                _ => 'Lay Direction',
                              };
                            },
                            style: GoogleFonts.ubuntu(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                            // dropdownButtonColor: Colors.white,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8.0, vertical: 8.0),
                        child: Container(
                          // height: 50,

                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: AppColors.primaryColor,
                              width: 3,
                            ),
                          ),
                          child: GFDropdown(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 5),
                            elevation: 5,
                            iconSize: 25,
                            iconDisabledColor: AppColors.primaryColor,
                            iconEnabledColor: AppColors.primaryColor,
                            dropdownButtonColor: Colors.transparent,
                            hint: Text(
                              controller.finish.value,
                              style: GoogleFonts.ubuntu(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            icon: const Icon(
                              Icons.arrow_drop_down,
                              color: AppColors.primaryColor,
                            ),
                            isExpanded: true,
                            items: const [
                              DropdownMenuItem(
                                  value: 1,
                                  child: Text(
                                    'Drawn Galvanised',
                                    style: TextStyle(color: Colors.black),
                                  )),
                              DropdownMenuItem(
                                  value: 2,
                                  child: Text('Bright',
                                      style: TextStyle(color: Colors.black))),
                              DropdownMenuItem(
                                  value: 2,
                                  child: Text('PVC Coated',
                                      style: TextStyle(color: Colors.black))),
                            ],
                            onChanged: (x) {
                              controller.finish.value = switch (x) {
                                1 => 'Drawn Galvanised',
                                2 => 'Bright',
                                3 => 'PVC Coated',
                                _ => 'Finish',
                              };
                            },
                            style: GoogleFonts.ubuntu(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                            // dropdownButtonColor: Colors.white,
                          ),
                        ),
                      ),
                      GFTextFieldRounded(
                        style: GoogleFonts.ubuntu(
                            fontSize: 10, fontWeight: FontWeight.bold),
                        autofocus: true,
                        autocorrect: true,
                        autovalidate: true,
                        autoValidateMode: AutovalidateMode.onUserInteraction,
                        enableSuggestions: true,
                        // keyboardType: TextInputType.number,
                        controller: controller.constructionController,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter construction';
                          }
                          return null;
                        },
                        onChanged: (value) {},
                        inputFormatters: const [
                          // FilteringTextInputFormatter.digitsOnly,
                        ],
                        editingbordercolor: AppColors.darkBlue,
                        idlebordercolor: AppColors.primaryColor,
                        borderwidth: 3,
                        cornerradius: 10,
                        hintText: 'Construction',
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          SizedBox(
                            width: context.widthFraction(sizeFraction: 0.40),
                            child: GFTextFieldRounded(
                              style: GoogleFonts.ubuntu(
                                  fontSize: 10, fontWeight: FontWeight.bold),
                              autofocus: true,
                              autocorrect: true,
                              autovalidate: true,
                              autoValidateMode:
                                  AutovalidateMode.onUserInteraction,
                              enableSuggestions: true,
                              controller: controller.diameterController,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter diameter';
                                }
                                return null;
                              },
                              keyboardType:
                                  const TextInputType.numberWithOptions(
                                      signed: true, decimal: true),
                              onChanged: (value) {},
                              inputFormatters: const [
                                // FilteringTextInputFormatter.digitsOnly,
                              ],
                              editingbordercolor: AppColors.darkBlue,
                              idlebordercolor: AppColors.primaryColor,
                              borderwidth: 3,
                              cornerradius: 10,
                              hintText: 'Wire Rope Diameter',
                            ),
                          ),
                          const SizedBox(
                            height: 50,
                            child: VerticalDivider(
                              color: AppColors.primaryColor,
                              thickness: 3,
                              indent: 3,
                              width: 3,
                              endIndent: 10,
                            ),
                          ),
                          SizedBox(
                            width: context.widthFraction(sizeFraction: 0.40),
                            child: GFTextFieldRounded(
                              style: GoogleFonts.ubuntu(
                                  fontSize: 10, fontWeight: FontWeight.bold),
                              autofocus: true,
                              controller: controller.lengthController,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter length';
                                }
                                return null;
                              },
                              autocorrect: true,
                              autovalidate: true,
                              autoValidateMode:
                                  AutovalidateMode.onUserInteraction,
                              enableSuggestions: true,
                              keyboardType:
                                  const TextInputType.numberWithOptions(
                                      decimal: true),
                              onChanged: (value) {},
                              inputFormatters: const [
                                // FilteringTextInputFormatter.digitsOnly,
                              ],
                              editingbordercolor: AppColors.darkBlue,
                              idlebordercolor: AppColors.primaryColor,
                              borderwidth: 3,
                              cornerradius: 10,
                              hintText: 'Wire Rope Length',
                            ),
                          )
                        ],
                      ),
                      // GFTextFieldRounded(
                      //   style: GoogleFonts.ubuntu(
                      //       fontSize: 10, fontWeight: FontWeight.bold),
                      //   autofocus: true,
                      //   autocorrect: true,
                      //   autovalidate: true,
                      //   autoValidateMode: AutovalidateMode.onUserInteraction,
                      //   enableSuggestions: true,
                      //   keyboardType: TextInputType.number,
                      //   onChanged: (value) {},
                      //   inputFormatters: [
                      //     FilteringTextInputFormatter.digitsOnly,
                      //   ],
                      //   editingbordercolor: AppColors.darkBlue,
                      //   idlebordercolor: AppColors.primaryColor,
                      //   borderwidth: 3,
                      //   cornerradius: 10,
                      //   hintText: 'Current Machine Hours',
                      // ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 8.0, horizontal: 32.0),
                        child: GFButton(
                            onPressed: () async {
                              if (!controller.formkey.currentState!
                                  .validate()) {
                                return;
                              }

                              controller.submit();
                            },
                            blockButton: true,
                            type: GFButtonType.outline2x,
                            color: AppColors.primaryColor,
                            textStyle: GoogleFonts.ubuntu(
                                fontWeight: FontWeight.w500,
                                color: AppColors.primaryColor),
                            text: 'Submit',
                            shape: GFButtonShape.pills),
                      ),
                    ],
                  ),
                ),
              ),
            ));
      }),
    );
  }
}
