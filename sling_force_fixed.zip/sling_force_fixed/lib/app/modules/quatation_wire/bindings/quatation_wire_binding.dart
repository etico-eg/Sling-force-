import 'package:get/get.dart';

import '../controllers/quatation_wire_controller.dart';

class QuatationWireBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<QuatationWireController>(
      () => QuatationWireController(),
    );
  }
}
