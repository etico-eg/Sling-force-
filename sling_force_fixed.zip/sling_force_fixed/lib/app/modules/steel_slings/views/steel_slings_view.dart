import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:getwidget/getwidget.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/utils/common_widgets/barcode_scanner_window.dart';
import 'package:sling_force/utils/common_widgets/app_dropdown.dart';
import 'package:sling_force/utils/common_widgets/nfc_scanner_sheet.dart';
import 'package:sling_force/utils/extensions.dart';
import 'package:sling_force/utils/helpers/snackbar_helper.dart';
import 'package:sling_force/values/app_colors.dart';

import '../controllers/steel_slings_controller.dart';
import 'package:sling_force/utils/common_widgets/tabbed_screen_wrapper.dart';

class SteelSlingsView extends GetView<SteelSlingsController> {
  const SteelSlingsView({super.key});
  @override
  Widget build(BuildContext context) {
    return TabbedScreenWrapper(
      title: 'Steel Wire Slings',
      collection: 'steel_wire_sling',
      submitChild: Stack(
        children: [
          SizedBox(
                height: context.heightFraction(sizeFraction: 1),
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: SizedBox(
                    height: context.heightFraction(sizeFraction: 1),
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: GfForm(
                        formkey: controller.formKey,
                        onFormSubmitted: (value) {},
                        defaultSubmitButtonEnabled: false,
                        formfields: [
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Serial Number :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            controller: controller.serialController,
                            autocorrect: true,
                            autovalidate: true,
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            enableSuggestions: true,
                            keyboardType: TextInputType.text,
                            onChanged: (value) {},
                            inputFormatters: const [
                              // FilteringTextInputFormatter.digitsOnly,
                            ],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Serial Number',
                            validator: (controller) {
                              if (controller == null || controller.isEmpty) {
                                return 'Please enter Serial Number';
                              }
                              return null;
                            },
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Project Name :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            controller: controller.projectNameController,
                            autocorrect: true,
                            autovalidate: true,
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            enableSuggestions: true,
                            keyboardType: TextInputType.text,
                            onChanged: (value) {},
                            inputFormatters: const [
                              // FilteringTextInputFormatter.digitsOnly,
                            ],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Project Name : ( optional )',
                            validator: (controller) {
                              // if (controller == null || controller.isEmpty) {
                              //   return 'Please enter Serial Number';
                              // }
                              return null;
                            },
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Purchase Order # :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            controller: controller.purchaseOrderController,
                            autocorrect: true,
                            autovalidate: true,
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            enableSuggestions: true,
                            keyboardType: TextInputType.text,
                            onChanged: (value) {},
                            inputFormatters: const [
                              // FilteringTextInputFormatter.digitsOnly,
                            ],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Purchase Order # ( optional )',
                            validator: (controller) {
                              // if (controller == null || controller.isEmpty) {
                              //   return 'Please enter Serial Number';
                              // }
                              return null;
                            },
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "MBL :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            controller: controller.mblController,
                            autocorrect: true,
                            autovalidate: true,
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            enableSuggestions: true,
                            keyboardType: TextInputType.text,
                            onChanged: (value) {},
                            inputFormatters: const [
                              // FilteringTextInputFormatter.digitsOnly,
                            ],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'MBL',
                            validator: (controller) {
                              if (controller == null || controller.isEmpty) {
                                return 'Please enter MBL';
                              }
                              return null;
                            },
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Working Date :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GestureDetector(
                            onTap: () async {
                              final picked = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(1900),
                                lastDate: DateTime(2100),
                              );
                              if (picked != null &&
                                  picked != controller.workingDate) {
                                controller.workingDate = picked;
                              }
                            },
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 8.0),
                              child: Row(
                                children: [
                                  IconButton(
                                    icon: const Icon(Icons.calendar_today,
                                        color: Colors.black87),
                                    onPressed: () async {
                                      final picked = await showDatePicker(
                                        context: context,
                                        initialDate: DateTime.now(),
                                        firstDate: DateTime(1900),
                                        lastDate: DateTime(2100),
                                      );
                                      if (picked != null &&
                                          picked != controller.workingDate) {
                                        controller.workingDate = picked;
                                      }
                                    },
                                  ),
                                  Text(
                                    controller.workingDate != null
                                        ? '${controller.workingDate?.day}/${controller.workingDate?.month}/${controller.workingDate?.year}'
                                        : 'Not Set',
                                    style:
                                        const TextStyle(color: Colors.black87),
                                  )
                                ],
                              ),
                            ),
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Diameter :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            autocorrect: true,
                            autovalidate: true,
                            controller: controller.diameterController,
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            enableSuggestions: true,
                            keyboardType: const TextInputType.numberWithOptions(
                                decimal: true),
                            onChanged: (value) {},
                            inputFormatters: const [
                              // FilteringTextInputFormatter.digitsOnly,
                            ],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Diameter',
                            validator: (controller) {
                              if (controller == null || controller.isEmpty) {
                                return 'Please enter diameter';
                              }
                              return null;
                            },
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Length :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            autocorrect: true,
                            autovalidate: true,
                            controller: controller.lengthController,
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            enableSuggestions: true,
                            keyboardType: const TextInputType.numberWithOptions(
                                decimal: true),
                            onChanged: (value) {},
                            inputFormatters: const [
                              // FilteringTextInputFormatter.digitsOnly,
                            ],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Length',
                            validator: (controller) {
                              if (controller == null || controller.isEmpty) {
                                return 'Please enter length';
                              }
                              return null;
                            },
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Eye Dimensions :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            autocorrect: true,
                            autovalidate: true,
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            enableSuggestions: true,
                            keyboardType: TextInputType.text,
                            controller: controller.eyeDimensionsController,
                            onChanged: (value) {},
                            inputFormatters: const [
                              // FilteringTextInputFormatter.digitsOnly,
                            ],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Eye dimensions',
                            validator: (controller) {
                              if (controller == null || controller.isEmpty) {
                                return 'Please enter eye dimensions';
                              }
                              return null;
                            },
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Steel Sling Type :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8.0, vertical: 8.0),
                            child: AppDropdown(
                              notifier: controller.slingType,
                              hint: 'Select Sling Type',
                              items: const [
                                'Hand spliced',
                                'Mechanically spliced',
                              ],
                              validator: (v) => v.isEmpty ? 'Please select sling type' : null,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8.0, vertical: 8.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                // text
                                Text(
                                  'With thimble ',
                                  style: GoogleFonts.ubuntu(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.black.withValues(alpha: 0.8)),
                                ),
                                GFCheckbox(
                                    validator: (value) {
                                      if (value == null) {
                                        return 'Please select thimble';
                                      }
                                      return null;
                                    },
                                    onChanged: (v) {
                                      controller.withThimble.value = v;
                                    },
                                    value: controller.withThimble.value,
                                    size: GFSize.SMALL,
                                    activeBgColor: AppColors.primaryColor,
                                    inactiveBorderColor: AppColors.primaryColor,
                                    activeBorderColor: AppColors.primaryColor,
                                    type: GFCheckboxType.circle),
                              ],
                            ),
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 8.0, vertical: 5),
                            child: GFTypography(
                              showDivider: false,
                              text: "Core :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8.0, vertical: 8.0),
                            child: AppDropdown(
                              notifier: controller.core,
                              hint: 'Select Core',
                              items: const [
                                'Steel core',
                                'Fibre core',
                              ],
                              validator: (v) => v.isEmpty ? 'Please select core' : null,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 8.0, horizontal: 32.0),
                            child: GFButton(
                                onPressed: () async {
                                  var uid =
                                      FirebaseAuth.instance.currentUser!.uid;
                                  final user = await FirebaseFirestore.instance
                                      .collection('users')
                                      .doc(uid)
                                      .get();
                                  var companyName = user.data()!['companyName'];

                                  final colRef = FirebaseFirestore.instance
                                      .collection(
                                          'companies/$companyName/steel_wire_sling');

                                  final docRef = await colRef
                                      .where('serial',
                                          isEqualTo:
                                              controller.serialController.text)
                                      .get();
                                  if (docRef.docs.isNotEmpty) {
                                    final document = docRef.docs.first;

                                    final data = document.data();
                                    final diameter = data['slingDiameter'];
                                    final eyeDimensions = data['eyeDimensions'];
                                    final slingType = data['slingType'];
                                    final mbl = data['MBL'];
                                    final core = data['core'];
                                    final withThimble = data['withThimble'];

                                    final length = data['length'];

                                    controller.diameterController.text =
                                        diameter;
                                    controller.eyeDimensionsController.text =
                                        eyeDimensions;
                                    controller.slingType.value = slingType;
                                    controller.core.value = core;
                                    controller.mblController.text = mbl;
                                    controller.withThimble.value = withThimble;

                                    controller.purchaseOrderController.text =
                                        data['purchaseOrder'] ?? '';
                                    controller.projectNameController.text =
                                        data['projectName'] ?? '';
                                    controller.lengthController.text = length;

                                    controller.workingDate =
                                        DateTime.fromMillisecondsSinceEpoch(
                                            data['workingDate']
                                                .millisecondsSinceEpoch);
                                  }
                                },
                                blockButton: true,
                                type: GFButtonType.outline2x,
                                color: AppColors.primaryColor,
                                textStyle: GoogleFonts.ubuntu(
                                    fontWeight: FontWeight.w500,
                                    color: AppColors.primaryColor),
                                text: 'Track',
                                shape: GFButtonShape.pills),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 8.0, horizontal: 32.0),
                            child: GFButton(
                                onPressed: () async {
                                  if (!controller.formKey.currentState!
                                      .validate()) {
                                    return;
                                  }
                                  var uid =
                                      FirebaseAuth.instance.currentUser!.uid;
                                  // get  the user company name from firestore
                                  var user = await FirebaseFirestore.instance
                                      .collection('users')
                                      .doc(uid)
                                      .get();
                                  var companyName = user.data()!['companyName'];
                                  if (await controller.submit(
                                      companyName: companyName)) {
                                    // get current user uid

                                    // submit the data to firestore and show success message
                                    FirebaseFirestore.instance
                                        .collection(
                                            'companies/$companyName/steel_wire_sling')
                                        .doc(controller.serialController.text)
                                        .set({
                                      'serial':
                                          controller.serialController.text,
                                      'purchaseOrder': controller
                                          .purchaseOrderController.text,
                                      'projectName':
                                          controller.projectNameController.text,
                                      'MBL': controller.mblController.text,
                                      'length':
                                          controller.lengthController.text,
                                      'slingDiameter':
                                          controller.diameterController.text,
                                      'eyeDimensions': controller
                                          .eyeDimensionsController.text,
                                      'slingType': controller.slingType.value,
                                      'core': controller.core.value,
                                      'withThimble':
                                          controller.withThimble.value,
                                      'type': (Get.arguments as String?) ?? '',
                                      'workingDate':
                                          controller.workingDate ?? 'Not Set',
                                    }, SetOptions(merge: true));
                                    controller.formKey.currentState!.reset();
                                    Get.back();

                                    SnackbarHelper.showSnackBar(
                                        'Added Successfully',
                                        isError: false);
                                  }
                                },
                                blockButton: true,
                                type: GFButtonType.outline2x,
                                color: AppColors.primaryColor,
                                textStyle: GoogleFonts.ubuntu(
                                    fontWeight: FontWeight.w500,
                                    color: AppColors.primaryColor),
                                text: 'Submit',
                                shape: GFButtonShape.pills),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              SizedBox(
                                width: context.widthFraction(sizeFraction: 0.4),
                                child: const GFTypography(
                                  showDivider: false,
                                  type: GFTypographyType.typo5,
                                  textColor: AppColors.primaryColor,
                                  text: 'Scan with qr code',
                                ),
                              ),
                              GFButton(
                                blockButton: false,
                                type: GFButtonType.outline2x,
                                color: AppColors.primaryColor,
                                shape: GFButtonShape.pills,
                                onPressed: () async {
                                  var result = await Get.to(
                                      () => BarcodeScannerWithScanWindow(
                                            controller: controller,
                                          ));

                                  print('result ' + result);
                                  if (result != null) {
                                    // controller.isTracking.value = true;
                                    // context.loaderOverlay.show();
                                    final splitResult = result.split(' ');

                                    final serial =
                                        splitResult[0].replaceAll(",", "");
                                    print(serial);
                                    controller.serialController.text = serial;
                                    final mbl = splitResult.length > 1
                                        ? splitResult[1].replaceAll(",", "")
                                        : null;
                                    final width = splitResult.length > 2
                                        ? splitResult[2].replaceAll(",", "")
                                        : null;
                                    final length = splitResult.length > 3
                                        ? splitResult[3].replaceAll(",", "")
                                        : null;
                                    final purchaseOrder = splitResult.length > 4
                                        ? splitResult[4].replaceAll(",", "")
                                        : null;
                                    final projectName = splitResult.length > 5
                                        ? splitResult[5].replaceAll(",", "")
                                        : null;
                                    if (mbl == null ||
                                        width == null ||
                                        length == null) {
                                      Get.dialog(AlertDialog(
                                        title: const Text('Error'),
                                        content: const Text('Invalid QR Code'),
                                        actions: <Widget>[
                                          TextButton(
                                            onPressed: () {
                                              Get.back();
                                            },
                                            child: const Text('OK'),
                                          ),
                                        ],
                                      ));
                                      return;
                                    }

                                    controller.mblController.text = mbl;
                                    controller.diameterController.text =
                                        (width + length) * 2;

                                    controller.purchaseOrderController.text =
                                        purchaseOrder ?? '';
                                    controller.projectNameController.text =
                                        projectName ?? '';

                                    await controller.track();
                                    // controller.isTracking.value = false;
                                  }
                                },
                                child: const Icon(
                                  Icons.qr_code,
                                  // size: 500,
                                  color: AppColors.primaryColor,
                                ),
                              ),
                              GFButton(
                                blockButton: false,
                                type: GFButtonType.outline2x,
                                color: AppColors.primaryColor,
                                shape: GFButtonShape.pills,
                                onPressed: () async {
                                  final result = await NfcScannerSheet.scan();
                                  if (result != null) {
                                    final splitResult = result.split(' ');
                                    final serial = splitResult[0].replaceAll(',', '');
                                    controller.serialController.text = serial;
                                    final mbl = splitResult.length > 1 ? splitResult[1].replaceAll(',', '') : null;
                                    final purchaseOrder = splitResult.length > 4 ? splitResult[4].replaceAll(',', '') : null;
                                    final projectName = splitResult.length > 5 ? splitResult[5].replaceAll(',', '') : null;
                                    if (mbl != null) controller.mblController.text = mbl;
                                    if (purchaseOrder != null) controller.purchaseOrderController.text = purchaseOrder;
                                    if (projectName != null) controller.projectNameController.text = projectName;
                                    await controller.track();
                                  }
                                },
                                child: const Icon(
                                  Icons.nfc,
                                  color: AppColors.primaryColor,
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                )),
          Obx(() => controller.isTracking.isTrue
              ? Container(
                  color: Colors.white.withValues(alpha: 0.7),
                  child: const Center(
                    child: SpinKitCubeGrid(
                      color: AppColors.primaryColor,
                      size: 50.0,
                    ),
                  ),
                )
              : const SizedBox.shrink()),
        ],
      ),
    );;
  }
}
