import 'package:get/get.dart';

import '../controllers/steel_slings_controller.dart';

class SteelSlingsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<SteelSlingsController>(
      () => SteelSlingsController(),
    );
  }
}
