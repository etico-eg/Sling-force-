import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sling_force/services/firestore_service.dart';
import 'package:sling_force/utils/helpers/snackbar_helper.dart';

class SteelSlingsController extends GetxController {
  RxBool   withThimble = false.obs;
  final slingType = ValueNotifier<String>('');
  final core      = ValueNotifier<String>('');

  final formKey                = GlobalKey<FormState>();
  final diameterController     = TextEditingController();
  final eyeDimensionsController = TextEditingController();
  final serialController       = TextEditingController();
  final mblController          = TextEditingController();
  final purchaseOrderController = TextEditingController();
  final projectNameController  = TextEditingController();
  final lengthController       = TextEditingController();
  DateTime? workingDate;
  RxBool isTracking = false.obs;

  Future<bool> submit({required String companyName}) async {
    final colRef = FirestoreService.productCollection(companyName, 'steel_wire_sling');
    final query = colRef.where('serial', isEqualTo: serialController.text);
    final docs = await query.get();
    if (docs.docs.isEmpty) {
      return (await Get.dialog<bool>(AlertDialog(
        title: const Text('Submit'),
        content: const Text('Are you sure you want to submit?'),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: const Text('No')),
          TextButton(onPressed: () => Get.back(result: true), child: const Text('Yes')),
        ],
      ))) ?? false;
    } else {
      return (await Get.dialog<bool>(AlertDialog(
        title: const Text('Serial Found'),
        content: const Text('Serial already exists. Override with current data?'),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: const Text('No')),
          TextButton(onPressed: () => Get.back(result: true), child: const Text('Yes')),
        ],
      ))) ?? false;
    }
  }

  Future<void> track() async {
    isTracking.value = true;
    try {
      final companyName = await FirestoreService.getCompanyName();
      final docs = await FirestoreService.productCollection(companyName, 'steel_wire_sling')
          .where('serial', isEqualTo: serialController.text).get();
      if (docs.docs.isNotEmpty) {
        final data = docs.docs.first.data() as Map<String, dynamic>;
        diameterController.text      = data['slingDiameter']  ?? '';
        eyeDimensionsController.text = data['eyeDimensions']  ?? '';
        lengthController.text        = data['length']         ?? '';
        mblController.text           = data['MBL']            ?? '';
        purchaseOrderController.text = data['purchaseOrder']  ?? '';
        projectNameController.text   = data['projectName']    ?? '';
        slingType.value              = data['slingType']      ?? '';
        core.value                   = data['core']           ?? '';
        withThimble.value            = data['withThimble']    ?? false;
        final wd = data['workingDate'];
        if (wd != null) {
          workingDate = DateTime.fromMillisecondsSinceEpoch(
              wd.millisecondsSinceEpoch).toLocal();
        }
      } else {
        Get.dialog(AlertDialog(
          title: const Text('New Serial'),
          content: const Text('Serial not found. Fill in fields and submit.'),
          actions: [TextButton(onPressed: () => Get.back(), child: const Text('Ok'))],
        ));
      }
    } finally {
      isTracking.value = false;
    }
  }

  Future<void> writeData() async {
    if (!formKey.currentState!.validate()) return;
    if (slingType.value.isEmpty) {
      SnackbarHelper.showSnackBar('Please select Sling Type', isError: true);
      return;
    }

    final confirmed = await Get.dialog<bool>(AlertDialog(
      title: const Text('Submit'),
      content: const Text('Are you sure you want to submit?'),
      actions: [
        TextButton(onPressed: () => Get.back(result: false), child: const Text('No')),
        TextButton(onPressed: () => Get.back(result: true), child: const Text('Yes')),
      ],
    ));
    if (confirmed != true) return;

    final companyName = await FirestoreService.getCompanyName();
    await FirestoreService.productCollection(companyName, 'steel_wire_sling')
        .doc(serialController.text)
        .set({
      ...FirestoreService.baseProductFields(companyId: companyName, category: 'steel_wire_sling'),
      'serial':        serialController.text,
      'slingDiameter': diameterController.text,
      'eyeDimensions': eyeDimensionsController.text,
      'length':        lengthController.text,
      'MBL':           mblController.text,
      'slingType':     slingType.value,
      'core':          core.value,
      'withThimble':   withThimble.value,
      'purchaseOrder': purchaseOrderController.text,
      'projectName':   projectNameController.text,
      'workingDate':   workingDate,
    }, SetOptions(merge: true));

    formKey.currentState!.reset();
    slingType.value   = '';
    core.value        = '';
    withThimble.value = false;
    workingDate       = null;
    SnackbarHelper.showSnackBar('Steel sling saved successfully', isError: false);
  }
}
