import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:getwidget/getwidget.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/utils/extensions.dart';
import 'package:sling_force/values/app_colors.dart';

import '../controllers/load_binder_controller.dart';
import 'package:sling_force/utils/common_widgets/tabbed_screen_wrapper.dart';

class LoadBinderView extends GetView<LoadBinderController> {
  const LoadBinderView({super.key});
  @override
  Widget build(BuildContext context) {
    return TabbedScreenWrapper(
      title: 'Load Binder',
      collection: (Get.arguments as String?) ?? '',
      submitChild: SizedBox(
          height: context.heightFraction(sizeFraction: 1),
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: SizedBox(
              height: context.heightFraction(sizeFraction: 1),
              child: SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: GfForm(
                    formkey: controller.formkey,
                    onFormSubmitted: (value) {},
                    defaultSubmitButtonEnabled: false,
                    formfields: [
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8.0),
                        child: GFTypography(
                          showDivider: false,
                          text: "Serial Number :",
                          textColor: Colors.black87,
                          type: GFTypographyType.typo5,
                        ),
                      ),
                      GFTextFieldRounded(
                        controller: controller.serialController,
                        validator: (controller) {
                          if (controller == null) {
                            return 'Enter Serial Number';
                          }
                          return null;
                        },
                        style: GoogleFonts.ubuntu(
                            fontSize: 10, fontWeight: FontWeight.bold),
                        autofocus: true,
                        autocorrect: true,
                        autovalidate: true,
                        autoValidateMode: AutovalidateMode.onUserInteraction,
                        enableSuggestions: true,
                        keyboardType: TextInputType.number,
                        onChanged: (value) {},
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        editingbordercolor: AppColors.darkBlue,
                        idlebordercolor: AppColors.primaryColor,
                        borderwidth: 3,
                        cornerradius: 10,
                        hintText: 'Serial Number',
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8.0),
                        child: GFTypography(
                          showDivider: false,
                          text: "Type :",
                          textColor: Colors.black87,
                          type: GFTypographyType.typo5,
                        ),
                      ),
                      GFTextFieldRounded(
                        controller: controller.typeController,
                        validator: (controller) {
                          if (controller == null) {
                            return 'Enter Type';
                          }
                          return null;
                        },
                        style: GoogleFonts.ubuntu(
                            fontSize: 10, fontWeight: FontWeight.bold),
                        autofocus: true,
                        autocorrect: true,
                        autovalidate: true,
                        autoValidateMode: AutovalidateMode.onUserInteraction,
                        enableSuggestions: true,
                        // keyboardType: TextInputType.number,
                        onChanged: (value) {},
                        inputFormatters: const [
                          // FilteringTextInputFormatter.digitsOnly,
                        ],
                        editingbordercolor: AppColors.darkBlue,
                        idlebordercolor: AppColors.primaryColor,
                        borderwidth: 3,
                        cornerradius: 10,
                        hintText: 'Type',
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8.0),
                        child: GFTypography(
                          showDivider: false,
                          text: "Size :",
                          textColor: Colors.black87,
                          type: GFTypographyType.typo5,
                        ),
                      ),
                      GFTextFieldRounded(
                        controller: controller.sizeController,
                        validator: (controller) {
                          if (controller == null) {
                            return 'Enter Size';
                          }
                          return null;
                        },
                        style: GoogleFonts.ubuntu(
                            fontSize: 10, fontWeight: FontWeight.bold),
                        autofocus: true,
                        autocorrect: true,
                        autovalidate: true,
                        autoValidateMode: AutovalidateMode.onUserInteraction,
                        enableSuggestions: true,
                        // keyboardType: TextInputType.number,
                        onChanged: (value) {},
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        editingbordercolor: AppColors.darkBlue,
                        idlebordercolor: AppColors.primaryColor,
                        borderwidth: 3,
                        cornerradius: 10,
                        hintText: 'Size (mm)',
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8.0),
                        child: GFTypography(
                          showDivider: false,
                          text: "MBL :",
                          textColor: Colors.black87,
                          type: GFTypographyType.typo5,
                        ),
                      ),
                      GFTextFieldRounded(
                        controller: controller.mblController,
                        validator: (controller) {
                          if (controller == null) {
                            return 'Enter MBL';
                          }
                          return null;
                        },
                        style: GoogleFonts.ubuntu(
                            fontSize: 10, fontWeight: FontWeight.bold),
                        autofocus: true,
                        autocorrect: true,
                        autovalidate: true,
                        autoValidateMode: AutovalidateMode.onUserInteraction,
                        enableSuggestions: true,
                        // keyboardType: TextInputType.number,
                        onChanged: (value) {},
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                        ],
                        editingbordercolor: AppColors.darkBlue,
                        idlebordercolor: AppColors.primaryColor,
                        borderwidth: 3,
                        cornerradius: 10,
                        hintText: 'MBL',
                      ),
                      // GFTextFieldRounded(
                      //   style: GoogleFonts.ubuntu(
                      //       fontSize: 10, fontWeight: FontWeight.bold),
                      //   autofocus: true,
                      //   autocorrect: true,
                      //   autovalidate: true,
                      //   autoValidateMode: AutovalidateMode.onUserInteraction,
                      //   enableSuggestions: true,
                      //   keyboardType: TextInputType.number,
                      //   onChanged: (value) {},
                      //   inputFormatters: [
                      //     FilteringTextInputFormatter.digitsOnly,
                      //   ],
                      //   editingbordercolor: AppColors.darkBlue,
                      //   idlebordercolor: AppColors.primaryColor,
                      //   borderwidth: 3,
                      //   cornerradius: 10,
                      //   hintText: 'Diameter (mm)',
                      // ),
                      Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 8.0, horizontal: 32.0),
                            child: GFButton(
                                onPressed: () async {
                                  await controller.track();
                                },
                                blockButton: true,
                                type: GFButtonType.outline2x,
                                color: AppColors.primaryColor,
                                textStyle: GoogleFonts.ubuntu(
                                    fontWeight: FontWeight.w500,
                                    color: AppColors.primaryColor),
                                text: 'Track',
                                shape: GFButtonShape.pills),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 8.0, horizontal: 32.0),
                            child: GFButton(
                                onPressed: () async {
                                  await controller.writeData();
                                },
                                blockButton: true,
                                type: GFButtonType.outline2x,
                                color: AppColors.primaryColor,
                                textStyle: GoogleFonts.ubuntu(
                                    fontWeight: FontWeight.w500,
                                    color: AppColors.primaryColor),
                                text: 'Submit',
                                shape: GFButtonShape.pills),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          )),
    );;
  }
}
