import 'package:get/get.dart';

import '../controllers/load_binder_controller.dart';

class LoadBinderBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<LoadBinderController>(
      () => LoadBinderController(),
    );
  }
}
