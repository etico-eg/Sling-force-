import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sling_force/services/firestore_service.dart';
import 'package:sling_force/utils/helpers/snackbar_helper.dart';

class LoadBinderController extends GetxController {
  final formkey          = GlobalKey<FormState>();
  final serialController = TextEditingController();
  final typeController   = TextEditingController();
  final mblController    = TextEditingController();
  final sizeController   = TextEditingController();

  submit() => Get.dialog(AlertDialog(
    title: const Text('Submit'),
    content: const Text('Are you sure you want to submit?'),
    actions: [
      TextButton(onPressed: () => Get.back(result: false), child: const Text('No')),
      TextButton(onPressed: () => Get.back(result: true), child: const Text('Yes')),
    ],
  ));

  Future track() async {
    final companyName = await FirestoreService.getCompanyName();
    final docs = await FirestoreService.productCollection(companyName, Get.arguments)
        .where('serial', isEqualTo: serialController.text).get();
    if (docs.docs.isNotEmpty) {
      final data = docs.docs.first.data() as Map<String, dynamic>;
      serialController.text = data['serial'] ?? '';
      typeController.text   = data['type']   ?? '';
      sizeController.text   = data['size']   ?? '';
      mblController.text    = data['MBL']    ?? '';
    }
  }

  Future writeData() async {
    if (!formkey.currentState!.validate()) return;
    if (await submit()) {
      final companyName = await FirestoreService.getCompanyName();
      await FirestoreService.productCollection(companyName, Get.arguments)
          .doc(serialController.text)
          .set({
        ...FirestoreService.baseProductFields(companyId: companyName, category: Get.arguments),
        'serial': serialController.text,
        'type':   typeController.text,
        'size':   sizeController.text,
        'MBL':    mblController.text,
      }, SetOptions(merge: true));
      formkey.currentState!.reset();
      SnackbarHelper.showSnackBar('Added Successfully', isError: false);
    }
  }
}
