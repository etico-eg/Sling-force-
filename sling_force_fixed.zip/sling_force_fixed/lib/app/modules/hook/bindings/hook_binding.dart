import 'package:get/get.dart';

import '../controllers/hook_controller.dart';

class HookBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<HookController>(
      () => HookController(),
    );
  }
}
