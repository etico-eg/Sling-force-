import 'package:get/get.dart';

import '../controllers/lifting_eye_controller.dart';

class LiftingEyeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<LiftingEyeController>(
      () => LiftingEyeController(),
    );
  }
}
