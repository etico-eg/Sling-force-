import 'package:get/get.dart';

import '../controllers/shakle_tracking_controller.dart';

class ShakleTrackingBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ShakleTrackingController>(
      () => ShakleTrackingController(),
    );
  }
}
