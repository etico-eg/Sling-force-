import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:getwidget/getwidget.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/utils/extensions.dart';
import 'package:sling_force/values/app_colors.dart';

import '../controllers/steel_slings_quotation_controller.dart';

class SteelSlingsQuotationView extends GetView<SteelSlingsQuotationController> {
  const SteelSlingsQuotationView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          toolbarHeight: 40,
          automaticallyImplyLeading: true,
          foregroundColor: Colors.white,
          backgroundColor: const Color.fromARGB(255, 96, 10, 10),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(50),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Steel wire rope slings',
                    style: GoogleFonts.ubuntu(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Colors.white),
                  ),
                  const Icon(
                    Icons.add,
                    color: Colors.white,
                  )
                ],
              ),
            ),
          )),
      body: Obx(() {
        return SizedBox(
            height: context.heightFraction(sizeFraction: 1),
            child: Padding(
              padding: const EdgeInsets.all(5.0),
              child: SizedBox(
                height: context.heightFraction(sizeFraction: 1),
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: GfForm(
                      formkey: controller.formKey,
                      onFormSubmitted: (value) {},
                      defaultSubmitButtonEnabled: false,
                      formfields: [
                        GFTextFieldRounded(
                          style: GoogleFonts.ubuntu(
                              fontSize: 10, fontWeight: FontWeight.bold),
                          autofocus: true,
                          controller: controller.mblController,
                          autocorrect: true,
                          autovalidate: true,
                          autoValidateMode: AutovalidateMode.onUserInteraction,
                          enableSuggestions: true,
                          keyboardType: TextInputType.number,
                          onChanged: (value) {},
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                          ],
                          editingbordercolor: AppColors.darkBlue,
                          idlebordercolor: AppColors.primaryColor,
                          borderwidth: 3,
                          cornerradius: 10,
                          hintText: 'MBL',
                          validator: (controller) {
                            if (controller == null || controller.isEmpty) {
                              return 'Please enter MBL';
                            }
                            return null;
                          },
                        ),
                        GFTextFieldRounded(
                          style: GoogleFonts.ubuntu(
                              fontSize: 10, fontWeight: FontWeight.bold),
                          autofocus: true,
                          autocorrect: true,
                          autovalidate: true,
                          controller: controller.diameterController,
                          autoValidateMode: AutovalidateMode.onUserInteraction,
                          enableSuggestions: true,
                          keyboardType: TextInputType.number,
                          onChanged: (value) {},
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                          ],
                          editingbordercolor: AppColors.darkBlue,
                          idlebordercolor: AppColors.primaryColor,
                          borderwidth: 3,
                          cornerradius: 10,
                          hintText: 'Diameter',
                          validator: (controller) {
                            if (controller == null || controller.isEmpty) {
                              return 'Please enter diameter';
                            }
                            return null;
                          },
                        ),
                        GFTextFieldRounded(
                          style: GoogleFonts.ubuntu(
                              fontSize: 10, fontWeight: FontWeight.bold),
                          autofocus: true,
                          autocorrect: true,
                          autovalidate: true,
                          autoValidateMode: AutovalidateMode.onUserInteraction,
                          enableSuggestions: true,
                          keyboardType: TextInputType.number,
                          controller: controller.eyeDimensionsController,
                          onChanged: (value) {},
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                          ],
                          editingbordercolor: AppColors.darkBlue,
                          idlebordercolor: AppColors.primaryColor,
                          borderwidth: 3,
                          cornerradius: 10,
                          hintText: 'Eye dimensions',
                          validator: (controller) {
                            if (controller == null || controller.isEmpty) {
                              return 'Please enter eye dimensions';
                            }
                            return null;
                          },
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8.0, vertical: 8.0),
                          child: Container(
                            // height: 50,

                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: AppColors.primaryColor,
                                width: 3,
                              ),
                            ),
                            child: GFDropdown(
                              validator: (value) {
                                if (value == null &&
                                    controller.slingType.value == '') {
                                  return 'Please select sling type';
                                }
                                return null;
                              },
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 5),
                              elevation: 5,
                              iconSize: 25,
                              iconDisabledColor: AppColors.primaryColor,
                              iconEnabledColor: AppColors.primaryColor,
                              dropdownButtonColor: Colors.transparent,
                              hint: Text(
                                'Steel sling type',
                                style: GoogleFonts.ubuntu(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              icon: const Icon(
                                Icons.arrow_drop_down,
                                color: AppColors.primaryColor,
                              ),
                              isExpanded: true,
                              items: const [
                                DropdownMenuItem(
                                    value: 1,
                                    child: Text(
                                      'Hand spliced',
                                      style: TextStyle(color: Colors.black),
                                    )),
                                DropdownMenuItem(
                                    value: 2,
                                    child: Text('Mechanically spliced',
                                        style: TextStyle(color: Colors.black))),
                              ],
                              onChanged: (x) {
                                controller.slingType.value = x == 1
                                    ? 'Hand spliced'
                                    : 'Mechanically spliced';
                              },
                              style: GoogleFonts.ubuntu(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                              // dropdownButtonColor: Colors.white,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16.0, vertical: 8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              // text
                              Text(
                                'With thimble ',
                                style: GoogleFonts.ubuntu(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.black.withValues(alpha: 0.8)),
                              ),
                              GFCheckbox(
                                  validator: (value) {
                                    if (value == null) {
                                      return 'Please select thimble';
                                    }
                                    return null;
                                  },
                                  onChanged: (v) {
                                    controller.withThimble.value = v;
                                  },
                                  value: controller.withThimble.value,
                                  size: GFSize.SMALL,
                                  activeBgColor: AppColors.primaryColor,
                                  inactiveBorderColor: AppColors.primaryColor,
                                  activeBorderColor: AppColors.primaryColor,
                                  type: GFCheckboxType.circle),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8.0, vertical: 8.0),
                          child: Container(
                            // height: 50,

                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color: AppColors.primaryColor,
                                width: 3,
                              ),
                            ),
                            child: GFDropdown(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 5),
                              elevation: 5,
                              validator: (value) {
                                if (value == null &&
                                    controller.core.value == '') {
                                  return 'Please select core';
                                }
                                return null;
                              },
                              iconSize: 25,
                              iconDisabledColor: AppColors.primaryColor,
                              iconEnabledColor: AppColors.primaryColor,
                              dropdownButtonColor: Colors.transparent,
                              hint: Text(
                                'Core',
                                style: GoogleFonts.ubuntu(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              icon: const Icon(
                                Icons.arrow_drop_down,
                                color: AppColors.primaryColor,
                              ),
                              isExpanded: true,
                              items: const [
                                DropdownMenuItem(
                                    value: 1,
                                    child: Text(
                                      'Steel core',
                                      style: TextStyle(color: Colors.black),
                                    )),
                                DropdownMenuItem(
                                    value: 2,
                                    child: Text('Fibre core',
                                        style: TextStyle(color: Colors.black))),
                              ],
                              onChanged: (x) {
                                controller.core.value =
                                    x == 1 ? 'Steel core' : 'Fibre core';
                              },
                              style: GoogleFonts.ubuntu(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                              // dropdownButtonColor: Colors.white,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 8.0, horizontal: 32.0),
                          child: GFButton(
                              onPressed: () async {},
                              blockButton: true,
                              type: GFButtonType.outline2x,
                              color: AppColors.primaryColor,
                              textStyle: GoogleFonts.ubuntu(
                                  fontWeight: FontWeight.w500,
                                  color: AppColors.primaryColor),
                              text: 'Request Quotation',
                              shape: GFButtonShape.pills),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ));
      }),
    );
  }
}
