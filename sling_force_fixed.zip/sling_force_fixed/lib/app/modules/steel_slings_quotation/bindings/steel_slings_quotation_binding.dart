import 'package:get/get.dart';

import '../controllers/steel_slings_quotation_controller.dart';

class SteelSlingsQuotationBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<SteelSlingsQuotationController>(
      () => SteelSlingsQuotationController(),
    );
  }
}
