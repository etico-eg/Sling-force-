import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SteelSlingsQuotationController extends GetxController {
  RxBool withThimble = false.obs;
  RxString slingType = ''.obs;
  RxString core = ''.obs;
  final formKey = GlobalKey<FormState>();

  final diameterController = TextEditingController();
  final eyeDimensionsController = TextEditingController();
  // final slingTypeController = TextEditingController();
  final mblController = TextEditingController();
}
