import 'package:get/get.dart';

import '../controllers/clutch_controller.dart';

class ClutchBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ClutchController>(
      () => ClutchController(),
    );
  }
}
