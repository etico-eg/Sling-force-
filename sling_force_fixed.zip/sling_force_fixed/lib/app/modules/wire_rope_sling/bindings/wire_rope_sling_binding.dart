import 'package:get/get.dart';

import '../controllers/wire_rope_sling_controller.dart';

class WireRopeSlingBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<WireRopeSlingController>(
      () => WireRopeSlingController(),
    );
  }
}
