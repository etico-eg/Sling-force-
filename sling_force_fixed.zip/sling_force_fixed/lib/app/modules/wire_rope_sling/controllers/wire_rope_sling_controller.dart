import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sling_force/services/firestore_service.dart';
import 'package:sling_force/utils/helpers/snackbar_helper.dart';

class WireRopeSlingController extends GetxController {
  final formKey                 = GlobalKey<FormState>();
  final serialController        = TextEditingController();
  final widthController         = TextEditingController();
  final lengthController        = TextEditingController();
  final mblController           = TextEditingController();
  final purchaseOrderController = TextEditingController();
  final projectNameController   = TextEditingController();
  final layerNumbersController  = TextEditingController();
  RxBool isTracking = false.obs;
  DateTime? workingDate;

  Future<bool> submit({required String companyName}) async {
    final colRef = FirestoreService.productCollection(companyName, 'webbing_sling');
    final query = colRef.where('serial', isEqualTo: serialController.text);
    final docs = await query.get();
    if (docs.docs.isEmpty) {
      return (await Get.dialog<bool>(AlertDialog(
        title: const Text('Submit'),
        content: const Text('Are you sure you want to submit?'),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: const Text('No')),
          TextButton(onPressed: () => Get.back(result: true), child: const Text('Yes')),
        ],
      ))) ?? false;
    } else {
      return (await Get.dialog<bool>(AlertDialog(
        title: const Text('Serial Found'),
        content: const Text('Serial already exists. Override with current data?'),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: const Text('No')),
          TextButton(onPressed: () => Get.back(result: true), child: const Text('Yes')),
        ],
      ))) ?? false;
    }
  }

  Future<void> track() async {
    isTracking.value = true;
    try {
      final companyName = await FirestoreService.getCompanyName();
      final docs = await FirestoreService.productCollection(companyName, 'webbing_sling')
          .where('serial', isEqualTo: serialController.text).get();
      if (docs.docs.isNotEmpty) {
        final data = docs.docs.first.data() as Map<String, dynamic>;
        lengthController.text        = data['slingLength']?.toString() ?? '';
        widthController.text         = data['slingWidth']?.toString()  ?? '';
        layerNumbersController.text  = data['slingLayers']?.toString() ?? '';
        mblController.text           = data['MBL']?.toString()         ?? '';
        purchaseOrderController.text = data['purchaseOrder']           ?? '';
        projectNameController.text   = data['projectName']             ?? '';
        final wd = data['workingDate'];
        if (wd != null) {
          workingDate = DateTime.fromMillisecondsSinceEpoch(
              wd.millisecondsSinceEpoch).toLocal();
        }
      } else {
        Get.dialog(AlertDialog(
          title: const Text('New Serial'),
          content: const Text('Serial not found. Fill in fields and submit.'),
          actions: [TextButton(onPressed: () => Get.back(), child: const Text('Ok'))],
        ));
      }
    } finally {
      isTracking.value = false;
    }
  }

  Future<void> writeData() async {
    if (!formKey.currentState!.validate()) return;

    final confirmed = await Get.dialog<bool>(AlertDialog(
      title: const Text('Submit'),
      content: const Text('Are you sure you want to submit?'),
      actions: [
        TextButton(onPressed: () => Get.back(result: false), child: const Text('No')),
        TextButton(onPressed: () => Get.back(result: true), child: const Text('Yes')),
      ],
    ));
    if (confirmed != true) return;

    final companyName = await FirestoreService.getCompanyName();
    await FirestoreService.productCollection(companyName, 'webbing_sling')
        .doc(serialController.text)
        .set({
      ...FirestoreService.baseProductFields(companyId: companyName, category: 'webbing_sling'),
      'serial':        serialController.text,
      'slingLength':   lengthController.text,
      'slingWidth':    widthController.text,
      'slingLayers':   layerNumbersController.text,
      'MBL':           mblController.text,
      'purchaseOrder': purchaseOrderController.text,
      'projectName':   projectNameController.text,
      'workingDate':   workingDate,
    }, SetOptions(merge: true));

    formKey.currentState!.reset();
    workingDate = null;
    SnackbarHelper.showSnackBar('Sling saved successfully', isError: false);
  }
}
