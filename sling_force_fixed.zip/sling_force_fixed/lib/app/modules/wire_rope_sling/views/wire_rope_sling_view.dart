import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:getwidget/getwidget.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/utils/common_widgets/barcode_scanner_window.dart';
import 'package:sling_force/utils/common_widgets/nfc_scanner_sheet.dart';
import 'package:sling_force/utils/extensions.dart';
import 'package:sling_force/utils/helpers/snackbar_helper.dart';
import 'package:sling_force/values/app_colors.dart';

import '../controllers/wire_rope_sling_controller.dart';
import 'package:sling_force/utils/common_widgets/tabbed_screen_wrapper.dart';

class WireRopeSlingView extends GetView<WireRopeSlingController> {
  const WireRopeSlingView({super.key});
  @override
  Widget build(BuildContext context) {
    return TabbedScreenWrapper(
      title: 'Webbing Slings',
      collection: (Get.arguments as String?) ?? '',
      submitChild: Stack(
        children: [
          SizedBox(
                height: context.heightFraction(sizeFraction: 1),
                child: Padding(
                  padding: const EdgeInsets.all(5.0),
                  child: SizedBox(
                    height: context.heightFraction(sizeFraction: 1),
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: GfForm(
                        height: context.heightFraction(sizeFraction: 0.5),
                        defaultSubmitButtonEnabled: false,
                        formkey: controller.formKey,
                        formBorderColor: AppColors.primaryColor,
                        onFormSubmitted: (value) {},
                        formfields: [
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Serial Number :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            autocorrect: true,
                            autovalidate: true,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter Serial Number';
                              }
                              return null;
                            },
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            controller: controller.serialController,
                            enableSuggestions: true,
                            keyboardType: TextInputType.text,
                            onChanged: (value) {},
                            inputFormatters: const [
                              // FilteringTextInputFormatter.digitsOnly,
                            ],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Serial Number',
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Project Name :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            autocorrect: true,
                            autovalidate: true,
                            validator: (value) {
                              // if (value == null || value.isEmpty) {
                              //   return 'Please enter project name';
                              // }
                              return null;
                            },
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            controller: controller.projectNameController,
                            enableSuggestions: true,
                            keyboardType: TextInputType.text,
                            onChanged: (value) {},
                            inputFormatters: const [
                              // FilteringTextInputFormatter.digitsOnly,
                            ],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Project Name ( optional )',
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Purchase Order # :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            autocorrect: true,
                            autovalidate: true,
                            validator: (value) {
                              // if (value == null || value.isEmpty) {
                              //   return 'Please enter Purchase Order';
                              // }
                              return null;
                            },
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            controller: controller.purchaseOrderController,
                            enableSuggestions: true,
                            keyboardType: TextInputType.text,
                            onChanged: (value) {},
                            inputFormatters: const [
                              // FilteringTextInputFormatter.digitsOnly,
                            ],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Purchase Order # ( optional )',
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "MBL :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            autocorrect: true,
                            autovalidate: true,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter MBL';
                              }
                              return null;
                            },
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            controller: controller.mblController,
                            enableSuggestions: true,
                            keyboardType: TextInputType.text,
                            onChanged: (value) {},
                            inputFormatters: const [
                              // FilteringTextInputFormatter.digitsOnly,
                            ],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'MBL',
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Working Date :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GestureDetector(
                            onTap: () async {
                              final picked = await showDatePicker(
                                context: context,
                                initialDate: DateTime.now(),
                                firstDate: DateTime(1900),
                                lastDate: DateTime(2100),
                              );
                              if (picked != null &&
                                  picked != controller.workingDate) {
                                controller.workingDate = picked;
                              }
                            },
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 8.0),
                              child: Row(
                                children: [
                                  IconButton(
                                    icon: const Icon(Icons.calendar_today,
                                        color: Colors.black87),
                                    onPressed: () async {
                                      final picked = await showDatePicker(
                                        context: context,
                                        initialDate: DateTime.now(),
                                        firstDate: DateTime(1900),
                                        lastDate: DateTime(2100),
                                      );
                                      if (picked != null &&
                                          picked != controller.workingDate) {
                                        controller.workingDate = picked;
                                      }
                                    },
                                  ),
                                  Text(
                                    controller.workingDate != null
                                        ? '${controller.workingDate?.day}/${controller.workingDate?.month}/${controller.workingDate?.year}'
                                        : 'Not Set',
                                    style:
                                        const TextStyle(color: Colors.black87),
                                  )
                                ],
                              ),
                            ),
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Sling Width :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            autocorrect: true,
                            autovalidate: true,
                            controller: controller.widthController,
                            validator: (controller) {
                              if (controller == null || controller.isEmpty) {
                                return 'Please enter sling width';
                              }
                              return null;
                            },
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            enableSuggestions: true,
                            keyboardType: const TextInputType.numberWithOptions(
                                decimal: true),
                            onChanged: (value) {},
                            inputFormatters: const [
                              // FilteringTextInputFormatter.digitsOnly,
                            ],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Sling Width (mm)',
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Sling Length :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            autocorrect: true,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter sling length';
                              }
                              return null;
                            },
                            autovalidate: true,
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            enableSuggestions: true,
                            keyboardType: const TextInputType.numberWithOptions(
                                decimal: true),
                            controller: controller.lengthController,
                            onChanged: (value) {},
                            inputFormatters: const [
                              // FilteringTextInputFormatter.digitsOnly,
                            ],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Sling Length (mm)',
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 8.0),
                            child: GFTypography(
                              showDivider: false,
                              text: "Number Of Layers :",
                              textColor: Colors.black87,
                              type: GFTypographyType.typo5,
                            ),
                          ),
                          GFTextFieldRounded(
                            style: GoogleFonts.ubuntu(
                                fontSize: 10, fontWeight: FontWeight.bold),
                            autofocus: true,
                            autocorrect: true,
                            autovalidate: true,
                            validator: (controller) {
                              if (controller == null || controller.isEmpty) {
                                return 'Please enter number of layers';
                              }
                              return null;
                            },
                            autoValidateMode:
                                AutovalidateMode.onUserInteraction,
                            controller: controller.layerNumbersController,
                            enableSuggestions: true,
                            keyboardType: TextInputType.number,
                            onChanged: (value) {},
                            inputFormatters: [
                              FilteringTextInputFormatter.digitsOnly,
                            ],
                            editingbordercolor: AppColors.darkBlue,
                            idlebordercolor: AppColors.primaryColor,
                            borderwidth: 3,
                            cornerradius: 10,
                            hintText: 'Number of layers ',
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 8.0, horizontal: 32.0),
                            child: GFButton(
                                onPressed: () async {
                                  await controller.track();
                                },
                                blockButton: true,
                                type: GFButtonType.outline2x,
                                color: AppColors.primaryColor,
                                textStyle: GoogleFonts.ubuntu(
                                    fontWeight: FontWeight.w500,
                                    color: AppColors.primaryColor),
                                text: 'Track',
                                shape: GFButtonShape.pills),
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 8.0, horizontal: 32.0),
                            child: GFButton(
                                onPressed: () async {
                                  if (!controller.formKey.currentState!
                                      .validate()) {
                                    return;
                                  }
                                  var uid =
                                      FirebaseAuth.instance.currentUser!.uid;
                                  // get  the user company name from firestore
                                  var user = await FirebaseFirestore.instance
                                      .collection('users')
                                      .doc(uid)
                                      .get();
                                  var companyName = user.data()!['companyName'];
                                  if (await controller.submit(
                                      companyName: companyName)) {
                                    // get current user uid

                                    // submit the data to firestore and show success message
                                    FirebaseFirestore.instance
                                        .collection(
                                            'companies/$companyName/${(Get.arguments as String?) ?? ""}')
                                        .doc(controller.serialController.text)
                                        .set({
                                      'serial':
                                          controller.serialController.text,
                                      'MBL': controller.mblController.text,
                                      'slingWidth':
                                          controller.widthController.text,
                                      'slingLength':
                                          controller.lengthController.text,
                                      'slingLayers': controller
                                          .layerNumbersController.text,
                                      'purchaseOrder': controller
                                          .purchaseOrderController.text,
                                      'projectName':
                                          controller.projectNameController.text,
                                      'workingDate': controller.workingDate
                                    }, SetOptions(merge: true));
                                    controller.formKey.currentState!.reset();
                                    Get.back();

                                    SnackbarHelper.showSnackBar(
                                        'Added Successfully',
                                        isError: false);
                                  }
                                },
                                blockButton: true,
                                type: GFButtonType.outline2x,
                                color: AppColors.primaryColor,
                                textStyle: GoogleFonts.ubuntu(
                                    fontWeight: FontWeight.w500,
                                    color: AppColors.primaryColor),
                                text: 'Submit',
                                shape: GFButtonShape.pills),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              SizedBox(
                                width: context.widthFraction(sizeFraction: 0.4),
                                child: const GFTypography(
                                  showDivider: false,
                                  type: GFTypographyType.typo5,
                                  textColor: AppColors.primaryColor,
                                  text: 'Scan with qr code',
                                ),
                              ),
                              GFButton(
                                blockButton: false,
                                type: GFButtonType.outline2x,
                                color: AppColors.primaryColor,
                                shape: GFButtonShape.pills,
                                onPressed: () async {
                                  var result = await Get.to(
                                      () => BarcodeScannerWithScanWindow(
                                            controller: controller,
                                          ));

                                  print('result ' + result);
                                  if (result != null) {
                                    // controller.isTracking.value = true;
                                    // context.loaderOverlay.show();
                                    final splitResult = result.split(' ');

                                    final serial =
                                        splitResult[0].replaceAll(",", "");
                                    print(serial);
                                    controller.serialController.text = serial;
                                    final mbl = splitResult.length > 1
                                        ? splitResult[1].replaceAll(",", "")
                                        : null;
                                    final width = splitResult.length > 2
                                        ? splitResult[2].replaceAll(",", "")
                                        : null;
                                    final length = splitResult.length > 3
                                        ? splitResult[3].replaceAll(",", "")
                                        : null;
                                    final purchaseOrder = splitResult.length > 4
                                        ? splitResult[4].replaceAll(",", "")
                                        : null;
                                    final projectName = splitResult.length > 5
                                        ? splitResult[5].replaceAll(",", "")
                                        : null;

                                    final layerNumbers = splitResult.length > 6
                                        ? splitResult[6].replaceAll(",", "")
                                        : null;
                                    if (mbl == null ||
                                        width == null ||
                                        length == null) {
                                      Get.dialog(AlertDialog(
                                        title: const Text('Error'),
                                        content: const Text('Invalid QR Code'),
                                        actions: <Widget>[
                                          TextButton(
                                            onPressed: () {
                                              Get.back();
                                            },
                                            child: const Text('OK'),
                                          ),
                                        ],
                                      ));
                                      return;
                                    }

                                    controller.mblController.text = mbl;
                                    controller.widthController.text = width;
                                    controller.lengthController.text = length;
                                    controller.purchaseOrderController.text =
                                        purchaseOrder ?? '';
                                    controller.projectNameController.text =
                                        projectName ?? '';
                                    controller.layerNumbersController.text =
                                        layerNumbers ?? '';
                                    print(layerNumbers);
                                    await controller.track();
                                    // controller.isTracking.value = false;
                                  }
                                },
                                child: const Icon(
                                  Icons.qr_code,
                                  // size: 500,
                                  color: AppColors.primaryColor,
                                ),
                              ),
                              GFButton(
                                blockButton: false,
                                type: GFButtonType.outline2x,
                                color: AppColors.primaryColor,
                                shape: GFButtonShape.pills,
                                onPressed: () async {
                                  final result = await NfcScannerSheet.scan();
                                  if (result != null) {
                                    final splitResult = result.split(' ');
                                    final serial = splitResult[0].replaceAll(',', '');
                                    controller.serialController.text = serial;
                                    final mbl = splitResult.length > 1 ? splitResult[1].replaceAll(',', '') : null;
                                    final width = splitResult.length > 2 ? splitResult[2].replaceAll(',', '') : null;
                                    final length = splitResult.length > 3 ? splitResult[3].replaceAll(',', '') : null;
                                    final purchaseOrder = splitResult.length > 4 ? splitResult[4].replaceAll(',', '') : null;
                                    final projectName = splitResult.length > 5 ? splitResult[5].replaceAll(',', '') : null;
                                    final layerNumbers = splitResult.length > 6 ? splitResult[6].replaceAll(',', '') : null;
                                    if (mbl != null) controller.mblController.text = mbl;
                                    if (width != null) controller.widthController.text = width;
                                    if (length != null) controller.lengthController.text = length;
                                    if (purchaseOrder != null) controller.purchaseOrderController.text = purchaseOrder;
                                    if (projectName != null) controller.projectNameController.text = projectName;
                                    if (layerNumbers != null) controller.layerNumbersController.text = layerNumbers;
                                    await controller.track();
                                  }
                                },
                                child: const Icon(
                                  Icons.nfc,
                                  color: AppColors.primaryColor,
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                )),
          Obx(() => controller.isTracking.isTrue
              ? Container(
                  color: Colors.white.withValues(alpha: 0.7),
                  child: const Center(
                    child: SpinKitCubeGrid(
                      color: AppColors.primaryColor,
                      size: 50.0,
                    ),
                  ),
                )
              : const SizedBox.shrink()),
        ],
      ),
    );;
  }
}
