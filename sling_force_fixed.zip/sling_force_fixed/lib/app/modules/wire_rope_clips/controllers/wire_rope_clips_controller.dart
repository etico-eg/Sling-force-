import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sling_force/services/firestore_service.dart';
import 'package:sling_force/utils/helpers/snackbar_helper.dart';

class WireRopeClipsController extends GetxController {
  final formkey            = GlobalKey<FormState>();
  final serialController   = TextEditingController();
  final diameterController = TextEditingController();

  submit() => Get.dialog(AlertDialog(
    title: const Text('Submit'),
    content: const Text('Are you sure you want to submit?'),
    actions: [
      TextButton(onPressed: () => Get.back(result: false), child: const Text('No')),
      TextButton(onPressed: () => Get.back(result: true), child: const Text('Yes')),
    ],
  ));

  Future track() async {
    final companyName = await FirestoreService.getCompanyName();
    final docs = await FirestoreService.productCollection(companyName, (Get.arguments as String?) ?? '')
        .where('serial', isEqualTo: serialController.text).get();
    if (docs.docs.isNotEmpty) {
      final data = docs.docs.first.data() as Map<String, dynamic>;
      serialController.text   = data['serial']   ?? '';
      diameterController.text = data['diameter'] ?? '';
    }
  }

  Future writeData() async {
    if (!formkey.currentState!.validate()) return;
    if (await submit()) {
      final companyName = await FirestoreService.getCompanyName();
      await FirestoreService.productCollection(companyName, (Get.arguments as String?) ?? '')
          .doc(serialController.text)
          .set({
        ...FirestoreService.baseProductFields(companyId: companyName, category: (Get.arguments as String?) ?? ''),
        'serial':   serialController.text,
        'diameter': diameterController.text,
      }, SetOptions(merge: true));
      formkey.currentState!.reset();
      SnackbarHelper.showSnackBar('Added Successfully', isError: false);
    }
  }
}
