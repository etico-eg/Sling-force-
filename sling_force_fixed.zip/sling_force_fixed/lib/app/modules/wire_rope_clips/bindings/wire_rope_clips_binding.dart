import 'package:get/get.dart';

import '../controllers/wire_rope_clips_controller.dart';

class WireRopeClipsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<WireRopeClipsController>(
      () => WireRopeClipsController(),
    );
  }
}
