import 'package:get/get.dart';

class SteelQuatationController extends GetxController {
  RxBool withThimble = false.obs;
  RxString slingType = 'Steel Sling Type'.obs;
  RxString core = 'Core'.obs;
}
