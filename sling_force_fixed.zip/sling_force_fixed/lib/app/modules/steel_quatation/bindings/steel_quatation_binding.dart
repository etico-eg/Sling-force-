import 'package:get/get.dart';

import '../controllers/steel_quatation_controller.dart';

class SteelQuatationBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<SteelQuatationController>(
      () => SteelQuatationController(),
    );
  }
}
