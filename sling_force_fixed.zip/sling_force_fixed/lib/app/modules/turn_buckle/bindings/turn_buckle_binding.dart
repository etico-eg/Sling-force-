import 'package:get/get.dart';

import '../controllers/turn_buckle_controller.dart';

class TurnBuckleBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<TurnBuckleController>(
      () => TurnBuckleController(),
    );
  }
}
