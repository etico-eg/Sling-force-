import 'package:get/get.dart';

import '../controllers/chain_controller.dart';

class ChainBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ChainController>(
      () => ChainController(),
    );
  }
}
