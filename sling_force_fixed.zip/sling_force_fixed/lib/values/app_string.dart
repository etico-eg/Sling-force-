class AppStrings {
  static const String loginAndRegister = 'Login and Register UI';

  static const String uhOhPageNotFound = 'uh-oh!\nPage not found';
  static const String register = 'Register';
  static const String login = 'Login';
  static const String createYourAccount = 'Create your account';
  static const String doNotHaveAnAccount = "Don't have an account?";
  static const String facebook = 'Facebook';
  static const String google = 'Google';
  static const String signInToYourNAccount = 'Sign in to your\nAccount';
  static const String signInToYourAccount = 'Sign in to your Account';
  static const String iHaveAnAccount = 'I have an account?';
  static const String forgotPassword = 'Forgot Password?';
  static const String orLoginWith = 'or Login with';
  static const String loggedIn = 'Logged In!';
  static const String passwordResetLinkSent = 'Password Reset Link Sent';

  static const String registrationComplete = 'Registration Complete!';
  static const String name = 'Name';

  static const String pleaseEnterName = 'Please, Enter Name';
  static const String invalidName = 'Name should be at least 3 characters';
  static const String invalidPositionName =
      'Position should be at least 2 characters';
  static const String email = 'Email';

  static const String pleaseEnterEmailAddress = 'Please, Enter Email Address';
  static const String invalidEmailAddress = 'Invalid Email Address';
  static const String password = 'Password';

  static const String pleaseEnterPassword = 'Please, Enter Password';
  static const String invalidPassword =
      'Password should be at least 6 digits \nwith 1 uppercase, 1 lowercase, 1 number \nand 1 special character';
  static const String confirmPassword = 'Confirm Password';

  static const String pleaseReEnterPassword = 'Please, Re-Enter Password';
  static const String passwordNotMatched = 'Password not matched!';
  static const String enterCompanyName = 'company name should be provided';
  const AppStrings._();
}
