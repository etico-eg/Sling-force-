import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/screens/login_screen.dart';
import 'package:sling_force/services/firestore_service.dart';
import 'package:sling_force/values/app_colors.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _positionController = TextEditingController();
  final _phoneController = TextEditingController();

  // Password change
  final _currentPasswordController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  bool _isLoading = true;
  bool _isSaving = false;
  bool _isChangingPassword = false;
  bool _showPasswordSection = false;
  Map<String, dynamic> _userData = {};

  final _auth = FirebaseAuth.instance;
  final _db = FirebaseFirestore.instance;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    setState(() => _isLoading = true);
    try {
      final data = await FirestoreService.getUserData();
      setState(() {
        _userData = data;
        _nameController.text = data['name'] ?? '';
        _positionController.text = data['position'] ?? '';
        _phoneController.text = data['phoneNumber'] ?? '';
      });
    } catch (e) {
      _showSnack('Failed to load profile: $e', isError: true);
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _saveProfile() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);
    try {
      final uid = _auth.currentUser!.uid;
      await _db.collection('users').doc(uid).update({
        'name': _nameController.text.trim(),
        'position': _positionController.text.trim(),
        'phoneNumber': _phoneController.text.trim(),
      });
      _showSnack('Profile updated successfully', isError: false);
    } catch (e) {
      _showSnack('Failed to save: $e', isError: true);
    } finally {
      setState(() => _isSaving = false);
    }
  }

  Future<void> _changePassword() async {
    if (_newPasswordController.text != _confirmPasswordController.text) {
      _showSnack('New passwords do not match', isError: true);
      return;
    }
    if (_newPasswordController.text.length < 6) {
      _showSnack('Password must be at least 6 characters', isError: true);
      return;
    }

    setState(() => _isChangingPassword = true);
    try {
      final user = _auth.currentUser!;
      // Re-authenticate first
      final credential = EmailAuthProvider.credential(
        email: user.email!,
        password: _currentPasswordController.text,
      );
      await user.reauthenticateWithCredential(credential);
      await user.updatePassword(_newPasswordController.text);

      _currentPasswordController.clear();
      _newPasswordController.clear();
      _confirmPasswordController.clear();
      setState(() => _showPasswordSection = false);
      _showSnack('Password changed successfully', isError: false);
    } on FirebaseAuthException catch (e) {
      String msg;
      switch (e.code) {
        case 'wrong-password':
        case 'invalid-credential':
          msg = 'Current password is incorrect';
          break;
        case 'too-many-requests':
          msg = 'Too many attempts. Please wait.';
          break;
        default:
          msg = e.message ?? 'Password change failed';
      }
      _showSnack(msg, isError: true);
    } finally {
      setState(() => _isChangingPassword = false);
    }
  }

  void _showSnack(String msg, {required bool isError}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? Colors.red[700] : Colors.green[700],
      behavior: SnackBarBehavior.floating,
    ));
  }

  Future<void> _signOut() async {
    final confirmed = await Get.dialog<bool>(AlertDialog(
      title: const Text('Sign Out'),
      content: const Text('Are you sure you want to sign out?'),
      actions: [
        TextButton(onPressed: () => Get.back(result: false), child: const Text('Cancel')),
        TextButton(
          onPressed: () => Get.back(result: true),
          child: const Text('Sign Out', style: TextStyle(color: Colors.red)),
        ),
      ],
    ));
    if (confirmed == true) {
      await _auth.signOut();
      Get.offAll(() => const LoginPage());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 96, 10, 10),
        foregroundColor: Colors.white,
        title: Text('My Profile', style: GoogleFonts.ubuntu(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Sign Out',
            onPressed: _signOut,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primaryColor))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ── Avatar + Email ─────────────────────────────────────
                    Center(
                      child: Column(
                        children: [
                          CircleAvatar(
                            radius: 40,
                            backgroundColor: AppColors.primaryColor,
                            backgroundImage: _auth.currentUser?.photoURL != null
                                ? NetworkImage(_auth.currentUser!.photoURL!)
                                : null,
                            child: _auth.currentUser?.photoURL == null
                                ? Text(
                                    (_nameController.text.isNotEmpty
                                            ? _nameController.text[0]
                                            : '?')
                                        .toUpperCase(),
                                    style: GoogleFonts.ubuntu(
                                        fontSize: 32,
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold),
                                  )
                                : null,
                          ),
                          const SizedBox(height: 10),
                          Text(
                            _auth.currentUser?.email ?? '',
                            style: GoogleFonts.ubuntu(
                                fontSize: 14, color: Colors.grey[600]),
                          ),
                          const SizedBox(height: 4),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 4),
                            decoration: BoxDecoration(
                              color: AppColors.primaryColor.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: AppColors.primaryColor),
                            ),
                            child: Text(
                              _userData['companyId'] ?? _userData['companyName'] ?? '',
                              style: GoogleFonts.ubuntu(
                                  fontSize: 12,
                                  color: AppColors.primaryColor,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 28),
                    _sectionTitle('Personal Information'),
                    const SizedBox(height: 12),

                    // ── Name ──────────────────────────────────────────────
                    _buildField(
                      controller: _nameController,
                      label: 'Full Name',
                      icon: Icons.person_outline,
                      validator: (v) => v!.trim().isEmpty ? 'Name is required' : null,
                    ),
                    const SizedBox(height: 14),

                    // ── Position ──────────────────────────────────────────
                    _buildField(
                      controller: _positionController,
                      label: 'Position / Role',
                      icon: Icons.work_outline,
                    ),
                    const SizedBox(height: 14),

                    // ── Phone ─────────────────────────────────────────────
                    _buildField(
                      controller: _phoneController,
                      label: 'Phone Number',
                      icon: Icons.phone_outlined,
                      keyboardType: TextInputType.phone,
                    ),
                    const SizedBox(height: 8),

                    // ── Company (read only) ───────────────────────────────
                    _buildReadOnly(
                      label: 'Company',
                      value: _userData['companyId'] ?? _userData['companyName'] ?? 'N/A',
                      icon: Icons.business_outlined,
                    ),
                    const SizedBox(height: 24),

                    // ── Save button ───────────────────────────────────────
                    SizedBox(
                      width: double.infinity,
                      child: _isSaving
                          ? const Center(child: CircularProgressIndicator(color: AppColors.primaryColor))
                          : ElevatedButton.icon(
                              onPressed: _saveProfile,
                              icon: const Icon(Icons.save_outlined, color: Colors.white),
                              label: Text('Save Changes',
                                  style: GoogleFonts.ubuntu(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold)),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.primaryColor,
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: const StadiumBorder(),
                              ),
                            ),
                    ),

                    const SizedBox(height: 28),
                    const Divider(),
                    const SizedBox(height: 8),

                    // ── Change Password section ───────────────────────────
                    // Only show for email/password users (not Google)
                    if (_auth.currentUser?.providerData
                            .any((p) => p.providerId == 'password') ==
                        true) ...[
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.lock_outline,
                            color: AppColors.primaryColor),
                        title: Text('Change Password',
                            style: GoogleFonts.ubuntu(fontWeight: FontWeight.w600)),
                        trailing: Icon(
                          _showPasswordSection
                              ? Icons.expand_less
                              : Icons.expand_more,
                          color: AppColors.primaryColor,
                        ),
                        onTap: () =>
                            setState(() => _showPasswordSection = !_showPasswordSection),
                      ),
                      if (_showPasswordSection) ...[
                        const SizedBox(height: 8),
                        _buildField(
                          controller: _currentPasswordController,
                          label: 'Current Password',
                          icon: Icons.lock_outline,
                          isPassword: true,
                        ),
                        const SizedBox(height: 12),
                        _buildField(
                          controller: _newPasswordController,
                          label: 'New Password',
                          icon: Icons.lock_reset_outlined,
                          isPassword: true,
                        ),
                        const SizedBox(height: 12),
                        _buildField(
                          controller: _confirmPasswordController,
                          label: 'Confirm New Password',
                          icon: Icons.lock_reset_outlined,
                          isPassword: true,
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: _isChangingPassword
                              ? const Center(child: CircularProgressIndicator(color: AppColors.primaryColor))
                              : OutlinedButton.icon(
                                  onPressed: _changePassword,
                                  icon: const Icon(Icons.lock_reset_outlined,
                                      color: AppColors.primaryColor),
                                  label: Text('Update Password',
                                      style: GoogleFonts.ubuntu(
                                          color: AppColors.primaryColor,
                                          fontWeight: FontWeight.bold)),
                                  style: OutlinedButton.styleFrom(
                                    side: const BorderSide(
                                        color: AppColors.primaryColor, width: 2),
                                    padding:
                                        const EdgeInsets.symmetric(vertical: 14),
                                    shape: const StadiumBorder(),
                                  ),
                                ),
                        ),
                        const SizedBox(height: 16),
                      ],
                      const Divider(),
                    ],

                    const SizedBox(height: 8),

                    // ── Sign out ──────────────────────────────────────────
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.logout, color: Colors.red),
                      title: Text('Sign Out',
                          style: GoogleFonts.ubuntu(
                              color: Colors.red, fontWeight: FontWeight.w600)),
                      onTap: _signOut,
                    ),
                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _sectionTitle(String text) => Text(
        text,
        style: GoogleFonts.ubuntu(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.black87),
      );

  Widget _buildField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool isPassword = false,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: isPassword,
      keyboardType: keyboardType,
      validator: validator,
      style: GoogleFonts.ubuntu(fontSize: 14),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(color: AppColors.primaryColor),
        prefixIcon: Icon(icon, color: AppColors.primaryColor),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppColors.primaryColor),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:
              const BorderSide(color: AppColors.primaryColor, width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide:
              const BorderSide(color: AppColors.primaryColor, width: 2),
        ),
      ),
    );
  }

  Widget _buildReadOnly({
    required String label,
    required String value,
    required IconData icon,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[300]!),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.grey[500], size: 20),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label,
                  style: GoogleFonts.ubuntu(
                      fontSize: 11, color: Colors.grey[500])),
              Text(value,
                  style: GoogleFonts.ubuntu(
                      fontSize: 14, color: Colors.grey[700])),
            ],
          ),
          const Spacer(),
          Icon(Icons.lock_outline, size: 16, color: Colors.grey[400]),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _positionController.dispose();
    _phoneController.dispose();
    _currentPasswordController.dispose();
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }
}
