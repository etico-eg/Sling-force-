import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/app/modules/home/controllers/home_controller.dart';
import 'package:sling_force/app/modules/home/views/home_view.dart';
import 'package:sling_force/components/app_text_form_field.dart';
import 'package:sling_force/constants/assets.dart';
import 'package:sling_force/screens/login_screen.dart';
import 'package:sling_force/utils/common_widgets/gradient_background.dart';
import 'package:sling_force/utils/extensions.dart';
import 'package:sling_force/utils/helpers/snackbar_helper.dart';
import 'package:sling_force/values/app_colors.dart';
import 'package:sling_force/values/app_constants.dart';
import 'package:sling_force/values/app_regex.dart';
import 'package:sling_force/values/app_string.dart';
import 'package:sling_force/values/app_them.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController nameController;
  late final TextEditingController emailController;
  late final TextEditingController passwordController;
  late final TextEditingController confirmPasswordController;
  late final TextEditingController companyNameController;
  late final TextEditingController positionController;

  final ValueNotifier<bool> passwordNotifier = ValueNotifier(true);
  final ValueNotifier<bool> confirmPasswordNotifier = ValueNotifier(true);
  final ValueNotifier<bool> companyNameNotifier = ValueNotifier(true);
  final ValueNotifier<bool> fieldValidNotifier = ValueNotifier(false);
  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          toolbarHeight: 0,
          systemOverlayStyle: const SystemUiOverlayStyle(
            statusBarColor: Color.fromARGB(255, 96, 10, 10),
            statusBarIconBrightness: Brightness.dark,
          )),
      body: SafeArea(
        child: Stack(
        children: [
          ListView(
        children: [
          GradientBackground(
            colors: const [
              Color.fromARGB(255, 96, 10, 10),
              Color.fromARGB(255, 146, 36, 29)
            ],
            children: [
              SvgPicture.asset(
                Assets.assetsSvgIconsLogo,
                color: Colors.white,
                width: context.widthFraction(sizeFraction: 0.2),
                height: context.widthFraction(sizeFraction: 0.3),
              ),
              const Text(AppStrings.register, style: AppTheme.titleLarge),
              const SizedBox(height: 5),
              const Text(AppStrings.createYourAccount,
                  style: AppTheme.bodySmall),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  AppTextFormField(
                    autofocus: true,
                    labelText: AppStrings.name,
                    keyboardType: TextInputType.name,
                    textInputAction: TextInputAction.next,
                    onChanged: (value) => _formKey.currentState?.validate(),
                    validator: (value) {
                      return value!.isEmpty
                          ? AppStrings.pleaseEnterName
                          : value.length < 3
                              ? AppStrings.invalidName
                              : null;
                    },
                    controller: nameController,
                  ),
                  SizedBox(
                    height: context.heightFraction(sizeFraction: 0.02),
                  ),
                  SizedBox(
                    width: context.widthFraction(sizeFraction: 1),
                    child: Text(
                      'Company Name ',
                      style: AppTheme.bodySmall.copyWith(
                          color: AppColors.darkestBlue.withValues(alpha: 0.7),
                          fontWeight: FontWeight.w500,
                          fontFamily: GoogleFonts.ubuntu().fontFamily,
                          fontSize: context.widthFraction(sizeFraction: 0.035),
                          letterSpacing: 0.1,
                          height: 0.2),
                      textAlign: TextAlign.left,
                      textScaler: TextScaler.noScaling,
                    ),
                  ),

                  TypeAheadField(
                    animationDuration: const Duration(milliseconds: 500),
                    loadingBuilder: (context) {
                      return const Center(
                          child: SpinKitThreeBounce(
                        color: AppColors.primaryColor,
                        size: 20,
                      ));
                    },
                    key: const Key('companyName'),
                    controller: companyNameController,
                    itemBuilder: (context, value) => ListTile(
                      title: Text(value),
                    ),
                    onSelected: (value) {
                      companyNameController.text = value;
                    },
                    emptyBuilder: (context) {
                      return const SizedBox.shrink();
                    },
                    suggestionsCallback: (search) {
                      if (search.isEmpty) return null;
                      return FirebaseFirestore.instance
                          .collection('companies')
                          .get()
                          .then((snapshot) => Future.value(snapshot.docs
                              .map((doc) => doc.data()['companyName'])
                              .where((name) => name
                                  .toLowerCase()
                                  .startsWith(search.toLowerCase()))
                              .toList()));
                    },
                  ),
                  SizedBox(
                    height: context.heightFraction(sizeFraction: 0.02),
                  ),
                  // AppTextFormField(
                  //   labelText: 'Company Name',
                  //   keyboardType: TextInputType.name,
                  //   textInputAction: TextInputAction.next,
                  //   onChanged: (value) => _formKey.currentState?.validate(),
                  //   validator: (value) {
                  //     return value!.isEmpty
                  //         ? 'Please, Enter Company Name'
                  //         : value.length < 3
                  //             ? AppStrings.invalidName
                  //             : null;
                  //   },
                  //   controller: companyNameController,
                  // ),
                  AppTextFormField(
                    labelText: 'Position',
                    keyboardType: TextInputType.name,
                    textInputAction: TextInputAction.next,
                    onChanged: (value) => _formKey.currentState?.validate(),
                    validator: (value) {
                      return value!.isEmpty
                          ? 'Please, Enter Your Position'
                          : value.length < 2
                              ? AppStrings.invalidPositionName
                              : null;
                    },
                    controller: positionController,
                  ),
                  AppTextFormField(
                    labelText: AppStrings.email,
                    controller: emailController,
                    textInputAction: TextInputAction.next,
                    keyboardType: TextInputType.emailAddress,
                    onEditingComplete: () => _formKey.currentState?.validate(),
                    validator: (value) {
                      return value!.isEmpty
                          ? AppStrings.pleaseEnterEmailAddress
                          : AppConstants.emailRegex.hasMatch(value)
                              ? null
                              : AppStrings.invalidEmailAddress;
                    },
                  ),
                  ValueListenableBuilder<bool>(
                    valueListenable: passwordNotifier,
                    builder: (_, passwordObscure, __) {
                      return AppTextFormField(
                        obscureText: passwordObscure,
                        controller: passwordController,
                        labelText: AppStrings.password,
                        textInputAction: TextInputAction.next,
                        keyboardType: TextInputType.visiblePassword,
                        onChanged: (_) => _formKey.currentState?.validate(),
                        validator: (value) {
                          return value!.isEmpty
                              ? AppStrings.pleaseEnterPassword
                              : value!.length < 6 ? 'Password must be at least 6 characters' : null;
                        },
                        suffixIcon: Focus(
                          /// If false,
                          ///
                          /// disable focus for all of this node's descendants
                          descendantsAreFocusable: false,

                          /// If false,
                          ///
                          /// make this widget's descendants un-traversable.
                          // descendantsAreTraversable: false,
                          child: IconButton(
                            onPressed: () =>
                                passwordNotifier.value = !passwordObscure,
                            style: IconButton.styleFrom(
                              minimumSize: const Size.square(48),
                            ),
                            icon: Icon(
                              passwordObscure
                                  ? Icons.visibility_off_outlined
                                  : Icons.visibility_outlined,
                              color: AppColors.primaryColor,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                  ValueListenableBuilder(
                    valueListenable: confirmPasswordNotifier,
                    builder: (_, confirmPasswordObscure, __) {
                      return AppTextFormField(
                        labelText: AppStrings.confirmPassword,
                        controller: confirmPasswordController,
                        obscureText: confirmPasswordObscure,
                        textInputAction: TextInputAction.done,
                        keyboardType: TextInputType.visiblePassword,
                        onChanged: (_) => _formKey.currentState?.validate(),
                        validator: (value) {
                          return value!.isEmpty
                              ? AppStrings.pleaseReEnterPassword
                              : AppConstants.passwordRegex.hasMatch(value)
                                  ? passwordController.text ==
                                          confirmPasswordController.text
                                      ? null
                                      : AppStrings.passwordNotMatched
                                  : AppStrings.invalidPassword;
                        },
                        suffixIcon: Focus(
                          /// If false,
                          ///
                          /// disable focus for all of this node's descendants.
                          descendantsAreFocusable: false,

                          /// If false,
                          ///
                          /// make this widget's descendants un-traversable.
                          // descendantsAreTraversable: false,
                          child: IconButton(
                            onPressed: () => confirmPasswordNotifier.value =
                                !confirmPasswordObscure,
                            style: IconButton.styleFrom(
                              minimumSize: const Size.square(48),
                            ),
                            icon: Icon(
                              confirmPasswordObscure
                                  ? Icons.visibility_off_outlined
                                  : Icons.visibility_outlined,
                              color: AppColors.primaryColor,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                  ValueListenableBuilder(
                    valueListenable: fieldValidNotifier,
                    builder: (_, isValid, __) {
                      return FilledButton(
                        style: ElevatedButton.styleFrom(
                          foregroundColor: Colors.white,
                          backgroundColor: AppColors.primaryColor,
                          // minimumSize: const Size(double.infinity, 50),
                        ),
                        onPressed: isValid
                            ? () async {
                                if (companyNameController.text.isEmpty) {
                                  SnackbarHelper.showSnackBar(
                                      AppStrings.enterCompanyName);
                                  return;
                                }
                                final companyResult = await checkCompany();
                                if (!companyResult) {
                                  if (context.mounted) {
                                    await showDialog<bool>(
                                      context: context,
                                      builder: (BuildContext context) {
                                        return AlertDialog(
                                          title:
                                              const Text('Company not found'),
                                          content: const Text(
                                              'Would you like to register a new company ?'),
                                          actions: [
                                            TextButton(
                                              onPressed: () async {
                                                if (companyNameController
                                                    .text.isEmpty) {
                                                  return;
                                                }
                                                // register the company to firestore
                                                final normalizedName = companyNameController.text
                                                        .toLowerCase()
                                                        .replaceAll(RegExp(r'[^a-z0-9\s-]'), '')
                                                        .trim()
                                                        .replaceAll(RegExp(r'\s+'), '-');
                                                await FirebaseFirestore.instance
                                                    .collection('companies')
                                                    .doc(normalizedName)
                                                    .set({
                                                  'companyName': normalizedName,
                                                  'createdAt': FieldValue.serverTimestamp(),
                                                });

                                                if (context.mounted) {
                                                  Navigator.of(context).pop();
                                                  final cred =
                                                      await registerUser();
                                                  if (cred != null) {
                                                    nameController.clear();
                                                    emailController.clear();
                                                    passwordController.clear();
                                                    confirmPasswordController
                                                        .clear();

                                                    Get.offAll(
                                                        () => const HomeView());
                                                    SnackbarHelper.showSnackBar(
                                                      AppStrings
                                                          .registrationComplete,
                                                    );
                                                  }
                                                }
                                              },
                                              child: const Text('Yes'),
                                            ),
                                            TextButton(
                                              onPressed: () {
                                                Navigator.of(context).pop();
                                              },
                                              child: const Text('No'),
                                            ),
                                          ],
                                        );
                                      },
                                    );
                                  }
                                } else {
                                  if (context.mounted) {
                                    setState(() => isLoading = true);

                                    final cred = await registerUser();

                                    if (cred != null) {
                                      Get.offAll(() => const HomeView());
                                      Future.delayed(
                                          const Duration(milliseconds: 500), () {
                                        SnackbarHelper.showSnackBar(
                                          AppStrings.registrationComplete,
                                        );
                                      });
                                    } else {
                                      if (context.mounted) {
                                        setState(() => isLoading = false);
                                      }
                                    }
                                  }
                                }
                              }
                            : null,
                        child: const Text(AppStrings.register),
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                AppStrings.iHaveAnAccount,
                style: AppTheme.bodySmall.copyWith(color: Colors.black),
              ),
              TextButton(
                onPressed: () => Get.off(() => const LoginPage()),
                child: const Text(
                  AppStrings.login,
                  style: TextStyle(color: AppColors.primaryColor),
                ),
              ),
            ],
          ),
        ],
      ),
          if (isLoading)
            Container(
              color: Colors.black.withValues(alpha: 0.4),
              child: const Center(
                child: SpinKitCubeGrid(
                  color: AppColors.primaryColor,
                  size: 50.0,
                ),
              ),
            ),
        ],
      ),
      ),
    );
  }

  // function to look for companies collection and if the company there it return true else false
  Future<bool> checkCompany() async {
    try {
      final cred = await FirebaseFirestore.instance
          .collection('companies')
          .where('companyName', isEqualTo: companyNameController.text)
          .get();
      if (cred.docs.isNotEmpty) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      print(e);
      SnackbarHelper.showSnackBar(
        "something went wrong",
        isError: true,
      );
      return false;
    }
  }

  void controllerListener() {
    final name = nameController.text;
    final companyName = companyNameController.text;
    final position = positionController.text;
    final email = emailController.text;
    final password = passwordController.text;
    final confirmPassword = confirmPasswordController.text;

    if (name.isEmpty &&
        email.isEmpty &&
        password.isEmpty &&
        confirmPassword.isEmpty &&
        companyName.isEmpty &&
        position.isEmpty) {
      return;
    }

    if (name.isNotEmpty &&
        email.isNotEmpty &&
        AppRegex.emailRegex.hasMatch(email) &&
        password.length >= 6 &&
        password == confirmPassword &&
        companyName.isNotEmpty &&
        position.isNotEmpty) {
      fieldValidNotifier.value = true;
    } else {
      fieldValidNotifier.value = false;
    }
  }

  @override
  void dispose() {
    disposeControllers();
    super.dispose();
  }

  void disposeControllers() {
    nameController.dispose();
    companyNameController.dispose();
    positionController.dispose();
    emailController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
  }

  void initializeControllers() {
    nameController = TextEditingController()..addListener(controllerListener);
    companyNameController = TextEditingController()
      ..addListener(controllerListener);
    positionController = TextEditingController()
      ..addListener(controllerListener);
    emailController = TextEditingController()..addListener(controllerListener);
    passwordController = TextEditingController()
      ..addListener(controllerListener);
    confirmPasswordController = TextEditingController()
      ..addListener(controllerListener);
  }

  @override
  void initState() {
    Get.lazyPut<HomeController>(() => HomeController());

    initializeControllers();
    super.initState();
  }

  Future<UserCredential?> registerUser() async {
    try {
      final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: emailController.text.trim(),
          password: passwordController.text);

      final cleanCompanyName = companyNameController.text
          .toLowerCase()
          .replaceAll(RegExp(r'[^a-z0-9\s-]'), '')
          .trim()
          .replaceAll(RegExp(r'\s+'), '-');

      // Wait for auth token to be fully ready before writing to Firestore
      await cred.user!.getIdToken(true);

      // Save user profile
      await FirebaseFirestore.instance
          .collection('users')
          .doc(cred.user!.uid)
          .set({
        'name': nameController.text.trim(),
        'companyName': cleanCompanyName,
        'companyId': cleanCompanyName,
        'position': positionController.text.trim(),
        'email': emailController.text.trim(),
        'uid': cred.user!.uid,
        'createdAt': FieldValue.serverTimestamp(),
      });

      // Ensure company doc exists
      await FirebaseFirestore.instance
          .collection('companies')
          .doc(cleanCompanyName)
          .set({
        'companyName': cleanCompanyName,
        'createdAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      return cred;
    } on FirebaseAuthException catch (e) {
      String message;
      switch (e.code) {
        case 'weak-password':
          message = 'Password is too weak. Use at least 6 characters.';
          break;
        case 'email-already-in-use':
          message = 'An account with this email already exists.';
          break;
        case 'invalid-email':
          message = 'The email address is not valid.';
          break;
        default:
          message = 'Registration failed: \${e.message ?? e.code}';
      }
      SnackbarHelper.showSnackBar(message, isError: true);
      return null;
    } catch (e) {
      SnackbarHelper.showSnackBar(
        'Error: \${e.toString()}',
        isError: true,
      );
      return null;
    }
  }
}