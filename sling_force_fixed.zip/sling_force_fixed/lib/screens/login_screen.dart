import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:getwidget/getwidget.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/app/modules/home/controllers/home_controller.dart';
import 'package:sling_force/app/routes/app_pages.dart';
import 'package:sling_force/components/app_text_form_field.dart';
import 'package:sling_force/constants/assets.dart';
import 'package:sling_force/screens/forget_password_screen.dart';
import 'package:sling_force/screens/register_screen.dart';
import 'package:sling_force/services/firestore_service.dart';
import 'package:sling_force/utils/common_widgets/gradient_background.dart';
import 'package:sling_force/utils/extensions.dart';
import 'package:sling_force/utils/helpers/snackbar_helper.dart';
import 'package:sling_force/values/app_colors.dart';
import 'package:sling_force/values/app_constants.dart';
import 'package:sling_force/values/app_regex.dart';
import 'package:sling_force/values/app_string.dart';
import 'package:sling_force/values/app_them.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();

  final ValueNotifier<bool> passwordNotifier = ValueNotifier(true);
  final ValueNotifier<bool> fieldValidNotifier = ValueNotifier(false);
  bool isLoading = false;

  late final TextEditingController emailController;
  late final TextEditingController passwordController;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          ListView(
        padding: EdgeInsets.zero,
        children: [
          GradientBackground(
            colors: const [
              Color.fromARGB(255, 111, 24, 18),
              Color.fromARGB(255, 145, 46, 39)
            ],
            children: [
              SvgPicture.asset(
                Assets.assetsSvgIconsLogo,
                color: Colors.white,
                width: context.widthFraction(sizeFraction: 0.3),
                height: context.widthFraction(sizeFraction: 0.3),
              ),
              Text(
                AppStrings.signInToYourNAccount,
                style: AppTheme.titleLarge
                    .copyWith(fontFamily: GoogleFonts.ubuntu().fontFamily),
              ),
              const SizedBox(height: 5),
              Text("Sling Force",
                  style: AppTheme.bodySmall.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w400,
                      fontFamily: GoogleFonts.ubuntu().fontFamily))
            ],
          ),
          Form(
            key: _formKey,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  AppTextFormField(
                    controller: emailController,
                    labelText: AppStrings.email,
                    keyboardType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,
                    onEditingComplete: () => _formKey.currentState?.validate(),
                    validator: (value) {
                      return value!.isEmpty
                          ? AppStrings.pleaseEnterEmailAddress
                          : AppConstants.emailRegex.hasMatch(value)
                              ? null
                              : AppStrings.invalidEmailAddress;
                    },
                  ),
                  ValueListenableBuilder(
                    valueListenable: passwordNotifier,
                    builder: (_, passwordObscure, __) {
                      return AppTextFormField(
                        obscureText: passwordObscure,
                        controller: passwordController,
                        labelText: AppStrings.password,
                        textInputAction: TextInputAction.done,
                        keyboardType: TextInputType.visiblePassword,
                        onChanged: (_) => _formKey.currentState?.validate(),
                        validator: (value) {
                          return value!.isEmpty
                              ? AppStrings.pleaseEnterPassword
                              : value.length < 6
                                  ? 'Password must be at least 6 characters'
                                  : null;
                        },
                        suffixIcon: IconButton(
                          onPressed: () =>
                              passwordNotifier.value = !passwordObscure,
                          style: IconButton.styleFrom(
                            minimumSize: const Size.square(48),
                          ),
                          icon: Icon(
                            passwordObscure
                                ? Icons.visibility_off_outlined
                                : Icons.visibility_outlined,
                            size: 20,
                            color: AppColors.primaryColor,
                          ),
                        ),
                      );
                    },
                  ),
                  TextButton(
                    onPressed: () {
                      Get.to(() => const ForgetPassword());
                    },
                    child: const Text(AppStrings.forgotPassword,
                        style: TextStyle(color: AppColors.primaryColor)),
                  ),
                  const SizedBox(height: 20),
                  ValueListenableBuilder(
                    valueListenable: fieldValidNotifier,
                    builder: (_, isValid, __) {
                      return FilledButton(
                        style: ElevatedButton.styleFrom(
                          foregroundColor: Colors.white,
                          backgroundColor: AppColors.primaryColor,
                        ),
                        onPressed: isValid
                            ? () async {
                                setState(() => isLoading = true);
                                if (await signUserIn()) {
                                  emailController.clear();
                                  passwordController.clear();
                                } else {
                                  if (context.mounted) setState(() => isLoading = false);
                                }
                              }
                            : null,
                        child: const Text(AppStrings.login),
                      );
                    },
                  ),
                  // const SizedBox(height: 10),
                ],
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                AppStrings.doNotHaveAnAccount,
                style: AppTheme.bodySmall.copyWith(color: Colors.black),
              ),
              const SizedBox(width: 4),
              TextButton(
                onPressed: () => Get.off(() => const RegisterPage()),
                child: const Text(
                  AppStrings.register,
                  style: TextStyle(color: AppColors.primaryColor),
                ),
              ),
            ],
          ),
        ],
      ),
          if (isLoading)
            Container(
              color: Colors.black.withValues(alpha: 0.4),
              child: const Center(
                child: CircularProgressIndicator(
                  color: AppColors.primaryColor,
                ),
              ),
            ),
        ],
      ),
    );
  }

  void controllerListener() {
    final email = emailController.text.trim();
    final password = passwordController.text;

    // Only check email format + password non-empty.
    // Do NOT enforce password complexity on login — the web portal may have
    // registered users with passwords that don't match this regex, which would
    // permanently disable the login button for them.
    if (AppRegex.emailRegex.hasMatch(email) && password.length >= 6) {
      fieldValidNotifier.value = true;
    } else {
      fieldValidNotifier.value = false;
    }
  }

  @override
  void dispose() {
    disposeControllers();
    super.dispose();
  }

  void disposeControllers() {
    emailController.dispose();
    passwordController.dispose();
  }

  void initializeControllers() {
    emailController = TextEditingController()..addListener(controllerListener);
    passwordController = TextEditingController()
      ..addListener(controllerListener);
  }

  @override
  void initState() {
    Get.lazyPut<HomeController>(() => HomeController());
    // setState(() {});
    initializeControllers();
    super.initState();
  }

  Future<bool> signUserIn() async {
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: emailController.text.trim(),
        password: passwordController.text,
      );

      // Verify user profile exists in Firestore and heal missing companyId
      // (handles users registered via the web portal).
      try {
        await FirestoreService.getCompanyName();
      } catch (_) {
        // Profile missing — could be a first-time web portal user.
        // Let them through; home screen will show appropriate guidance.
      }

      Get.offAllNamed(Routes.HOME);
      return true;
    } on FirebaseAuthException catch (e) {
      String message;
      switch (e.code) {
        case 'user-not-found':
          message = 'No account found with that email address.';
          break;
        case 'wrong-password':
        case 'invalid-credential':
        case 'invalid-password':
          message = 'Incorrect password. Please try again.';
          break;
        case 'user-disabled':
          message = 'This account has been disabled. Contact your admin.';
          break;
        case 'too-many-requests':
          message = 'Too many failed attempts. Please wait and try again.';
          break;
        case 'network-request-failed':
          message = 'No internet connection. Please check your network.';
          break;
        default:
          message = 'Login failed: ${e.message ?? e.code}';
      }
      SnackbarHelper.showSnackBar(message, isError: true);
      return false;
    }
  }
}
