class Assets {
  /// Assets for assetsImagesBlock
  /// assets/images/block.png
  static const String assetsImagesBlock = "assets/images/block.png";

  /// Assets for assetsImagesChain
  /// assets/images/chain.png
  static const String assetsImagesChain = "assets/images/chain.png";

  /// Assets for assetsImagesClutch
  /// assets/images/clutch.png
  static const String assetsImagesClutch = "assets/images/clutch.png";

  /// Assets for assetsImagesConnectingLink
  /// assets/images/connecting_link.png
  static const String assetsImagesConnectingLink =
      "assets/images/connecting_link.png";

  /// Assets for assetsImagesDoubleLeg
  /// assets/images/double_leg.png
  static const String assetsImagesDoubleLeg = "assets/images/double_leg.png";

  /// Assets for assetsImagesDrilling
  /// assets/images/drilling.png
  static const String assetsImagesDrilling = "assets/images/drilling.png";

  /// Assets for assetsImagesHook
  /// assets/images/hook.png
  static const String assetsImagesHook = "assets/images/hook.png";

  /// Assets for assetsImagesHookReal
  /// assets/images/hook_real.png
  static const String assetsImagesHookReal = "assets/images/hook_real.png";

  /// Assets for assetsImagesHours
  /// assets/images/hours.png
  static const String assetsImagesHours = "assets/images/hours.png";

  /// Assets for assetsImagesLatticeBoom
  /// assets/images/lattice_boom.png
  static const String assetsImagesLatticeBoom =
      "assets/images/lattice_boom.png";

  /// Assets for assetsImagesLiftingEye
  /// assets/images/lifting_eye.png
  static const String assetsImagesLiftingEye = "assets/images/lifting_eye.png";

  /// Assets for assetsImagesLoadbinder
  /// assets/images/loadbinder.png
  static const String assetsImagesLoadbinder = "assets/images/loadbinder.png";

  /// Assets for assetsImagesLogo
  /// assets/images/logo.png
  static const String assetsImagesLogo = "assets/images/logo.png";

  /// Assets for assetsImagesManufacture
  /// assets/images/manufacture.png
  static const String assetsImagesManufacture = "assets/images/manufacture.png";

  /// Assets for assetsImagesModel
  /// assets/images/model.png
  static const String assetsImagesModel = "assets/images/model.png";

  /// Assets for assetsImagesOverhead
  /// assets/images/overhead.png
  static const String assetsImagesOverhead = "assets/images/overhead.png";

  /// Assets for assetsImagesPedestal
  /// assets/images/pedestal.png
  static const String assetsImagesPedestal = "assets/images/pedestal.png";

  /// Assets for assetsImagesPiling
  /// assets/images/piling.png
  static const String assetsImagesPiling = "assets/images/piling.png";

  /// Assets for assetsImagesQuadLeg
  /// assets/images/quad_leg.png
  static const String assetsImagesQuadLeg = "assets/images/quad_leg.png";

  /// Assets for assetsImagesQuotation
  /// assets/images/quotation.png
  static const String assetsImagesQuotation = "assets/images/quotation.png";

  /// Assets for assetsImagesRolling
  /// assets/images/rolling.png
  static const String assetsImagesRolling = "assets/images/rolling.png";

  /// Assets for assetsImagesSerial
  /// assets/images/serial.png
  static const String assetsImagesSerial = "assets/images/serial.png";

  /// Assets for assetsImagesShackle
  /// assets/images/shackle.png
  static const String assetsImagesShackle = "assets/images/shackle.png";

  /// Assets for assetsImagesShackleReal
  /// assets/images/shackle_real.png
  static const String assetsImagesShackleReal =
      "assets/images/shackle_real.png";

  /// Assets for assetsImagesSingleLeg
  /// assets/images/single_leg.png
  static const String assetsImagesSingleLeg = "assets/images/single_leg.png";

  /// Assets for assetsImagesSling
  /// assets/images/sling.png
  static const String assetsImagesSling = "assets/images/sling.png";

  /// Assets for assetsImagesSocket
  /// assets/images/socket.png
  static const String assetsImagesSocket = "assets/images/socket.png";

  /// Assets for assetsImagesSteelBlast
  /// assets/images/steel_blast.png
  static const String assetsImagesSteelBlast = "assets/images/steel_blast.png";

  /// Assets for assetsImagesSteelLadle
  /// assets/images/steel_ladle.png
  static const String assetsImagesSteelLadle = "assets/images/steel_ladle.png";

  /// Assets for assetsImagesSwivel
  /// assets/images/swivel.png
  static const String assetsImagesSwivel = "assets/images/swivel.png";

  /// Assets for assetsImagesTelescopic
  /// assets/images/telescopic.png
  static const String assetsImagesTelescopic = "assets/images/telescopic.png";

  /// Assets for assetsImagesTowerCrane
  /// assets/images/tower_crane.png
  static const String assetsImagesTowerCrane = "assets/images/tower_crane.png";

  /// Assets for assetsImagesTrack
  /// assets/images/track.png
  static const String assetsImagesTrack = "assets/images/track.png";

  /// Assets for assetsImagesTripleLeg
  /// assets/images/triple_leg.png
  static const String assetsImagesTripleLeg = "assets/images/triple_leg.png";

  /// Assets for assetsImagesTurnbuckle
  /// assets/images/turnbuckle.png
  static const String assetsImagesTurnbuckle = "assets/images/turnbuckle.png";

  /// Assets for assetsImagesWebbingSling
  /// assets/images/webbing_sling.png
  static const String assetsImagesWebbingSling =
      "assets/images/webbing_sling.png";

  /// Assets for assetsImagesWireRoeCore
  /// assets/images/wire_roe_core.png
  static const String assetsImagesWireRoeCore =
      "assets/images/wire_roe_core.png";

  /// Assets for assetsImagesWireRope
  /// assets/images/wire_rope.png
  static const String assetsImagesWireRope = "assets/images/wire_rope.png";

  /// Assets for assetsImagesWireRopeClip
  /// assets/images/wire_rope_clip.png
  static const String assetsImagesWireRopeClip =
      "assets/images/wire_rope_clip.png";

  /// Assets for assetsImagesWrDiameter
  /// assets/images/wr_diameter.png
  static const String assetsImagesWrDiameter = "assets/images/wr_diameter.png";

  /// Assets for assetsImagesWrLength
  /// assets/images/wr_length.png
  static const String assetsImagesWrLength = "assets/images/wr_length.png";

  /// Assets for assetsImagesWrLocation
  /// assets/images/wr_location.png
  static const String assetsImagesWrLocation = "assets/images/wr_location.png";

  /// Assets for assetsSvgIconsCrane
  /// assets/svg/icons/crane.svg
  static const String assetsSvgIconsCrane = "assets/svg/icons/crane.svg";

  /// Assets for assetsSvgIconsHook
  /// assets/svg/icons/hook.svg
  static const String assetsSvgIconsHook = "assets/svg/icons/hook.svg";

  /// Assets for assetsSvgIconsLogo
  /// assets/svg/icons/logo.svg
  static const String assetsSvgIconsLogo = "assets/svg/icons/logo.svg";

  /// Assets for assetsSvgIconsNounGantry crane2036213
  /// assets/svg/icons/noun_gantry crane_2036213.svg
  static const String assetsSvgIconsNounGantrycrane2036213 =
      "assets/svg/icons/noun_gantry crane_2036213.svg";

  /// Assets for assetsSvgIconsNounWire116163
  /// assets/svg/icons/noun_Wire_116163.svg
  static const String assetsSvgIconsNounWire116163 =
      "assets/svg/icons/noun_Wire_116163.svg";

  /// Assets for assetsSvgIconsOverhead
  /// assets/svg/icons/overhead.svg
  static const String assetsSvgIconsOverhead = "assets/svg/icons/overhead.svg";

  // /// Assets for assetsSvgIconsNounWire116163
  // /// assets/svg/icons/noun_Wire_116163.png
  // static const String assetsSvgIconsNounWire116163 = "assets/svg/icons/noun_Wire_116163.png";

  /// Assets for assetsSvgIconsPiling
  /// assets/svg/icons/piling.svg
  static const String assetsSvgIconsPiling = "assets/svg/icons/piling.svg";

  /// Assets for assetsSvgIconsQuotation
  /// assets/svg/icons/quotation.svg
  static const String assetsSvgIconsQuotation =
      "assets/svg/icons/quotation.svg";

  /// Assets for assetsSvgIconsShackle
  /// assets/svg/icons/shackle.svg
  static const String assetsSvgIconsShackle = "assets/svg/icons/shackle.svg";

  /// Assets for assetsSvgIconsSling
  /// assets/svg/icons/sling.svg
  static const String assetsSvgIconsSling = "assets/svg/icons/sling.svg";

  /// Assets for assetsSvgIconsTowerCrane
  /// assets/svg/icons/tower_crane.svg
  static const String assetsSvgIconsTowerCrane =
      "assets/svg/icons/tower_crane.svg";

  /// Assets for assetsSvgIconsTrack
  /// assets/svg/icons/track.svg
  static const String assetsSvgIconsTrack = "assets/svg/icons/track.svg";

  Assets._();
}
