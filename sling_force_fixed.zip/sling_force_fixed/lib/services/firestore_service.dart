import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  static final FirebaseFirestore _db = FirebaseFirestore.instance;
  static final FirebaseAuth _auth = FirebaseAuth.instance;

  /// Returns the current user's UID.
  static String get currentUid => _auth.currentUser!.uid;

  /// Returns the current user's Firestore profile document data.
  static Future<Map<String, dynamic>> getUserData() async {
    final uid = _auth.currentUser!.uid;
    final doc = await _db.collection('users').doc(uid).get();
    if (!doc.exists || doc.data() == null) {
      throw Exception('User profile not found in Firestore.');
    }
    return doc.data()!;
  }

  /// Returns the current user's companyName (used as companyId in Firestore paths).
  ///
  /// Handles both profiles created by the mobile app (has both `companyName`
  /// and `companyId`) and profiles created by the web portal (has only
  /// `companyName`). If `companyId` is missing it is automatically backfilled
  /// so the Firestore security rules work correctly.
  static Future<String> getCompanyName() async {
    final uid = _auth.currentUser!.uid;
    final data = await getUserData();

    // Prefer companyId if present (matches Firestore security rules)
    String? company = (data['companyId'] as String?)?.replaceAll(' ', '');

    // Fall back to companyName (web portal users)
    if (company == null || company.isEmpty) {
      company = (data['companyName'] as String?)?.replaceAll(' ', '');
    }

    if (company == null || company.isEmpty) {
      throw Exception('User profile is missing company information.');
    }

    // Backfill companyId if it was missing — this heals web portal accounts
    // so they pass Firestore security rule checks on subsequent requests.
    if (data['companyId'] == null || (data['companyId'] as String).isEmpty) {
      await _db.collection('users').doc(uid).update({'companyId': company});
    }

    return company;
  }

  /// Returns the base fields that every product document must include
  /// to satisfy Firestore security rules (creatorUid + companyId + category).
  static Map<String, dynamic> baseProductFields({
    required String companyId,
    required String category,
  }) {
    return {
      'creatorUid': _auth.currentUser!.uid,
      'companyId': companyId,
      'category': category,
    };
  }

  /// Returns a reference to a product collection under a company.
  static CollectionReference productCollection(
    String companyName,
    String collection,
  ) {
    return _db.collection('companies/$companyName/$collection');
  }
}
