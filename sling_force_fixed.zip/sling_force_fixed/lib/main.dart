import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:sling_force/app/modules/splash/views/splash_view.dart';
import 'package:sling_force/firebase_options.dart';
import 'package:sling_force/utils/helpers/navigation_helper.dart';
import 'package:sling_force/utils/helpers/snackbar_helper.dart';

import 'app/routes/app_pages.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(statusBarIconBrightness: Brightness.light),
  );
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp])
      .then((_) => runApp(
            ScreenUtilInit(
              designSize: const Size(375, 812),
              minTextAdapt: true,
              splitScreenMode: true,
              rebuildFactor: (old, data) => true,
              useInheritedMediaQuery: true,
              child: GetMaterialApp(
                home: const SplashView(),
                useInheritedMediaQuery: true,
                scaffoldMessengerKey: SnackbarHelper.key,
                navigatorKey: NavigationHelper.key,
                title: "SlingForce",
                showPerformanceOverlay: false,
                debugShowCheckedModeBanner: false,
                // initialRoute: AppPages.INITIAL,
                getPages: AppPages.routes,
              ),
            ),
          ));
}
