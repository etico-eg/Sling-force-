import 'package:flutter/material.dart';

class SnackbarHelper {
  static final _key = GlobalKey<ScaffoldMessengerState>();

  static GlobalKey<ScaffoldMessengerState> get key => _key;

  const SnackbarHelper._();

  static void showSnackBar(String? message, {bool isError = false}) =>
      _key.currentState
        ?..removeCurrentSnackBar()
        ..showSnackBar(
          SnackBar(
            content: Center(
              child: Text(
                message ?? '',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: isError ? Colors.red : Colors.white,
                ),
              ),
            ),
          ),
        );
}
