import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/values/app_colors.dart';

/// A dropdown that uses [ValueNotifier] so it is completely isolated from
/// any parent [Obx] / [GetBuilder] rebuilds.  When the parent reactive scope
/// rebuilds, Flutter reuses this widget's existing [State] instead of
/// destroying it — meaning the open dropdown overlay is never interrupted.
///
/// Usage:
///   AppDropdown(
///     notifier: controller.layDirection,   // ValueNotifier<String>
///     items: ['RHOL ...', 'RHLL ...'],
///     hint: 'Select Lay Direction',
///     validator: (v) => v.isEmpty ? 'Required' : null,
///   )
class AppDropdown extends StatelessWidget {
  final ValueNotifier<String> notifier;
  final List<String> items;
  final String hint;
  final String? Function(String)? validator;
  final String? label;

  const AppDropdown({
    super.key,
    required this.notifier,
    required this.items,
    required this.hint,
    this.validator,
    this.label,
  });

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: notifier,
      builder: (context, value, _) {
        return _AppDropdownInner(
          items: items,
          hint: hint,
          label: label,
          value: value.isEmpty ? null : value,
          validator: validator,
          onChanged: (v) {
            if (v != null) notifier.value = v;
          },
        );
      },
    );
  }
}

/// The actual [StatefulWidget] that holds the form field.
/// Being a separate [StatefulWidget] means Flutter keeps its [State] alive
/// across parent rebuilds — the open overlay is never destroyed.
class _AppDropdownInner extends StatefulWidget {
  final List<String> items;
  final String hint;
  final String? label;
  final String? value;
  final String? Function(String)? validator;
  final void Function(String?) onChanged;

  const _AppDropdownInner({
    required this.items,
    required this.hint,
    this.label,
    required this.value,
    required this.validator,
    required this.onChanged,
  });

  @override
  State<_AppDropdownInner> createState() => _AppDropdownInnerState();
}

class _AppDropdownInnerState extends State<_AppDropdownInner> {
  String? _localValue;

  @override
  void initState() {
    super.initState();
    _localValue = widget.value;
  }

  @override
  void didUpdateWidget(_AppDropdownInner old) {
    super.didUpdateWidget(old);
    // Sync from controller (e.g. after track() populates from Firestore)
    if (widget.value != old.value && widget.value != _localValue) {
      // Defer to avoid setState during build
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) setState(() => _localValue = widget.value);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      value: _localValue,
      decoration: InputDecoration(
        labelText: widget.label,
        labelStyle: const TextStyle(color: AppColors.primaryColor),
        hintText: widget.hint,
        hintStyle: GoogleFonts.ubuntu(fontSize: 13, color: Colors.grey[500]),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide:
              const BorderSide(color: AppColors.primaryColor, width: 2),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide:
              const BorderSide(color: AppColors.primaryColor, width: 2),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide:
              const BorderSide(color: AppColors.primaryColor, width: 2.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: Colors.red, width: 2),
        ),
      ),
      validator: widget.validator == null
          ? null
          : (v) => widget.validator!(v ?? ''),
      dropdownColor: Colors.white,
      icon: const Icon(Icons.arrow_drop_down, color: AppColors.primaryColor),
      style: GoogleFonts.ubuntu(fontSize: 13, color: Colors.black87),
      isExpanded: true,
      items: widget.items
          .map((e) => DropdownMenuItem(value: e, child: Text(e)))
          .toList(),
      onChanged: (v) {
        setState(() => _localValue = v);
        widget.onChanged(v);
      },
    );
  }
}
