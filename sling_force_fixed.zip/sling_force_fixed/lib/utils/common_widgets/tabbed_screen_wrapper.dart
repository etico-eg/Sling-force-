import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sling_force/utils/common_widgets/audit_form_widget.dart';
import 'package:sling_force/values/app_colors.dart';

/// Wraps an existing screen's body in a Submit / Audit tab structure.
/// [title]        - Screen title shown in AppBar
/// [collection]   - Firestore collection name for audits
/// [submitChild]  - The existing submit form widget
/// [extraWhere]   - Optional extra filters for audit serial lookup
class TabbedScreenWrapper extends StatelessWidget {
  final String title;
  final String collection;
  final Widget submitChild;
  final Map<String, String>? extraWhere;

  TabbedScreenWrapper({
    super.key,
    required this.title,
    required this.collection,
    required this.submitChild,
    this.extraWhere,
  });

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          toolbarHeight: 40,
          automaticallyImplyLeading: true,
          foregroundColor: Colors.white,
          backgroundColor: const Color.fromARGB(255, 96, 10, 10),
          title: Text(
            title,
            style: GoogleFonts.ubuntu(
              fontSize: 15,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          bottom: TabBar(
            indicatorColor: Colors.white,
            indicatorWeight: 3,
            labelStyle: GoogleFonts.ubuntu(
                fontWeight: FontWeight.bold, fontSize: 14),
            unselectedLabelStyle:
                GoogleFonts.ubuntu(fontWeight: FontWeight.normal, fontSize: 14),
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white60,
            tabs: const [
              Tab(
                icon: Icon(Icons.add_circle_outline, size: 18),
                text: 'Submit',
                iconMargin: EdgeInsets.only(bottom: 2),
              ),
              Tab(
                icon: Icon(Icons.assignment_turned_in_outlined, size: 18),
                text: 'Audit',
                iconMargin: EdgeInsets.only(bottom: 2),
              ),
            ],
          ),
        ),
        body: SafeArea(
          child: TabBarView(
          children: [
            // Tab 0 — existing submit form (passed in)
            submitChild,
            // Tab 1 — audit form
            AuditFormWidget(
              collection: collection,
              extraWhere: extraWhere,
            ),
          ],
          ),
        ),
      ),
    );
  }
}
