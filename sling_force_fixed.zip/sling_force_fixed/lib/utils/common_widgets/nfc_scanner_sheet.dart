import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:nfc_manager/nfc_manager.dart';
import 'package:sling_force/values/app_colors.dart';

/// Shows a bottom sheet NFC scanner and returns the scanned value
/// (same contract as the QR scanner: returns a String or null).
///
/// Usage:
///   final result = await NfcScannerSheet.scan();
///   if (result != null) { ... }
class NfcScannerSheet {
  static Future<String?> scan() async {
    final bool isAvailable = await NfcManager.instance.isAvailable();
    if (!isAvailable) {
      Get.dialog(AlertDialog(
        title: const Text('NFC Not Available'),
        content: const Text(
            'This device does not support NFC or NFC is turned off. '
            'Please enable NFC in your device settings and try again.'),
        actions: [
          TextButton(onPressed: () => Get.back(), child: const Text('OK')),
        ],
      ));
      return null;
    }

    return await Get.bottomSheet<String>(
      _NfcScannerBottomSheet(),
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      isDismissible: true,
    );
  }
}

class _NfcScannerBottomSheet extends StatefulWidget {
  @override
  State<_NfcScannerBottomSheet> createState() => _NfcScannerBottomSheetState();
}

class _NfcScannerBottomSheetState extends State<_NfcScannerBottomSheet>
    with SingleTickerProviderStateMixin {
  String _status = 'Hold your device near an NFC tag';
  bool _scanning = true;
  bool _success = false;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _startNfc();
  }

  void _startNfc() {
    NfcManager.instance.startSession(
      onDiscovered: (NfcTag tag) async {
        String? value;

        // Try NDEF first (most common for labels/stickers)
        final ndef = Ndef.from(tag);
        if (ndef != null) {
          final cachedMessage = ndef.cachedMessage;
          if (cachedMessage != null && cachedMessage.records.isNotEmpty) {
            final record = cachedMessage.records.first;
            value = String.fromCharCodes(record.payload.skip(3));
          }
        }

        // Fallback: use tag identifier as hex string
        if (value == null || value.isEmpty) {
          final identifier = tag.data.values
              .map((v) => v['identifier'])
              .whereType<List<int>>()
              .firstOrNull;
          if (identifier != null) {
            value = identifier
                .map((b) => b.toRadixString(16).padLeft(2, '0'))
                .join(':')
                .toUpperCase();
          }
        }

        if (value != null && value.isNotEmpty) {
          await NfcManager.instance.stopSession();
          if (mounted) {
            setState(() {
              _status = 'Tag scanned successfully!';
              _scanning = false;
              _success = true;
            });
            await Future.delayed(const Duration(milliseconds: 800));
            if (mounted) Get.back(result: value);
          }
        }
      },
      onError: (error) async {
        if (mounted) {
          setState(() {
            _status = 'Error: ${error.message}. Try again.';
            _scanning = false;
          });
        }
      },
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    NfcManager.instance.stopSession();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 40),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Drag handle
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey[300],
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'NFC Scanner',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppColors.primaryColor,
            ),
          ),
          const SizedBox(height: 32),

          // Animated NFC icon
          ScaleTransition(
            scale: _scanning ? _pulseAnimation : const AlwaysStoppedAnimation(1.0),
            child: Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _success
                    ? Colors.green.withValues(alpha: 0.1)
                    : AppColors.primaryColor.withValues(alpha: 0.1),
                border: Border.all(
                  color: _success ? Colors.green : AppColors.primaryColor,
                  width: 2,
                ),
              ),
              child: Icon(
                _success ? Icons.check_circle_outline : Icons.nfc,
                size: 60,
                color: _success ? Colors.green : AppColors.primaryColor,
              ),
            ),
          ),

          const SizedBox(height: 28),

          Text(
            _status,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 15,
              color: _success ? Colors.green[700] : Colors.grey[700],
            ),
          ),

          const SizedBox(height: 32),

          // Retry / Cancel buttons
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () {
                    NfcManager.instance.stopSession();
                    Get.back(result: null);
                  },
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.primaryColor,
                    side: const BorderSide(color: AppColors.primaryColor),
                    shape: const StadiumBorder(),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: const Text('Cancel'),
                ),
              ),
              if (!_scanning && !_success) ...[
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _status = 'Hold your device near an NFC tag';
                        _scanning = true;
                        _success = false;
                      });
                      _startNfc();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryColor,
                      foregroundColor: Colors.white,
                      shape: const StadiumBorder(),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                    child: const Text('Try Again'),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}
