import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:getwidget/getwidget.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:sling_force/services/firestore_service.dart';
import 'package:sling_force/utils/common_widgets/nfc_scanner_sheet.dart';
import 'package:sling_force/utils/common_widgets/app_dropdown.dart';
import 'package:sling_force/utils/common_widgets/barcode_scanner_window.dart';
import 'package:sling_force/values/app_colors.dart';

/// A fully self-contained audit form.
/// Pass [collection] = the Firestore sub-collection name (e.g. 'shackles', 'wire_ropes').
/// Pass [extraWhere] to add extra .where() filters (e.g. for wire rope type filtering).
class AuditFormWidget extends StatefulWidget {
  final String collection;
  final Map<String, String>? extraWhere; // fieldName -> value

  const AuditFormWidget({
    super.key,
    required this.collection,
    this.extraWhere,
  });

  @override
  State<AuditFormWidget> createState() => _AuditFormWidgetState();
}

class _AuditFormWidgetState extends State<AuditFormWidget> {
  final _formKey = GlobalKey<FormState>();
  final _serialController = TextEditingController();
  final _failReasonController = TextEditingController();

  String _auditStatus = 'Pass';
  DateTime _auditDate = DateTime.now();
  bool _isSearching = false;
  bool _isSubmitting = false;
  Map<String, dynamic>? _foundItem;
  String? _searchError;
  final _auditNotifier = ValueNotifier<String>('Pass');

  // ── Lookup ────────────────────────────────────────────────────────────────
  Future<void> _findItem() async {
    if (_serialController.text.trim().isEmpty) return;
    setState(() {
      _isSearching = true;
      _foundItem = null;
      _searchError = null;
    });
    try {
      final companyName = await FirestoreService.getCompanyName();
      Query query = FirestoreService.productCollection(
              companyName, widget.collection)
          .where('serial', isEqualTo: _serialController.text.trim());

      // Apply any extra filters (e.g. wire rope type)
      if (widget.extraWhere != null) {
        for (final entry in widget.extraWhere!.entries) {
          query = query.where(entry.key, isEqualTo: entry.value);
        }
      }

      final docs = await query.get();
      if (docs.docs.isEmpty) {
        setState(() {
          _searchError =
              'Item not found. This serial has not been submitted yet.\nOnly submitted items can be audited.';
        });
      } else {
        setState(() {
          _foundItem = docs.docs.first.data() as Map<String, dynamic>;
        });
      }
    } catch (e) {
      setState(() => _searchError = 'Error: $e');
    } finally {
      setState(() => _isSearching = false);
    }
  }

  // ── Submit audit ─────────────────────────────────────────────────────────
  Future<void> _submitAudit() async {
    if (_foundItem == null) return;
    if (!_formKey.currentState!.validate()) return;
    _auditStatus = _auditNotifier.value; // sync from notifier
    if (_auditStatus == 'Fail' && _failReasonController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Please enter a fail reason'),
        backgroundColor: Colors.red,
      ));
      return;
    }

    final confirmed = await Get.dialog<bool>(AlertDialog(
      title: const Text('Submit Audit'),
      content: Text(
          'Submit audit for serial ${_serialController.text}?\nStatus: $_auditStatus'),
      actions: [
        TextButton(
            onPressed: () => Get.back(result: false),
            child: const Text('Cancel')),
        TextButton(
            onPressed: () => Get.back(result: true),
            child: const Text('Submit')),
      ],
    ));
    if (confirmed != true) return;

    setState(() => _isSubmitting = true);
    try {
      final companyName = await FirestoreService.getCompanyName();
      final userData = await FirestoreService.getUserData();
      final auditorName = userData['name'] ?? 'Unknown';
      final auditorUid = FirestoreService.currentUid;

      final auditEntry = {
        'auditStatus': _auditStatus,
        'auditDate': Timestamp.fromDate(_auditDate),
        'failReason':
            _auditStatus == 'Fail' ? _failReasonController.text.trim() : '',
        'auditorUid': auditorUid,
        'auditorName': auditorName,
        'createdAt': Timestamp.fromDate(DateTime.now()),
      };

      await FirestoreService.productCollection(companyName, widget.collection)
          .doc(_serialController.text.trim())
          .update({
        'latestAuditStatus': _auditStatus,
        'latestAuditDate': Timestamp.fromDate(_auditDate),
        'latestAuditFailReason':
            _auditStatus == 'Fail' ? _failReasonController.text.trim() : '',
        'latestAuditedBy': auditorUid,
        'latestAuditedByName': auditorName,
        'auditHistory': FieldValue.arrayUnion([auditEntry]),
      });

      // Reset form
      setState(() {
        _serialController.clear();
        _failReasonController.clear();
        _foundItem = null;
        _auditStatus = 'Pass';
        _auditDate = DateTime.now();
        _searchError = null;
      });

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Audit submitted: $_auditStatus'),
        backgroundColor: _auditNotifier.value == 'Pass' ? Colors.green : Colors.red,
      ));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Error submitting audit: $e'),
        backgroundColor: Colors.red,
      ));
    } finally {
      setState(() => _isSubmitting = false);
    }
  }

  // ── Date picker ───────────────────────────────────────────────────────────
  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _auditDate,
      firstDate: DateTime(2000),
      lastDate: DateTime.now(),
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: const ColorScheme.light(primary: AppColors.primaryColor),
        ),
        child: child!,
      ),
    );
    if (picked != null) setState(() => _auditDate = picked);
  }

  // ── Scan helpers ──────────────────────────────────────────────────────────
  Future<void> _scanQr() async {
    final result = await Get.to(() => BarcodeScannerWithScanWindow(
          controller: _AuditScanController.instance,
        ));
    if (result != null) {
      _serialController.text = result.split(' ')[0].replaceAll(',', '');
      await _findItem();
    }
  }

  Future<void> _scanNfc() async {
    final result = await NfcScannerSheet.scan();
    if (result != null) {
      _serialController.text = result.split(' ')[0].replaceAll(',', '');
      await _findItem();
    }
  }

  // ── Build ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Serial lookup ──────────────────────────────────────────────
            _sectionLabel('Serial Number'),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _serialController,
                    decoration: _inputDecoration('Enter serial number'),
                    keyboardType: TextInputType.text,
                    onFieldSubmitted: (_) => _findItem(),
                  ),
                ),
                const SizedBox(width: 8),
                _iconButton(Icons.search, _findItem),
                const SizedBox(width: 4),
                _iconButton(Icons.qr_code, _scanQr),
                const SizedBox(width: 4),
                _iconButton(Icons.nfc, _scanNfc),
              ],
            ),
            const SizedBox(height: 8),

            // ── Search state ───────────────────────────────────────────────
            if (_isSearching)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Center(
                    child: CircularProgressIndicator(
                        color: AppColors.primaryColor)),
              ),

            if (_searchError != null)
              Container(
                margin: const EdgeInsets.symmetric(vertical: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red[50],
                  border: Border.all(color: Colors.red[300]!),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.error_outline, color: Colors.red),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _searchError!,
                        style: const TextStyle(color: Colors.red),
                      ),
                    ),
                  ],
                ),
              ),

            // ── Found item summary ─────────────────────────────────────────
            if (_foundItem != null) ...[
              Container(
                margin: const EdgeInsets.symmetric(vertical: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.green[50],
                  border: Border.all(color: Colors.green[300]!),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.check_circle,
                            color: Colors.green, size: 18),
                        const SizedBox(width: 6),
                        Text('Item Found',
                            style: GoogleFonts.ubuntu(
                                fontWeight: FontWeight.bold,
                                color: Colors.green[800])),
                      ],
                    ),
                    const SizedBox(height: 8),
                    ..._foundItem!.entries
                        .where((e) => !_hiddenFields.contains(e.key))
                        .map((e) => Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 2),
                              child: Text(
                                '${_formatKey(e.key)}: ${e.value}',
                                style: GoogleFonts.ubuntu(fontSize: 12),
                              ),
                            )),
                    // Previous audit status badge
                    if (_foundItem!['latestAuditStatus'] != null) ...[
                      const SizedBox(height: 6),
                      const Divider(),
                      Text('Last Audit:',
                          style: GoogleFonts.ubuntu(
                              fontSize: 11, color: Colors.grey[600])),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          _auditBadge(_foundItem!['latestAuditStatus']),
                          const SizedBox(width: 8),
                          if (_foundItem!['latestAuditDate'] != null)
                            Text(
                              DateFormat('dd MMM yyyy').format(
                                  (_foundItem!['latestAuditDate'] as Timestamp)
                                      .toDate()),
                              style: GoogleFonts.ubuntu(fontSize: 11),
                            ),
                        ],
                      ),
                      if (_foundItem!['latestAuditFailReason'] != null &&
                          _foundItem!['latestAuditFailReason']
                              .toString()
                              .isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(
                            'Reason: ${_foundItem!['latestAuditFailReason']}',
                            style: GoogleFonts.ubuntu(
                                fontSize: 11, color: Colors.red[700]),
                          ),
                        ),
                    ],
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // ── Audit fields ─────────────────────────────────────────────
              _sectionLabel('Audit Status'),
              AppDropdown(
                notifier: _auditNotifier,
                hint: 'Select Status',
                items: const ['Pass', 'Fail'],
                validator: (v) => v.isEmpty ? 'Please select audit status' : null,
              ),

              const SizedBox(height: 16),

              // ── Fail reason ───────────────────────────────────────────────
              ValueListenableBuilder<String>(
                valueListenable: _auditNotifier,
                builder: (context, status, _) {
                  if (status != 'Fail') return const SizedBox.shrink();
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 16),
                      _sectionLabel('Fail Reason *'),
                      TextFormField(
                        controller: _failReasonController,
                        decoration: _inputDecoration('Describe the issue...'),
                        maxLines: 3,
                        validator: (v) => status == 'Fail' && (v == null || v.trim().isEmpty)
                            ? 'Please enter a fail reason'
                            : null,
                      ),
                    ],
                  );
                },
              ),

              // ── Audit date ────────────────────────────────────────────────
              _sectionLabel('Audit Date'),
              GestureDetector(
                onTap: _pickDate,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 14),
                  decoration: BoxDecoration(
                    border: Border.all(
                        color: AppColors.primaryColor, width: 1.5),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.calendar_today,
                          color: AppColors.primaryColor, size: 18),
                      const SizedBox(width: 10),
                      Text(
                        DateFormat('dd MMM yyyy').format(_auditDate),
                        style: GoogleFonts.ubuntu(
                            fontWeight: FontWeight.w500),
                      ),
                      const Spacer(),
                      const Icon(Icons.arrow_drop_down,
                          color: AppColors.primaryColor),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 28),

              // ── Submit button ──────────────────────────────────────────────
              SizedBox(
                width: double.infinity,
                child: _isSubmitting
                    ? const Center(
                        child: CircularProgressIndicator(
                            color: AppColors.primaryColor))
                    : ElevatedButton.icon(
                        onPressed: _submitAudit,
                        icon: const Icon(Icons.assignment_turned_in,
                            color: Colors.white),
                        label: Text(
                          'Submit Audit',
                          style: GoogleFonts.ubuntu(
                              fontWeight: FontWeight.bold,
                              color: Colors.white),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _auditNotifier.value == 'Pass'
                              ? Colors.green[700]
                              : Colors.red[700],
                          padding:
                              const EdgeInsets.symmetric(vertical: 14),
                          shape: const StadiumBorder(),
                        ),
                      ),
              ),
              const SizedBox(height: 24),
            ],
          ],
        ),
      ),
    );
  }

  // ── Helpers ───────────────────────────────────────────────────────────────
  Widget _sectionLabel(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(
          text,
          style: GoogleFonts.ubuntu(
              fontWeight: FontWeight.w600,
              fontSize: 13,
              color: Colors.black87),
        ),
      );

  InputDecoration _inputDecoration(String hint) => InputDecoration(
        hintText: hint,
        hintStyle: GoogleFonts.ubuntu(fontSize: 13, color: Colors.grey),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide:
              const BorderSide(color: AppColors.primaryColor, width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide:
              const BorderSide(color: AppColors.primaryColor, width: 2),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide:
              const BorderSide(color: AppColors.primaryColor, width: 1.5),
        ),
      );

  Widget _iconButton(IconData icon, VoidCallback onTap) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            border:
                Border.all(color: AppColors.primaryColor, width: 1.5),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: AppColors.primaryColor, size: 20),
        ),
      );

  Widget _auditBadge(String status) => Container(
        padding:
            const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
        decoration: BoxDecoration(
          color: status == 'Pass' ? Colors.green[100] : Colors.red[100],
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: status == 'Pass'
                  ? Colors.green[400]!
                  : Colors.red[400]!),
        ),
        child: Text(
          status,
          style: GoogleFonts.ubuntu(
              fontSize: 11,
              fontWeight: FontWeight.bold,
              color: status == 'Pass'
                  ? Colors.green[800]
                  : Colors.red[800]),
        ),
      );

  String _formatKey(String key) {
    return key
        .replaceAllMapped(
            RegExp(r'([A-Z])'), (m) => ' ${m.group(1)}')
        .replaceAll('_', ' ')
        .trim()
        .split(' ')
        .map((w) => w.isEmpty ? '' : '${w[0].toUpperCase()}${w.substring(1)}')
        .join(' ');
  }

  static const _hiddenFields = {
    'creatorUid', 'companyId', 'auditHistory',
    'latestAuditedBy', 'latestAuditStatus', 'latestAuditDate',
    'latestAuditFailReason', 'latestAuditedByName',
  };

  @override
  void dispose() {
    _serialController.dispose();
    _failReasonController.dispose();
    super.dispose();
  }
}

/// Minimal GetxController used only so BarcodeScannerWithScanWindow has
/// a controller reference in the audit flow.
class _AuditScanController extends GetxController {
  static final _AuditScanController instance = _AuditScanController();
}
