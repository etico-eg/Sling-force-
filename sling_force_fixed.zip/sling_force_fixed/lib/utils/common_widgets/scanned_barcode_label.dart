import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class ScannedBarcodeLabel extends StatefulWidget {
  final Stream<BarcodeCapture> barcodes;
  final GetxController controller;

  const ScannedBarcodeLabel(
      {super.key, required this.barcodes, required this.controller});

  @override
  State<ScannedBarcodeLabel> createState() => _ScannedBarcodeLabelState();
}

class _ScannedBarcodeLabelState extends State<ScannedBarcodeLabel> {
  var backed = false;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: widget.barcodes,
      builder: (context, snapshot) {
        final scannedBarcodes = snapshot.data?.barcodes ?? [];

        if (scannedBarcodes.isEmpty) {
          return const Text(
            'Scan something!',
            overflow: TextOverflow.fade,
            style: TextStyle(color: Colors.white),
          );
        }
        if (scannedBarcodes.first.displayValue!.isNotEmpty) {
          if (!backed) {
            // print(
            //   'scanned barcodes: ${scannedBarcodes.first.displayValue}',
            // );

            WidgetsBinding.instance.addPostFrameCallback((_) {
              Get.back(result: scannedBarcodes.first.displayValue);
            });
          }
          WidgetsBinding.instance.addPostFrameCallback((_) {
            setState(() {
              backed = true;
            });
          });
        }
        return Text(
          scannedBarcodes.first.displayValue!.isNotEmpty
              ? 'Bar Code scanned succsefully'
              : 'Empty Bar Code',
          overflow: TextOverflow.fade,
          style: const TextStyle(color: Colors.white),
        );
      },
    );
  }
}
