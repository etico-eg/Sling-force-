package slingforce.com.sling_force

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
